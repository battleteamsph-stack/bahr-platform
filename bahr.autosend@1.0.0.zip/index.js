(function (exports) {
    "use strict";

    var cfg = {
        channelId: "",
        messageText: "",
        rateMode: "interval", // "interval" (seconds between msgs) | "perSecond" (msgs per second)
        intervalSec: "5",
        perSecond: "1",
        countMode: "fixed", // "fixed" | "unlimited"
        totalCount: "10",
        scheduleMode: "now", // "now" | "delayMin" | "clock"
        delayMinutes: "5",
        clockTime: "22:00",
        showLocalNotices: true
    };

    var storageRef = null;
    var originalSendMessage = null;

    var mods = {
        RestAPI: null,
        UserStore: null,
        ChannelStore: null,
        GuildStore: null,
        SelectedChannelStore: null,
        MessageActions: null,
        Dispatcher: null,
        Toast: null
    };

    var job = {
        running: false,
        waitingSchedule: false,
        stopRequested: false,
        channelId: "",
        channelLabel: "",
        sent: 0,
        failed: 0,
        rateLimits: 0,
        targetCount: null, // null = unlimited
        nextActionAt: 0,
        status: "جاهز للإرسال",
        lastError: ""
    };

    var activeTimer = null;
    var countdownTicker = null;
    var listeners = [];

    function emitState() {
        for (var i = 0; i < listeners.length; i++) {
            try { listeners[i](); } catch (e) {}
        }
    }

    function subscribeState(fn) {
        listeners.push(fn);
        return function () {
            var idx = listeners.indexOf(fn);
            if (idx !== -1) listeners.splice(idx, 1);
        };
    }

    function getReact() {
        return (typeof valenced !== "undefined" && valenced.react && (valenced.react.React || valenced.react)) || null;
    }

    function getRN() {
        return (typeof valenced !== "undefined" && valenced.react && valenced.react.ReactNative) || null;
    }

    function sleepAbortable(ms) {
        return new Promise(function (resolve) {
            if (job.stopRequested) {
                resolve();
                return;
            }
            var wait = Math.max(0, ms);
            job.nextActionAt = Date.now() + wait;
            activeTimer = setTimeout(function () {
                activeTimer = null;
                job.nextActionAt = 0;
                resolve();
            }, wait);
        });
    }

    function clearTimers() {
        if (activeTimer) {
            clearTimeout(activeTimer);
            activeTimer = null;
        }
        if (countdownTicker) {
            clearInterval(countdownTicker);
            countdownTicker = null;
        }
        job.nextActionAt = 0;
    }

    function normalizeDigits(str) {
        if (typeof str !== "string") return "";
        var arabic = "٠١٢٣٤٥٦٧٨٩";
        var persian = "۰۱۲۳۴۵۶۷۸۹";
        var out = "";
        for (var i = 0; i < str.length; i++) {
            var ch = str.charAt(i);
            var idx = arabic.indexOf(ch);
            if (idx !== -1) {
                out += String(idx);
            } else {
                var pidx = persian.indexOf(ch);
                if (pidx !== -1) out += String(pidx);
                else out += ch;
            }
        }
        return out;
    }

    function showToast(text) {
        try {
            if (mods.Toast && typeof mods.Toast.showToast === "function") {
                mods.Toast.showToast(text);
                return;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.ToastAndroid && typeof RN.ToastAndroid.show === "function") {
                RN.ToastAndroid.show(String(text), RN.ToastAndroid.SHORT);
            }
        } catch (e) {}
    }

    function sendLocalNotice(channelId, content) {
        if (!cfg.showLocalNotices || !channelId) return;
        var now = new Date().toISOString();
        var fakeId = String(Date.now()) + String(Math.floor(Math.random() * 100000));
        var msgObj = {
            id: fakeId,
            type: 0,
            channel_id: channelId,
            content: content,
            timestamp: now,
            edited_timestamp: null,
            tts: false,
            mention_everyone: false,
            mentions: [],
            mention_roles: [],
            attachments: [],
            embeds: [],
            pinned: false,
            flags: 64,
            state: "SENT",
            author: {
                id: "1",
                username: "منصة بحر • الإرسال التلقائي",
                global_name: "منصة بحر • الإرسال التلقائي",
                discriminator: "0000",
                avatar: null,
                bot: true
            }
        };

        try {
            if (mods.MessageActions && typeof mods.MessageActions.receiveMessage === "function") {
                mods.MessageActions.receiveMessage(channelId, msgObj);
                return;
            }
        } catch (e) {}

        try {
            if (mods.Dispatcher && typeof mods.Dispatcher.dispatch === "function") {
                mods.Dispatcher.dispatch({
                    type: "MESSAGE_CREATE",
                    channelId: channelId,
                    message: msgObj,
                    optimistic: false,
                    isPushNotification: false
                });
            }
        } catch (e) {}
    }

    function getCurrentChannelId() {
        try {
            if (mods.SelectedChannelStore && typeof mods.SelectedChannelStore.getChannelId === "function") {
                return mods.SelectedChannelStore.getChannelId() || "";
            }
        } catch (e) {}
        return "";
    }

    function getChannelInfo(channelId) {
        if (!channelId) return { id: "", name: "غير محدد", typeLabel: "", guildId: null };
        var ch = null;
        try {
            if (mods.ChannelStore && typeof mods.ChannelStore.getChannel === "function") {
                ch = mods.ChannelStore.getChannel(channelId);
            }
        } catch (e) {}

        if (!ch) {
            return { id: channelId, name: "غرفة (" + channelId + ")", typeLabel: "غرفة", guildId: null };
        }

        var type = ch.type;
        var guildId = ch.guild_id || null;

        if (type === 1) {
            var recipientName = "محادثة خاصة";
            try {
                var recIds = ch.recipients || ch.rawRecipients;
                if (Array.isArray(recIds) && recIds.length > 0) {
                    var first = recIds[0];
                    if (typeof first === "object" && first) {
                        recipientName = first.globalName || first.global_name || first.username || recipientName;
                    } else if (mods.UserStore && typeof mods.UserStore.getUser === "function") {
                        var u = mods.UserStore.getUser(String(first));
                        if (u) recipientName = u.globalName || u.global_name || u.username || recipientName;
                    }
                }
            } catch (e) {}
            return { id: channelId, name: recipientName, typeLabel: "خاص", guildId: null };
        }

        if (type === 3) {
            var gName = ch.name || "";
            if (!gName) {
                try {
                    var names = [];
                    var rIds = ch.recipients || [];
                    for (var i = 0; i < rIds.length && i < 3; i++) {
                        var uid = typeof rIds[i] === "object" ? rIds[i].id : String(rIds[i]);
                        var usr = mods.UserStore && mods.UserStore.getUser ? mods.UserStore.getUser(uid) : null;
                        if (usr) names.push(usr.globalName || usr.global_name || usr.username);
                    }
                    gName = names.length > 0 ? names.join("، ") : "قروب خاص";
                } catch (e) {
                    gName = "قروب خاص";
                }
            }
            return { id: channelId, name: gName, typeLabel: "قروب", guildId: null };
        }

        var chName = ch.name ? "#" + ch.name : channelId;
        var guildName = "";
        try {
            if (guildId && mods.GuildStore && typeof mods.GuildStore.getGuild === "function") {
                var g = mods.GuildStore.getGuild(guildId);
                if (g && g.name) guildName = g.name;
            }
        } catch (e) {}

        return {
            id: channelId,
            name: guildName ? (guildName + " / " + chName) : chName,
            typeLabel: "سيرفر",
            guildId: guildId
        };
    }

    function listPrivateChannels(maxItems) {
        var out = [];
        try {
            if (!mods.ChannelStore) return out;
            var raw = null;
            if (typeof mods.ChannelStore.getSortedPrivateChannels === "function") {
                raw = mods.ChannelStore.getSortedPrivateChannels();
            } else if (typeof mods.ChannelStore.getMutablePrivateChannels === "function") {
                var map = mods.ChannelStore.getMutablePrivateChannels();
                if (map && typeof map === "object") {
                    raw = Object.keys(map).map(function (k) { return map[k]; });
                }
            }
            if (Array.isArray(raw)) {
                for (var i = 0; i < raw.length && out.length < (maxItems || 25); i++) {
                    var c = raw[i];
                    if (c && c.id && (c.type === 1 || c.type === 3)) {
                        out.push(getChannelInfo(c.id));
                    }
                }
            }
        } catch (e) {}
        return out;
    }

    function extractRetryAfterMs(err) {
        try {
            if (err && err.body && typeof err.body.retry_after === "number") {
                return Math.ceil(err.body.retry_after * 1000) + 500;
            }
            if (err && err.headers && err.headers["retry-after"]) {
                var sec = parseFloat(err.headers["retry-after"]);
                if (!isNaN(sec)) return Math.ceil(sec * 1000) + 500;
            }
        } catch (e) {}
        return 3500;
    }

    function postMessageOnce(channelId, content) {
        function attempt(tries) {
            if (job.stopRequested) return Promise.resolve("stopped");

            var p;
            if (mods.RestAPI && typeof mods.RestAPI.post === "function") {
                p = Promise.resolve(mods.RestAPI.post({
                    url: "/channels/" + channelId + "/messages",
                    body: {
                        content: content,
                        tts: false
                    }
                }));
            } else if (originalSendMessage) {
                p = Promise.resolve(originalSendMessage.call(mods.MessageActions, channelId, {
                    content: content,
                    invalidEmojis: [],
                    tts: false,
                    validNonShortcutEmojis: []
                }));
            } else if (mods.MessageActions && typeof mods.MessageActions.sendMessage === "function") {
                p = Promise.resolve(mods.MessageActions.sendMessage(channelId, {
                    content: content,
                    invalidEmojis: [],
                    tts: false,
                    validNonShortcutEmojis: []
                }));
            } else {
                return Promise.reject(new Error("لا توجد وحدة إرسال متاحة حالياً"));
            }

            return p.then(function () {
                return "sent";
            }).catch(function (err) {
                var status = err && err.status;
                if (status === 429 && tries < 6) {
                    var waitMs = extractRetryAfterMs(err);
                    job.rateLimits++;
                    job.status = "حد مؤقت من السيرفر... انتظار " + Math.ceil(waitMs / 1000) + " ثانية";
                    emitState();
                    return sleepAbortable(waitMs).then(function () {
                        return attempt(tries + 1);
                    });
                }
                if (status === 403 || status === 401 || status === 404) {
                    throw err;
                }
                if (tries < 2) {
                    return sleepAbortable(1500).then(function () {
                        return attempt(tries + 1);
                    });
                }
                throw err;
            });
        }

        return attempt(0);
    }

    function parseMessagesList(rawText) {
        if (typeof rawText !== "string") return [];
        var parts = rawText.split(/\r?\n---\r?\n/);
        var out = [];
        for (var i = 0; i < parts.length; i++) {
            var p = parts[i].trim();
            if (p.length > 0) out.push(p);
        }
        return out;
    }

    function computeStartDelayMs(scheduleMode, delayMinutesStr, clockTimeStr) {
        if (scheduleMode === "delayMin") {
            var mins = parseFloat(normalizeDigits(String(delayMinutesStr || "0")));
            if (isNaN(mins) || mins <= 0) return 0;
            return Math.floor(mins * 60 * 1000);
        }
        if (scheduleMode === "clock") {
            var clean = normalizeDigits(String(clockTimeStr || "")).trim();
            var m = clean.match(/^(\d{1,2}):(\d{2})$/);
            if (!m) return -1; // invalid format
            var hh = parseInt(m[1], 10);
            var mm = parseInt(m[2], 10);
            if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return -1;
            var now = new Date();
            var target = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hh, mm, 0, 0);
            if (target.getTime() <= now.getTime()) {
                target.setDate(target.getDate() + 1);
            }
            return target.getTime() - now.getTime();
        }
        return 0;
    }

    function formatRemaining(ms) {
        if (ms <= 0) return "الآن";
        var totalSec = Math.ceil(ms / 1000);
        var h = Math.floor(totalSec / 3600);
        var m = Math.floor((totalSec % 3600) / 60);
        var s = totalSec % 60;
        if (h > 0) return h + "س " + m + "د " + s + "ث";
        if (m > 0) return m + "د " + s + "ث";
        return s + "ث";
    }

    function stopAutoSend(notifyChannelId) {
        if (!job.running) {
            showToast("لا توجد عملية إرسال تلقائي جارية حالياً");
            if (notifyChannelId) sendLocalNotice(notifyChannelId, "ℹ️ لا توجد عملية إرسال تلقائي جارية حالياً.");
            return;
        }
        job.stopRequested = true;
        job.waitingSchedule = false;
        job.status = "جارٍ إيقاف الإرسال...";
        clearTimers();
        emitState();
        showToast("تم إيقاف الإرسال التلقائي");
    }

    function startAutoSend(opts, notifyInChat) {
        if (job.running) {
            var busyMsg = "⚠️ هناك عملية إرسال تلقائي جارية بالفعل. أوقفها أولاً بكتابة `!ايقاف_تلقائي` أو من الإعدادات.";
            showToast("هناك عملية إرسال جارية بالفعل");
            if (notifyInChat && opts.channelId) sendLocalNotice(opts.channelId, busyMsg);
            return;
        }

        var channelId = normalizeDigits(String(opts.channelId || "")).trim();
        if (!channelId) {
            showToast("يرجى تحديد الغرفة أو الخاص (Channel ID) أولاً");
            return;
        }

        var messages = parseMessagesList(opts.messageText || "");
        if (messages.length === 0) {
            showToast("يرجى كتابة نص الرسالة أولاً");
            return;
        }

        var intervalMs = 5000;
        if (opts.rateMode === "perSecond") {
            var rate = parseFloat(normalizeDigits(String(opts.perSecond || "1")));
            if (isNaN(rate) || rate <= 0) rate = 1;
            if (rate > 5) rate = 5; // Safe upper cap to protect account
            intervalMs = Math.max(200, Math.round(1000 / rate));
        } else {
            var sec = parseFloat(normalizeDigits(String(opts.intervalSec || "5")));
            if (isNaN(sec) || sec < 0.2) sec = 1;
            intervalMs = Math.round(sec * 1000);
        }

        var targetCount = null;
        if (opts.countMode !== "unlimited") {
            var parsedCnt = parseInt(normalizeDigits(String(opts.totalCount || "1")), 10);
            if (isNaN(parsedCnt) || parsedCnt <= 0) {
                showToast("يرجى إدخال عدد رسائل صحيح أكبر من 0");
                return;
            }
            targetCount = parsedCnt;
        }

        var startDelayMs = computeStartDelayMs(opts.scheduleMode || "now", opts.delayMinutes, opts.clockTime);
        if (startDelayMs < 0) {
            showToast("صيغة الوقت غير صحيحة! استخدم صيغة مثل 22:30");
            return;
        }

        var info = getChannelInfo(channelId);

        job.running = true;
        job.stopRequested = false;
        job.waitingSchedule = startDelayMs > 0;
        job.channelId = channelId;
        job.channelLabel = (info.typeLabel ? "[" + info.typeLabel + "] " : "") + info.name;
        job.sent = 0;
        job.failed = 0;
        job.rateLimits = 0;
        job.targetCount = targetCount;
        job.lastError = "";
        job.status = startDelayMs > 0
            ? ("مجدول: سيبدأ بعد " + formatRemaining(startDelayMs))
            : ("جارٍ الإرسال إلى " + job.channelLabel + "...");
        emitState();

        countdownTicker = setInterval(function () {
            if (!job.running) {
                clearTimers();
                return;
            }
            emitState();
        }, 1000);

        var countLabel = targetCount ? (targetCount + " رسالة") : "غير محدود";
        var rateLabel = opts.rateMode === "perSecond"
            ? (opts.perSecond + " رسالة/ثانية")
            : ("كل " + (intervalMs / 1000) + " ثانية");

        showToast(startDelayMs > 0 ? ("تم جدولة الإرسال بعد " + formatRemaining(startDelayMs)) : "بدأ الإرسال التلقائي");
        if (notifyInChat) {
            sendLocalNotice(
                channelId,
                "📤 **تم تشغيل الإرسال التلقائي**\n" +
                "• المكان: **" + job.channelLabel + "**\n" +
                "• العدد: **" + countLabel + "** | السرعة: **" + rateLabel + "**\n" +
                (startDelayMs > 0 ? ("• وقت البدء: بعد **" + formatRemaining(startDelayMs) + "**\n") : "") +
                "• للإيقاف الفوري اكتب: `!ايقاف_تلقائي`"
            );
        }

        var startPromise = startDelayMs > 0 ? sleepAbortable(startDelayMs) : Promise.resolve();

        startPromise.then(function () {
            job.waitingSchedule = false;
            if (job.stopRequested) return;

            function sendNext() {
                if (job.stopRequested) return Promise.resolve();
                if (targetCount && job.sent >= targetCount) return Promise.resolve();

                var msgBody = messages[job.sent % messages.length];
                job.status = "جارٍ الإرسال (" + (job.sent + 1) + (targetCount ? (" / " + targetCount) : "") + ")...";
                emitState();

                return postMessageOnce(channelId, msgBody).then(function (res) {
                    if (res === "sent") {
                        job.sent++;
                        job.status = "تم إرسال " + job.sent + (targetCount ? (" / " + targetCount) : "") + " رسالة";
                        emitState();
                    }
                    if (job.stopRequested) return;
                    if (targetCount && job.sent >= targetCount) return;
                    return sleepAbortable(intervalMs).then(sendNext);
                });
            }

            return sendNext();
        }).then(function () {
            var wasStopped = job.stopRequested;
            clearTimers();
            job.running = false;
            job.waitingSchedule = false;
            job.stopRequested = false;
            job.status = (wasStopped ? "تم الإيقاف: " : "اكتمل الإرسال: ") + "أُرسلت " + job.sent + " رسالة";
            emitState();

            showToast((wasStopped ? "تم الإيقاف: " : "اكتمل: ") + "أُرسلت " + job.sent + " رسالة");
            if (notifyInChat) {
                sendLocalNotice(
                    channelId,
                    (wasStopped ? "⏹️ **تم إيقاف الإرسال التلقائي**" : "✅ **اكتمل الإرسال التلقائي**") +
                    "\n• المكان: **" + job.channelLabel + "**" +
                    "\n• الرسائل المرسلة: **" + job.sent + "**"
                );
            }
        }).catch(function (err) {
            var errText = (err && (err.message || (err.body && err.body.message))) || String(err || "خطأ غير معروف");
            clearTimers();
            job.running = false;
            job.waitingSchedule = false;
            job.stopRequested = false;
            job.failed++;
            job.lastError = errText;
            job.status = "توقف بسبب خطأ بعد إرسال " + job.sent + " رسالة";
            emitState();
            showToast("خطأ في الإرسال: " + errText);
            if (notifyInChat) {
                sendLocalNotice(channelId, "❌ **توقف الإرسال التلقائي بسبب خطأ:** " + errText + "\n• تم إرسال **" + job.sent + "** رسالة.");
            }
        });
    }

    function handleChatCommand(channelId, rawText) {
        if (typeof rawText !== "string") return false;
        var text = rawText.trim();
        if (!text || text.charAt(0) !== "!") return false;

        var norm = normalizeDigits(text);
        var firstSpace = norm.indexOf(" ");
        var cmd = (firstSpace === -1 ? norm : norm.slice(0, firstSpace)).toLowerCase();
        var rest = firstSpace === -1 ? "" : text.slice(firstSpace + 1).trim();

        if (cmd === "!ايقاف_تلقائي" || cmd === "!إيقاف_تلقائي" || cmd === "!stop_auto") {
            stopAutoSend(channelId);
            return true;
        }

        if (cmd === "!حالة_تلقائي" || cmd === "!status_auto") {
            var rem = job.nextActionAt > Date.now() ? (" | القادم بعد: " + formatRemaining(job.nextActionAt - Date.now())) : "";
            sendLocalNotice(
                channelId,
                "📊 **حالة الإرسال التلقائي:** " + job.status + rem +
                (job.running ? ("\n• المكان: **" + job.channelLabel + "**\n• المرسل: **" + job.sent + "**") : "")
            );
            return true;
        }

        if (cmd === "!تلقائي" || cmd === "!autosend") {
            if (!rest || rest === "مساعدة" || rest === "help" || rest === "؟" || rest === "?") {
                sendLocalNotice(
                    channelId,
                    "📤 **أوامر الإرسال التلقائي السريعة:**\n" +
                    "• `!تلقائي <العدد> <الثواني> <الرسالة>`\n" +
                    "  مثال: `!تلقائي 5 10 سبحان الله وبحمده`\n" +
                    "• `!ايقاف_تلقائي` — إيقاف الإرسال فوراً\n" +
                    "• `!حالة_تلقائي` — معرفة عدد الرسائل المرسلة\n" +
                    "*(وللمزيد من الخيارات مثل وقت البدء أو اختيار ID غرفة أخرى استخدم إعدادات الإضافة)*"
                );
                return true;
            }

            if (rest === "ايقاف" || rest === "إيقاف" || rest === "stop") {
                stopAutoSend(channelId);
                return true;
            }

            if (rest === "حالة" || rest === "status") {
                sendLocalNotice(channelId, "📊 **حالة الإرسال التلقائي:** " + job.status);
                return true;
            }

            // Format: !تلقائي <count> <seconds> <message...>
            var m = rest.match(/^([0-9٠-٩۰-۹]+)\s+([0-9٠-٩۰-۹.]+)\s+([\s\S]+)$/);
            if (!m) {
                sendLocalNotice(channelId, "⚠️ الصيغة الصحيحة: `!تلقائي <العدد> <الفاصل_بالثانية> <نص الرسالة>`\nمثال: `!تلقائي 5 10 السلام عليكم`");
                return true;
            }

            var cnt = normalizeDigits(m[1]);
            var sec = normalizeDigits(m[2]);
            var msg = m[3].trim();

            startAutoSend({
                channelId: channelId,
                messageText: msg,
                rateMode: "interval",
                intervalSec: sec,
                countMode: "fixed",
                totalCount: cnt,
                scheduleMode: "now"
            }, true);
            return true;
        }

        return false;
    }

    function saveSettings(patch) {
        var keys = Object.keys(patch);
        for (var i = 0; i < keys.length; i++) {
            cfg[keys[i]] = patch[keys[i]];
        }
        if (storageRef && typeof storageRef.set === "function") {
            try { storageRef.set(patch); } catch (e) {}
        }
    }

    exports.default = plugin({
        jsonStorage: {
            load: true,
            default: {
                channelId: "",
                messageText: "",
                rateMode: "interval",
                intervalSec: "5",
                perSecond: "1",
                countMode: "fixed",
                totalCount: "10",
                scheduleMode: "now",
                delayMinutes: "5",
                clockTime: "22:00",
                showLocalNotices: true
            }
        },
        start: function (ctx) {
            var cleanup = ctx.cleanup;
            var finders = valenced.modules.finders;
            var filters = finders.filters;
            var patcher = valenced.patcher;

            storageRef = ctx.jsonStorage || null;
            if (storageRef) {
                var applyLoaded = function (c) {
                    if (!c || typeof c !== "object") return;
                    var keys = Object.keys(cfg);
                    for (var i = 0; i < keys.length; i++) {
                        var k = keys[i];
                        if (c[k] !== undefined) cfg[k] = c[k];
                    }
                };
                if (storageRef.cache) applyLoaded(storageRef.cache);
                if (typeof storageRef.get === "function") {
                    Promise.resolve(storageRef.get()).then(applyLoaded).catch(function () {});
                }
            }

            try {
                var d = valenced.discord;
                if (d) {
                    if (d.rest) mods.RestAPI = d.rest;
                    if (d.common && d.common.RestAPI && !mods.RestAPI) mods.RestAPI = d.common.RestAPI;
                    if (d.common && d.common.flux && d.common.flux.Dispatcher) mods.Dispatcher = d.common.flux.Dispatcher;
                    if (d.flux && d.flux.Stores) {
                        if (d.flux.Stores.UserStore) mods.UserStore = d.flux.Stores.UserStore;
                        if (d.flux.Stores.ChannelStore) mods.ChannelStore = d.flux.Stores.ChannelStore;
                        if (d.flux.Stores.GuildStore) mods.GuildStore = d.flux.Stores.GuildStore;
                        if (d.flux.Stores.SelectedChannelStore) mods.SelectedChannelStore = d.flux.Stores.SelectedChannelStore;
                    }
                }
            } catch (e) {}

            cleanup(finders.getModules(filters.withProps("get", "post", "put", "del"), function (m) {
                if (m && typeof m.post === "function") {
                    if (!mods.RestAPI || typeof m.getAPIBaseURL === "function" || typeof m.patch === "function") {
                        mods.RestAPI = m;
                    }
                }
            }));

            if (!mods.UserStore) {
                cleanup(finders.getModules(filters.withProps("getCurrentUser", "getUser"), function (m) {
                    mods.UserStore = m;
                }));
            }

            if (!mods.ChannelStore) {
                cleanup(finders.getModules(filters.withProps("getChannel", "getDMFromUserId"), function (m) {
                    mods.ChannelStore = m;
                }));
            }

            if (!mods.GuildStore) {
                cleanup(finders.getModules(filters.withProps("getGuild", "getGuilds"), function (m) {
                    mods.GuildStore = m;
                }));
            }

            if (!mods.SelectedChannelStore) {
                cleanup(finders.getModules(filters.withProps("getChannelId", "getVoiceChannelId"), function (m) {
                    mods.SelectedChannelStore = m;
                }));
            }

            if (!mods.Dispatcher) {
                cleanup(finders.getModules(filters.withProps("_interceptors", "dispatch"), function (m) {
                    mods.Dispatcher = m;
                }));
            }

            cleanup(finders.getModules(filters.withProps("showToast"), function (m) {
                mods.Toast = m;
            }));

            var sendPatched = false;
            cleanup(finders.getModules(filters.withProps("sendMessage", "deleteMessage"), function (m) {
                if (!m || typeof m.sendMessage !== "function") return;
                mods.MessageActions = m;
                if (sendPatched) return;
                sendPatched = true;
                originalSendMessage = m.sendMessage;
                try {
                    cleanup(patcher.instead(m, "sendMessage", function (args, original) {
                        originalSendMessage = original;
                        try {
                            var chId = args && args[0];
                            var msgPayload = args && args[1];
                            var content = msgPayload && msgPayload.content;
                            if (typeof content === "string" && handleChatCommand(chId, content)) {
                                return Promise.resolve();
                            }
                        } catch (e) {}
                        return original.apply(this, args);
                    }));
                } catch (e) {}
            }));

            cleanup(function () {
                job.stopRequested = true;
                clearTimers();
            });
        },

        SettingsComponent: function () {
            var R = getReact();
            var RN = getRN();
            if (!R || !RN) return null;

            var View = RN.View;
            var Text = RN.Text;
            var ScrollView = RN.ScrollView;
            var TouchableOpacity = RN.TouchableOpacity;
            var TextInput = RN.TextInput;

            var tickState = R.useState(0);
            var setTick = tickState[1];

            R.useEffect(function () {
                return subscribeState(function () {
                    setTick(function (n) { return n + 1; });
                });
            }, []);

            var activeChannelId = getCurrentChannelId();

            var channelIdState = R.useState(cfg.channelId || activeChannelId || "");
            var channelId = channelIdState[0];
            var setChannelId = channelIdState[1];

            var messageState = R.useState(cfg.messageText || "");
            var messageText = messageState[0];
            var setMessageText = messageState[1];

            var rateModeState = R.useState(cfg.rateMode || "interval");
            var rateMode = rateModeState[0];
            var setRateMode = rateModeState[1];

            var intervalState = R.useState(String(cfg.intervalSec || "5"));
            var intervalSec = intervalState[0];
            var setIntervalSec = intervalState[1];

            var perSecState = R.useState(String(cfg.perSecond || "1"));
            var perSecond = perSecState[0];
            var setPerSecond = perSecState[1];

            var countModeState = R.useState(cfg.countMode || "fixed");
            var countMode = countModeState[0];
            var setCountMode = countModeState[1];

            var totalCountState = R.useState(String(cfg.totalCount || "10"));
            var totalCount = totalCountState[0];
            var setTotalCount = totalCountState[1];

            var scheduleModeState = R.useState(cfg.scheduleMode || "now");
            var scheduleMode = scheduleModeState[0];
            var setScheduleMode = scheduleModeState[1];

            var delayMinState = R.useState(String(cfg.delayMinutes || "5"));
            var delayMinutes = delayMinState[0];
            var setDelayMinutes = delayMinState[1];

            var clockState = R.useState(String(cfg.clockTime || "22:00"));
            var clockTime = clockState[0];
            var setClockTime = clockState[1];

            var showDmListState = R.useState(false);
            var showDmList = showDmListState[0];
            var setShowDmList = showDmListState[1];

            var selectedInfo = getChannelInfo(channelId);
            var activeInfo = activeChannelId ? getChannelInfo(activeChannelId) : null;
            var privateChannels = showDmList ? listPrivateChannels(30) : [];

            function persistAll() {
                saveSettings({
                    channelId: channelId,
                    messageText: messageText,
                    rateMode: rateMode,
                    intervalSec: intervalSec,
                    perSecond: perSecond,
                    countMode: countMode,
                    totalCount: totalCount,
                    scheduleMode: scheduleMode,
                    delayMinutes: delayMinutes,
                    clockTime: clockTime
                });
            }

            function btnStyle(bg, extra) {
                return Object.assign({
                    backgroundColor: bg,
                    paddingVertical: 11,
                    paddingHorizontal: 12,
                    borderRadius: 8,
                    alignItems: "center",
                    justifyContent: "center"
                }, extra || {});
            }

            var cardStyle = {
                backgroundColor: "#2B2D31",
                borderRadius: 10,
                padding: 14,
                gap: 10
            };

            var inputStyle = {
                backgroundColor: "#111214",
                color: "#FFFFFF",
                padding: 10,
                borderRadius: 8,
                borderWidth: 1,
                borderColor: "#3F4147",
                textAlign: "right"
            };

            var remText = (job.running && job.nextActionAt > Date.now())
                ? ("  |  القادم بعد: " + formatRemaining(job.nextActionAt - Date.now()))
                : "";

            var intervalPresets = [
                { label: "1ث", val: "1" },
                { label: "2ث", val: "2" },
                { label: "5ث", val: "5" },
                { label: "10ث", val: "10" },
                { label: "60ث", val: "60" },
                { label: "5د", val: "300" }
            ];
            var perSecPresets = ["1", "2", "3"];
            var countPresets = ["5", "10", "25", "50", "100"];

            return R.createElement(
                ScrollView,
                { style: { flex: 1, padding: 16, backgroundColor: "#1E1F22" } },
                R.createElement(
                    View,
                    { style: { gap: 14, paddingBottom: 42 } },

                    // Header
                    R.createElement(
                        Text,
                        { style: { fontSize: 19, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                        "📤 الإرسال التلقائي للرسائل"
                    ),

                    // Live Status Card
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 14, fontWeight: "bold", color: job.running ? "#23A55A" : "#FFFFFF", textAlign: "right" } },
                            "الحالة: " + job.status
                        ),
                        R.createElement(
                            Text,
                            { style: { fontSize: 12, color: "#B5BAC1", textAlign: "right" } },
                            "المرسلة: " + job.sent + (job.targetCount ? (" / " + job.targetCount) : "") + remText
                        ),
                        job.lastError ? R.createElement(
                            Text,
                            { style: { fontSize: 12, color: "#F23F43", textAlign: "right" } },
                            "آخر خطأ: " + job.lastError
                        ) : null,
                        job.running ? R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () { stopAutoSend(null); },
                                style: btnStyle("#DA373C")
                            },
                            R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, "⏹️ إيقاف الإرسال فوراً")
                        ) : null
                    ),

                    // 1) Target Channel
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "1) الغرفة أو الخاص (Channel ID)"
                        ),
                        R.createElement(
                            Text,
                            { style: { fontSize: 13, color: "#DBDEE1", textAlign: "right" } },
                            "المحدد: " + (channelId ? ("[" + (selectedInfo.typeLabel || "غرفة") + "] " + selectedInfo.name) : "لم يتم التحديد")
                        ),
                        activeInfo ? R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () { setChannelId(activeChannelId); },
                                style: btnStyle("#5865F2")
                            },
                            R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, "استخدام المحادثة المفتوحة الآن: " + activeInfo.name)
                        ) : null,
                        R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () { setShowDmList(!showDmList); },
                                style: btnStyle("#4E5058")
                            },
                            R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, showDmList ? "إخفاء قائمة الخاص والقروبات ▲" : "اختيار من الخاص والقروبات ▼")
                        ),
                        showDmList ? R.createElement(
                            View,
                            { style: { gap: 6 } },
                            privateChannels.length === 0
                                ? R.createElement(Text, { style: { color: "#949BA4", textAlign: "right", fontSize: 12 } }, "لا توجد محادثات خاصة محمّلة حالياً.")
                                : privateChannels.map(function (ch) {
                                    var isSel = ch.id === channelId;
                                    return R.createElement(
                                        TouchableOpacity,
                                        {
                                            key: ch.id,
                                            onPress: function () {
                                                setChannelId(ch.id);
                                                setShowDmList(false);
                                            },
                                            style: btnStyle(isSel ? "#248046" : "#1E1F22", { alignItems: "flex-end" })
                                        },
                                        R.createElement(Text, { style: { color: "#FFFFFF", fontSize: 13 } }, "[" + ch.typeLabel + "] " + ch.name)
                                    );
                                })
                        ) : null,
                        TextInput ? R.createElement(TextInput, {
                            value: channelId,
                            onChangeText: function (t) { setChannelId(normalizeDigits(t).trim()); },
                            placeholder: "أدخل ID الغرفة أو الخاص هنا...",
                            placeholderTextColor: "#72767D",
                            keyboardType: "numeric",
                            style: inputStyle
                        }) : null
                    ),

                    // 2) Message Text
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "2) نص الرسالة"
                        ),
                        TextInput ? R.createElement(TextInput, {
                            value: messageText,
                            onChangeText: function (t) { setMessageText(t); },
                            placeholder: "اكتب الرسالة هنا...",
                            placeholderTextColor: "#72767D",
                            multiline: true,
                            numberOfLines: 4,
                            style: Object.assign({}, inputStyle, { minHeight: 90, textAlignVertical: "top" })
                        }) : null,
                        R.createElement(
                            Text,
                            { style: { fontSize: 11, color: "#949BA4", textAlign: "right" } },
                            "تلميح: يمكنك التبديل بين عدة رسائل تلقائياً بوضع --- في سطر منفصل بين كل رسالة وأخرى."
                        )
                    ),

                    // 3) Speed / Rate
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "3) سرعة الإرسال (بالثانية)"
                        ),
                        R.createElement(
                            View,
                            { style: { flexDirection: "row", gap: 8 } },
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setRateMode("interval"); },
                                    style: btnStyle(rateMode === "interval" ? "#5865F2" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 13 } }, "كل X ثانية")
                            ),
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setRateMode("perSecond"); },
                                    style: btnStyle(rateMode === "perSecond" ? "#5865F2" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 13 } }, "عدد المرات بالثانية")
                            )
                        ),
                        rateMode === "interval" ? R.createElement(
                            View,
                            { style: { gap: 8 } },
                            R.createElement(
                                View,
                                { style: { flexDirection: "row", flexWrap: "wrap", gap: 6, justifyContent: "flex-end" } },
                                intervalPresets.map(function (p) {
                                    return R.createElement(
                                        TouchableOpacity,
                                        {
                                            key: p.val,
                                            onPress: function () { setIntervalSec(p.val); },
                                            style: btnStyle(intervalSec === p.val ? "#248046" : "#1E1F22", { minWidth: 48, paddingVertical: 8 })
                                        },
                                        R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 12 } }, p.label)
                                    );
                                })
                            ),
                            TextInput ? R.createElement(TextInput, {
                                value: intervalSec,
                                onChangeText: function (t) { setIntervalSec(normalizeDigits(t).replace(/[^0-9.]/g, "")); },
                                placeholder: "الفاصل بالثواني (مثال: 5)",
                                placeholderTextColor: "#72767D",
                                keyboardType: "numeric",
                                style: inputStyle
                            }) : null
                        ) : R.createElement(
                            View,
                            { style: { gap: 8 } },
                            R.createElement(
                                View,
                                { style: { flexDirection: "row", gap: 6, justifyContent: "flex-end" } },
                                perSecPresets.map(function (v) {
                                    return R.createElement(
                                        TouchableOpacity,
                                        {
                                            key: v,
                                            onPress: function () { setPerSecond(v); },
                                            style: btnStyle(perSecond === v ? "#248046" : "#1E1F22", { minWidth: 72, paddingVertical: 8 })
                                        },
                                        R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 12 } }, v + " / ثانية")
                                    );
                                })
                            ),
                            TextInput ? R.createElement(TextInput, {
                                value: perSecond,
                                onChangeText: function (t) { setPerSecond(normalizeDigits(t).replace(/[^0-9.]/g, "")); },
                                placeholder: "عدد الرسائل في الثانية (1 إلى 5)",
                                placeholderTextColor: "#72767D",
                                keyboardType: "numeric",
                                style: inputStyle
                            }) : null,
                            R.createElement(
                                Text,
                                { style: { fontSize: 11, color: "#F0B232", textAlign: "right" } },
                                "ملاحظة: السرعات العالية قد تفعّل حد السيرفر المؤقت (Rate Limit)؛ الإضافة تنتظر تلقائياً لحماية حسابك."
                            )
                        )
                    ),

                    // 4) Message Count
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "4) عدد الرسائل"
                        ),
                        R.createElement(
                            View,
                            { style: { flexDirection: "row", gap: 8 } },
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setCountMode("fixed"); },
                                    style: btnStyle(countMode === "fixed" ? "#5865F2" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, "عدد محدد")
                            ),
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setCountMode("unlimited"); },
                                    style: btnStyle(countMode === "unlimited" ? "#248046" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, "مستمر حتى الإيقاف")
                            )
                        ),
                        countMode === "fixed" ? R.createElement(
                            View,
                            { style: { gap: 8 } },
                            R.createElement(
                                View,
                                { style: { flexDirection: "row", flexWrap: "wrap", gap: 6, justifyContent: "flex-end" } },
                                countPresets.map(function (n) {
                                    return R.createElement(
                                        TouchableOpacity,
                                        {
                                            key: n,
                                            onPress: function () { setTotalCount(n); },
                                            style: btnStyle(totalCount === n ? "#248046" : "#1E1F22", { minWidth: 50, paddingVertical: 8 })
                                        },
                                        R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, n)
                                    );
                                })
                            ),
                            TextInput ? R.createElement(TextInput, {
                                value: totalCount,
                                onChangeText: function (t) { setTotalCount(normalizeDigits(t).replace(/[^0-9]/g, "")); },
                                placeholder: "أدخل عدد الرسائل...",
                                placeholderTextColor: "#72767D",
                                keyboardType: "numeric",
                                style: inputStyle
                            }) : null
                        ) : null
                    ),

                    // 5) Start Time (Schedule)
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "5) وقت البدء"
                        ),
                        R.createElement(
                            View,
                            { style: { flexDirection: "row", gap: 6 } },
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setScheduleMode("now"); },
                                    style: btnStyle(scheduleMode === "now" ? "#5865F2" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 12 } }, "فوراً")
                            ),
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setScheduleMode("delayMin"); },
                                    style: btnStyle(scheduleMode === "delayMin" ? "#5865F2" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 12 } }, "بعد دقائق")
                            ),
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setScheduleMode("clock"); },
                                    style: btnStyle(scheduleMode === "clock" ? "#5865F2" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 12 } }, "وقت محدد")
                            )
                        ),
                        scheduleMode === "delayMin" && TextInput ? R.createElement(TextInput, {
                            value: delayMinutes,
                            onChangeText: function (t) { setDelayMinutes(normalizeDigits(t).replace(/[^0-9.]/g, "")); },
                            placeholder: "عدد الدقائق قبل البدء (مثال: 5)",
                            placeholderTextColor: "#72767D",
                            keyboardType: "numeric",
                            style: inputStyle
                        }) : null,
                        scheduleMode === "clock" && TextInput ? R.createElement(TextInput, {
                            value: clockTime,
                            onChangeText: function (t) { setClockTime(normalizeDigits(t).trim()); },
                            placeholder: "الساعة بنظام 24 ساعة (مثال: 22:30)",
                            placeholderTextColor: "#72767D",
                            style: inputStyle
                        }) : null
                    ),

                    // Action Buttons
                    !job.running ? R.createElement(
                        View,
                        { style: { gap: 8 } },
                        R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () {
                                    persistAll();
                                    startAutoSend({
                                        channelId: channelId,
                                        messageText: messageText,
                                        rateMode: rateMode,
                                        intervalSec: intervalSec,
                                        perSecond: perSecond,
                                        countMode: countMode,
                                        totalCount: totalCount,
                                        scheduleMode: scheduleMode,
                                        delayMinutes: delayMinutes,
                                        clockTime: clockTime
                                    }, true);
                                },
                                style: btnStyle("#248046", { paddingVertical: 14 })
                            },
                            R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 15 } }, "🚀 بدء الإرسال التلقائي")
                        ),
                        R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () {
                                    persistAll();
                                    showToast("تم حفظ الإعدادات بنجاح");
                                },
                                style: btnStyle("#4E5058")
                            },
                            R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, "💾 حفظ الإعدادات")
                        )
                    ) : null,

                    // Chat Commands Guide
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "⚡ الأوامر السريعة من داخل الشات"
                        ),
                        R.createElement(
                            Text,
                            { style: { fontSize: 13, color: "#DBDEE1", textAlign: "right", lineHeight: 22 } },
                            "• !تلقائي 5 10 السلام عليكم  ←  إرسال 5 رسائل كل 10 ثوانٍ\n" +
                            "• !ايقاف_تلقائي  ←  إيقاف الإرسال فوراً\n" +
                            "• !حالة_تلقائي  ←  عرض حالة الإرسال الحالي\n" +
                            "• !تلقائي مساعدة  ←  عرض المساعدة محلياً"
                        )
                    )
                )
            );
        }
    });

    return exports;
})({});
