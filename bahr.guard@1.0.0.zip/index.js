(function (exports) {
    "use strict";

    /*
     * حارس بحر (bahr.guard)
     * ---------------------
     * يفحص الرسائل التي حمّلها العميل فعلاً (رسائل جديدة + الرسائل المعروضة)
     * ويصنّفها بالذكاء الاصطناعي أو بالكشف المحلي، ثم يعرض مكان الرسالة
     * ومسار الإبلاغ المناسب داخل ديسكورد.
     *
     * قواعد أمان ثابتة:
     *  - لا إبلاغ تلقائي (الإبلاغ يدوي من المستخدم دائماً).
     *  - لا جلب جماعي لسجل الرسائل (لا طلبات API لديسكورد إطلاقاً).
     *  - النصوص فقط؛ المرفقات والصور لا تُنزَّل ولا تُرسل لأي جهة.
     */

    // ===================== الإعدادات =====================
    var DEFAULTS = {
        enabled: true,
        provider: "local",        // "local" | "openai" | "gemini"
        openaiKey: "",
        geminiKey: "",
        geminiModel: "gemini-2.5-flash",
        threshold: 0.5,           // عتبة الحساسية (0..1)
        scanNew: true,            // فحص الرسائل الجديدة
        scanLoaded: true,         // فحص الرسائل عند تحميل الروم
        localAlways: true,        // تشغيل الكشف المحلي مع الذكاء الاصطناعي
        skipOwn: true,            // تجاهل رسائلي
        toast: true,              // تنبيه منبثق
        inChatNotice: true,       // تنبيه محلي داخل الروم المفتوح
        findings: []
    };

    var cfg = JSON.parse(JSON.stringify(DEFAULTS));
    var storageRef = null;
    var MAX_FINDINGS = 250;
    var BATCH_SIZE = 16;
    var REQUEST_GAP_MS = 1200;
    var MAX_TEXT = 1500;
    var NOTICE_AUTHOR_ID = "1";

    var mods = {
        UserStore: null,
        ChannelStore: null,
        GuildStore: null,
        SelectedChannelStore: null,
        MessageStore: null,
        MessageActions: null,
        Dispatcher: null,
        Toast: null,
        Router: null,
        URLOpener: null,
        Clipboard: null
    };

    var state = {
        queued: 0,
        scanned: 0,
        flagged: 0,
        lastError: "",
        busy: false
    };

    // ===================== أدوات عامة =====================
    var listeners = [];
    function emitState() {
        for (var i = 0; i < listeners.length; i++) {
            try { listeners[i](); } catch (e) {}
        }
    }
    function subscribeState(fn) {
        listeners.push(fn);
        return function () {
            var idx = listeners.indexOf(fn);
            if (idx !== -1) listeners.splice(idx, 1);
        };
    }

    function getReact() {
        return (typeof valenced !== "undefined" && valenced.react && (valenced.react.React || valenced.react)) || null;
    }
    function getRN() {
        return (typeof valenced !== "undefined" && valenced.react && valenced.react.ReactNative) || null;
    }
    function sleep(ms) {
        return new Promise(function (resolve) { setTimeout(resolve, ms); });
    }

    function saveCfg(patch) {
        for (var k in patch) {
            if (Object.prototype.hasOwnProperty.call(patch, k)) cfg[k] = patch[k];
        }
        if (storageRef && typeof storageRef.set === "function") {
            try { storageRef.set(patch); } catch (e) {}
        }
        emitState();
    }

    function showToast(text) {
        try {
            if (mods.Toast && typeof mods.Toast.showToast === "function") {
                mods.Toast.showToast(String(text));
                return;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.ToastAndroid && typeof RN.ToastAndroid.show === "function") {
                RN.ToastAndroid.show(String(text), RN.ToastAndroid.LONG);
            }
        } catch (e) {}
    }

    function copyText(text) {
        try {
            if (mods.Clipboard && typeof mods.Clipboard.setString === "function") {
                mods.Clipboard.setString(text);
                return true;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.Clipboard && typeof RN.Clipboard.setString === "function") {
                RN.Clipboard.setString(text);
                return true;
            }
        } catch (e) {}
        return false;
    }

    function getMyUserId() {
        try {
            if (mods.UserStore && typeof mods.UserStore.getCurrentUser === "function") {
                var u = mods.UserStore.getCurrentUser();
                if (u && u.id) return String(u.id);
            }
        } catch (e) {}
        return null;
    }

    function getCurrentChannelId() {
        try {
            if (mods.SelectedChannelStore && typeof mods.SelectedChannelStore.getChannelId === "function") {
                return mods.SelectedChannelStore.getChannelId() || "";
            }
        } catch (e) {}
        return "";
    }

    function getChannelInfo(channelId) {
        var info = { channelId: channelId || "", guildId: null, guildName: "", channelName: "", typeLabel: "قناة" };
        if (!channelId) return info;
        var ch = null;
        try {
            if (mods.ChannelStore && typeof mods.ChannelStore.getChannel === "function") ch = mods.ChannelStore.getChannel(channelId);
        } catch (e) {}
        if (!ch) { info.channelName = "قناة " + channelId; return info; }
        info.guildId = ch.guild_id || ch.guildId || null;
        if (ch.type === 1) { info.typeLabel = "خاص"; info.channelName = "محادثة خاصة"; }
        else if (ch.type === 3) { info.typeLabel = "قروب"; info.channelName = ch.name || "قروب خاص"; }
        else if (ch.type === 11 || ch.type === 12 || ch.type === 10) { info.typeLabel = "ثريد"; info.channelName = ch.name ? ("🧵 " + ch.name) : channelId; }
        else { info.typeLabel = "سيرفر"; info.channelName = ch.name ? ("#" + ch.name) : channelId; }
        try {
            if (info.guildId && mods.GuildStore && typeof mods.GuildStore.getGuild === "function") {
                var g = mods.GuildStore.getGuild(info.guildId);
                if (g && g.name) info.guildName = g.name;
            }
        } catch (e) {}
        return info;
    }

    function messageLink(f) {
        return "https://discord.com/channels/" + (f.guildId || "@me") + "/" + f.channelId + "/" + f.messageId;
    }

    function jumpToMessage(f) {
        var path = "/channels/" + (f.guildId || "@me") + "/" + f.channelId + "/" + f.messageId;
        var url = "https://discord.com" + path;
        try {
            if (mods.Router && typeof mods.Router.transitionTo === "function") {
                mods.Router.transitionTo(path);
                return true;
            }
        } catch (e) {}
        try {
            if (mods.URLOpener && typeof mods.URLOpener.openURL === "function") {
                mods.URLOpener.openURL(url);
                return true;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.Linking && typeof RN.Linking.openURL === "function") {
                RN.Linking.openURL(url);
                return true;
            }
        } catch (e) {}
        return false;
    }

    function openExternal(url) {
        try {
            var RN = getRN();
            if (RN && RN.Linking) RN.Linking.openURL(url);
        } catch (e) {}
    }

    // ===================== التصنيفات ومسارات الإبلاغ =====================
    // كل تصنيف: الاسم العربي، الخطورة (أعلى = أخطر)، ومسار الإبلاغ داخل قائمة الإبلاغ المعرّبة.
    var CATS = {
        "sexual/minors": {
            label: "استغلال جنسي للأطفال (CSAM)",
            severity: 100,
            color: "#FF0033",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "سلامة الأطفال / استغلال جنسي لقاصر"],
            extra: "⚠️ لا تفتح أو تحفظ أو تصوّر أو تشارك أي مرفق. بلّغ ديسكورد، وبلّغ أيضاً مركز NCMEC عبر report.cybertip.org. وبلّغ عن السيرفر نفسه.",
            hideSnippet: true
        },
        "self-harm": {
            label: "إيذاء النفس / انتحار",
            severity: 90,
            color: "#E67E22",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "إيذاء النفس"],
            extra: "إن كان الشخص في خطر حقيقي فتواصل معه بلطف ووجّهه لخط مساعدة: findahelpline.com"
        },
        "violence": {
            label: "تهديد / عنف / تمجيد إرهاب",
            severity: 80,
            color: "#C0392B",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "معلومات مضللة ضارة أو تمجيد العنف"]
        },
        "illicit": {
            label: "محتوى غير قانوني / بيع ممنوعات",
            severity: 70,
            color: "#8E44AD",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "بيع سلع أو خدمات غير قانونية"]
        },
        "hate": {
            label: "خطاب كراهية",
            severity: 60,
            color: "#D35400",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "إساءة أو مضايقة", "خطاب كراهية"]
        },
        "harassment": {
            label: "إساءة / مضايقة / سب",
            severity: 50,
            color: "#E74C3C",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "إساءة أو مضايقة"]
        },
        "sexual": {
            label: "محتوى جنسي / إباحي",
            severity: 55,
            color: "#E91E63",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "عري أو محتوى جنسي"]
        },
        "scam": {
            label: "احتيال / تصيّد / سبام",
            severity: 45,
            color: "#F1C40F",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "رسائل مزعجة (سبام)"],
            extra: "لا تضغط على الرابط ولا تدخل بيانات حسابك."
        },
        "doxxing": {
            label: "نشر معلومات شخصية (تشهير)",
            severity: 40,
            color: "#3498DB",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "كشف معلومات شخصية خاصة"]
        },
        "blocked": {
            label: "محتوى رفض الذكاء الاصطناعي تحليله (مشبوه جداً)",
            severity: 85,
            color: "#FF5555",
            steps: ["افتح الرسالة بحذر وراجعها بنفسك", "إن تأكدت: اضغط مطولاً ← إبلاغ ← اختر النوع المناسب"],
            extra: "Gemini حجب الرد لأن النص يحوي محتوى محظوراً بشدة. لا تفتح المرفقات."
        }
    };

    // ربط تصنيفات OpenAI بتصنيفاتنا
    var OPENAI_MAP = {
        "sexual/minors": "sexual/minors",
        "self-harm": "self-harm",
        "self-harm/intent": "self-harm",
        "self-harm/instructions": "self-harm",
        "violence": "violence",
        "violence/graphic": "violence",
        "harassment/threatening": "violence",
        "hate/threatening": "violence",
        "illicit": "illicit",
        "illicit/violent": "illicit",
        "hate": "hate",
        "harassment": "harassment",
        "sexual": "sexual"
    };

    // ===================== الكشف المحلي =====================
    var OFFICIAL_DOMAINS = /^(?:[a-z0-9-]+\.)*(discord\.com|discord\.gg|discordapp\.com|discordapp\.net|discord\.media|discord\.new|discord\.gift|discordstatus\.com|steampowered\.com|steamcommunity\.com|tenor\.com|giphy\.com|youtube\.com|youtu\.be|google\.com)$/i;
    var LOOKALIKE = /(d[i1l!|][s5$][ckq][o0][r][dcl]|disc[o0]rd|dlscord|discrod|d1scord|nitr[o0]|st[e3]am|ste[a@]m)/i;
    var URL_RE = /https?:\/\/([^\s\/<>"']+)/gi;

    var RULES = [
        { cat: "sexual/minors", score: 0.9, re: /(child\s*porn|\bcp\s*(link|vid|pack|sell|trade|for sale)|pedo\s*(link|pack|vid)|preteen\s*(nude|sex)|underage\s*(nude|sex|porn)|loli\s*(porn|nude|sex|hentai)|\bjailbait\b|اباحية\s*اطفال|إباحية\s*أطفال|سكس\s*(اطفال|أطفال|قاصر|قاصرات)|صور\s*(اطفال|قاصرات)\s*(عاري|عارية|سكس))/i },
        { cat: "self-harm", score: 0.75, re: /(\bkill\s*my\s*self\b|\bkms\b|\bsuicide\b|want\s*to\s*die|cut\s*my\s*self|ابي\s*انتحر|أبي\s*أنتحر|بنتحر|سأنتحر|راح\s*انتحر|اريد\s*الانتحار|أريد\s*الانتحار|اقتل\s*نفسي|أقتل\s*نفسي|اذبح\s*نفسي)/i },
        { cat: "violence", score: 0.75, re: /(i\s*(will|'ll|am\s*going\s*to)\s*(kill|shoot|stab)\s*(you|u)|bomb\s*(the|a)\s*(school|mosque|church)|سأقتلك|راح\s*اقتلك|بقتلك|والله\s*لاقتلك|بذبحك|راح\s*اذبحك|سأذبحك|بفجر|تفجير\s*(مدرسة|مسجد|كنيسة))/i },
        { cat: "illicit", score: 0.7, re: /((weed|cocaine|coke|meth|mdma|xanax|lsd|heroin|ecstasy)\s*(for\s*sale|dm\s*me|available|plug)|selling\s*(weed|coke|meth|drugs|guns|accounts|cc\b)|\bcc\s*dumps?\b|(حشيش|مخدرات|كبتاجون|كبتاغون|شبو|كريستال|ترامادول|سلاح|اسلحة|أسلحة)\s*(للبيع|متوفر|متوفرة|توصيل)|بيع\s*(حشيش|مخدرات|كبتاجون|حسابات\s*مسروقة|فيزا\s*مسروقة))/i },
        { cat: "sexual", score: 0.6, re: /(\bporn(hub)?\b|\bxvideos\b|\bxnxx\b|onlyfans\s*(leak|leaks|free)|\bnudes?\s*(leak|pack|for\s*sale|dm)|\bnsfw\s*(link|leak)|سكس|نيك|افلام\s*اباحية|أفلام\s*إباحية|مقاطع\s*اباحية|صور\s*عارية|محارم)/i },
        { cat: "scam", score: 0.7, re: /(free\s*nitro|nitro\s*(for\s*)?free|claim\s*(your\s*)?(nitro|gift|reward)|steam\s*gift|\$\d+\s*steam|airdrop|crypto\s*giveaway|نيترو\s*مجان|نيترو\s*ببلاش|هدية\s*ستيم|اربح\s*نيترو)/i },
        { cat: "hate", score: 0.6, re: /(\bn[i1]gg(er|a)s?\b|\bfaggots?\b|\bkikes?\b|gas\s*the\s*jews|يا\s*(عبد|عبيد)\b|يا\s*زنجي|الله\s*يلعن\s*(دينك|دين\s*ابوك|دين\s*أبوك))/i },
        { cat: "harassment", score: 0.55, re: /(\bkys\b|kill\s*yourself|يا\s*(كلب|حمار|خنزير|حيوان|منيوك|قحبة|شرموط|شرموطة|عاهر|عاهرة|ديوث|لوطي)|ابن\s*(القحبة|الكلب|الشرموطة)|كس\s*(امك|أمك|اختك|أختك))/i }
    ];

    var DOX_CONTEXT = /(رقمه|رقمها|رقم\s*(جواله|جوالها|تلفونه|هاتفه|هاتفها)|عنوانه|عنوانها|ساكن|ساكنة|يسكن|تسكن|بيته|بيتها|\bdox(x)?(ed|ing)?\b|home\s*address|his\s*address|her\s*address|lives\s*at|ip\s*:?)/i;
    var PHONE_RE = /(\+?\d[\d\s\-]{8,}\d)/;
    var IP_RE = /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/;

    function localDetect(text) {
        var hits = [];
        if (!text) return hits;
        for (var i = 0; i < RULES.length; i++) {
            if (RULES[i].re.test(text)) hits.push({ cat: RULES[i].cat, score: RULES[i].score, reason: "كلمات مطابقة (كشف محلي)" });
        }
        // روابط مقلّدة لديسكورد/ستيم
        var m;
        URL_RE.lastIndex = 0;
        while ((m = URL_RE.exec(text)) !== null) {
            var host = String(m[1] || "").toLowerCase().split(":")[0];
            if (!OFFICIAL_DOMAINS.test(host) && LOOKALIKE.test(host)) {
                hits.push({ cat: "scam", score: 0.9, reason: "رابط مقلّد: " + host });
                break;
            }
        }
        // تشهير: رقم هاتف أو IP مع سياق شخصي
        if ((PHONE_RE.test(text) || IP_RE.test(text)) && DOX_CONTEXT.test(text)) {
            hits.push({ cat: "doxxing", score: 0.65, reason: "رقم/عنوان مع سياق شخصي" });
        }
        return hits;
    }

    // ===================== مزوّدات الذكاء الاصطناعي =====================
    function openaiModerate(texts) {
        return fetch("https://api.openai.com/v1/moderations", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + cfg.openaiKey
            },
            body: JSON.stringify({ model: "omni-moderation-latest", input: texts })
        }).then(function (r) {
            return r.json().then(function (j) {
                if (!r.ok) throw new Error((j && j.error && j.error.message) || ("HTTP " + r.status));
                return j;
            });
        }).then(function (j) {
            var out = [];
            var results = (j && j.results) || [];
            for (var i = 0; i < texts.length; i++) {
                var res = results[i] || {};
                var scores = res.category_scores || {};
                var flags = res.categories || {};
                var hits = [];
                var seen = {};
                for (var k in OPENAI_MAP) {
                    if (!Object.prototype.hasOwnProperty.call(OPENAI_MAP, k)) continue;
                    var s = Number(scores[k] || 0);
                    var limit = k === "sexual/minors" ? Math.min(cfg.threshold, 0.3) : cfg.threshold;
                    if (flags[k] === true || s >= limit) {
                        var our = OPENAI_MAP[k];
                        if (!seen[our] || seen[our].score < s) {
                            seen[our] = { cat: our, score: s, reason: "OpenAI: " + k + " (" + Math.round(s * 100) + "%)" };
                        }
                    }
                }
                for (var c in seen) if (Object.prototype.hasOwnProperty.call(seen, c)) hits.push(seen[c]);
                out.push(hits);
            }
            return out;
        });
    }

    var GEMINI_CATS = ["sexual/minors", "self-harm", "violence", "illicit", "hate", "harassment", "sexual", "scam", "doxxing"];

    function geminiModerate(texts) {
        var listing = texts.map(function (t, i) {
            return i + ": " + JSON.stringify(t);
        }).join("\n");
        var prompt =
            "You are a strict content-safety classifier for a Discord community. " +
            "Classify each numbered message. Allowed categories: " + GEMINI_CATS.join(", ") + ". " +
            "scam = phishing, fake nitro/steam gifts, crypto scams. doxxing = sharing someone's private phone/address/IP. " +
            "Messages may be Arabic, English or any language; judge meaning, not single words. Ordinary jokes or mild slang are NOT violations. " +
            "Return ONLY JSON array: [{\"i\":index,\"cats\":[...],\"score\":0..1,\"reason\":\"short Arabic reason\"}] including only violating messages. " +
            "Return [] if none.\n\nMessages:\n" + listing;

        var url = "https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(cfg.geminiModel || "gemini-2.5-flash") + ":generateContent";
        return fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": cfg.geminiKey },
            body: JSON.stringify({
                contents: [{ role: "user", parts: [{ text: prompt }] }],
                generationConfig: { temperature: 0, responseMimeType: "application/json" },
                safetySettings: [
                    { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
                ]
            })
        }).then(function (r) {
            return r.json().then(function (j) {
                if (!r.ok) throw new Error((j && j.error && j.error.message) || ("HTTP " + r.status));
                return j;
            });
        }).then(function (j) {
            var out = texts.map(function () { return []; });
            var blocked = (j && j.promptFeedback && j.promptFeedback.blockReason) ||
                (j && j.candidates && j.candidates[0] && (j.candidates[0].finishReason === "SAFETY" || j.candidates[0].finishReason === "PROHIBITED_CONTENT") && j.candidates[0].finishReason);
            if (blocked) {
                var err = new Error("BLOCKED");
                err.blocked = String(blocked);
                throw err;
            }
            var txt = "";
            try { txt = j.candidates[0].content.parts.map(function (p) { return p.text || ""; }).join(""); } catch (e) {}
            var arr = [];
            try { arr = JSON.parse(txt); } catch (e) {
                var mm = txt.match(/\[[\s\S]*\]/);
                if (mm) { try { arr = JSON.parse(mm[0]); } catch (e2) {} }
            }
            if (!Array.isArray(arr)) arr = [];
            for (var a = 0; a < arr.length; a++) {
                var it = arr[a] || {};
                var idx = Number(it.i);
                if (!(idx >= 0 && idx < texts.length)) continue;
                var sc = Number(it.score);
                if (!(sc >= 0)) sc = 0.8;
                if (sc < cfg.threshold && !(Array.isArray(it.cats) && it.cats.indexOf("sexual/minors") !== -1)) continue;
                var cats = Array.isArray(it.cats) ? it.cats : [];
                for (var c = 0; c < cats.length; c++) {
                    if (CATS[cats[c]]) out[idx].push({ cat: cats[c], score: sc, reason: "Gemini: " + (it.reason || cats[c]) });
                }
            }
            return out;
        });
    }

    // ===================== الطابور =====================
    var seenIds = {};
    var seenOrder = [];
    var queue = [];
    var running = false;
    var stopped = false;

    function markSeen(id) {
        if (seenIds[id]) return;
        seenIds[id] = 1;
        seenOrder.push(id);
        if (seenOrder.length > 8000) {
            var old = seenOrder.splice(0, 2000);
            for (var i = 0; i < old.length; i++) delete seenIds[old[i]];
        }
    }

    function extractText(msg) {
        var parts = [];
        if (typeof msg.content === "string" && msg.content) parts.push(msg.content);
        var embeds = msg.embeds || [];
        for (var i = 0; i < embeds.length && i < 3; i++) {
            var e = embeds[i] || {};
            if (e.title || e.rawTitle) parts.push(String(e.title || e.rawTitle));
            if (e.description || e.rawDescription) parts.push(String(e.description || e.rawDescription));
        }
        var t = parts.join("\n").trim();
        if (t.length > MAX_TEXT) t = t.slice(0, MAX_TEXT);
        return t;
    }

    function authorOf(msg) {
        var a = msg.author || {};
        return {
            id: String(a.id || ""),
            name: a.globalName || a.global_name || a.username || "مجهول",
            username: a.username || "",
            bot: !!a.bot
        };
    }

    function enqueueMessage(msg, channelId, force) {
        try {
            if (stopped || !cfg.enabled || !msg || !msg.id) return false;
            if (msg._bahrGuard) return false;
            var a = authorOf(msg);
            if (a.id === NOTICE_AUTHOR_ID) return false;
            if (cfg.skipOwn && a.id && a.id === getMyUserId()) return false;
            var id = String(msg.id);
            if (!force && seenIds[id]) return false;
            markSeen(id);
            var text = extractText(msg);
            var hasAttach = Array.isArray(msg.attachments) && msg.attachments.length > 0;
            if (!text) return false; // المرفقات وحدها لا تُحلَّل
            var chId = String(channelId || msg.channel_id || msg.channelId || "");
            var item = {
                messageId: id,
                channelId: chId,
                author: a,
                text: text,
                hasAttach: hasAttach,
                ts: msg.timestamp ? String(msg.timestamp) : new Date().toISOString()
            };

            var hasAiKey = (cfg.provider === "openai" && !!cfg.openaiKey) || (cfg.provider === "gemini" && !!cfg.geminiKey);
            // الكشف المحلي فوري عند اختياره، أو عند تفعيل localAlways، أو كبديل عند عدم حفظ مفتاح AI
            if (cfg.provider === "local" || cfg.localAlways || !hasAiKey) {
                var lh = localDetect(text);
                if (lh.length) recordFinding(item, lh, "محلي");
            }
            if (hasAiKey) { queue.push(item); }
            else { state.scanned++; }
            state.queued = queue.length;
            emitState();
            pump();
            return true;
        } catch (e) {
            return false;
        }
    }

    function pump() {
        if (running || stopped || queue.length === 0) return;
        running = true;
        state.busy = true;
        emitState();
        var loop = function () {
            if (stopped || queue.length === 0 || !cfg.enabled) {
                running = false;
                state.busy = false;
                state.queued = queue.length;
                emitState();
                return;
            }
            var takeCount = (queue[0] && queue[0]._single) ? 1 : BATCH_SIZE;
            var batch = queue.splice(0, takeCount);
            state.queued = queue.length;
            var texts = batch.map(function (b) { return b.text; });
            var activeProvider = cfg.provider;
            var p = activeProvider === "gemini" ? geminiModerate(texts) : openaiModerate(texts);
            p.then(function (results) {
                state.lastError = "";
                for (var i = 0; i < batch.length; i++) {
                    state.scanned++;
                    var hits = results[i] || [];
                    if (hits.length) recordFinding(batch[i], hits, activeProvider === "gemini" ? "Gemini" : "OpenAI");
                }
            }).catch(function (err) {
                if (err && err.blocked) {
                    if (batch.length > 1) {
                        // قسّم الدفعة لمعرفة الرسالة المحجوبة بالضبط
                        for (var b = batch.length - 1; b >= 0; b--) { batch[b]._single = true; queue.unshift(batch[b]); }
                    } else {
                        state.scanned++;
                        recordFinding(batch[0], [{ cat: "blocked", score: 1, reason: "Gemini حجب التحليل: " + err.blocked }], "Gemini");
                    }
                } else {
                    state.lastError = String((err && err.message) || err);
                    if (/429|rate|quota/i.test(state.lastError)) {
                        var requeued = false;
                        for (var q = batch.length - 1; q >= 0; q--) {
                            batch[q]._retries = (batch[q]._retries || 0) + 1;
                            if (batch[q]._retries <= 3) {
                                queue.unshift(batch[q]);
                                requeued = true;
                            }
                        }
                        if (requeued) return sleep(15000);
                    }
                    state.scanned += batch.length;
                }
            }).then(function () {
                emitState();
                return sleep(REQUEST_GAP_MS);
            }).then(loop, loop);
        };
        loop();
    }

    // ===================== تسجيل النتائج =====================
    function pickPrimary(hits) {
        var best = null;
        for (var i = 0; i < hits.length; i++) {
            var c = CATS[hits[i].cat];
            if (!c) continue;
            if (!best || c.severity > CATS[best.cat].severity || (c.severity === CATS[best.cat].severity && hits[i].score > best.score)) best = hits[i];
        }
        return best;
    }

    function recordFinding(item, hits, source) {
        var primary = pickPrimary(hits);
        if (!primary) return;
        var list = cfg.findings || [];
        for (var i = 0; i < list.length; i++) {
            if (list[i].messageId === item.messageId) {
                // حدّث إن كان التصنيف الجديد أخطر
                if (CATS[primary.cat].severity > (CATS[list[i].cat] ? CATS[list[i].cat].severity : 0)) {
                    list[i].cat = primary.cat;
                    list[i].score = primary.score;
                    list[i].reason = primary.reason;
                    list[i].source = source;
                    saveCfg({ findings: list.slice() });
                }
                return;
            }
        }
        var info = getChannelInfo(item.channelId);
        var cat = CATS[primary.cat];
        var snippet;
        if (cat.hideSnippet) {
            snippet = "[النص مخفي لحمايتك]";
        } else {
            var rawSnippet = item.text.replace(/\s+/g, " ").slice(0, 160);
            if (primary.cat === "doxxing") {
                rawSnippet = rawSnippet
                    .replace(/\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g, "[IP مخفي]")
                    .replace(/\+?\d[\d\s\-]{8,}\d/g, "[رقم مخفي]");
            }
            snippet = rawSnippet;
        }
        var f = {
            messageId: item.messageId,
            channelId: item.channelId,
            guildId: info.guildId,
            guildName: info.guildName,
            channelName: info.channelName,
            typeLabel: info.typeLabel,
            authorId: item.author.id,
            authorName: item.author.name,
            authorUsername: item.author.username,
            authorBot: item.author.bot,
            ts: item.ts,
            cat: primary.cat,
            allCats: hits.map(function (h) { return h.cat; }).filter(function (v, idx, arr) { return arr.indexOf(v) === idx; }),
            score: primary.score,
            reason: primary.reason,
            source: source,
            snippet: snippet,
            hasAttach: item.hasAttach,
            foundAt: Date.now()
        };
        list = [f].concat(list).slice(0, MAX_FINDINGS);
        state.flagged++;
        saveCfg({ findings: list });

        var where = (info.guildName ? info.guildName + " / " : "") + info.channelName;
        if (cfg.toast) showToast("🛡️ حارس بحر: " + cat.label + " — " + where);
        if (cfg.inChatNotice && item.channelId && item.channelId === getCurrentChannelId()) {
            postLocalNotice(item.channelId, f);
        }
    }

    function postLocalNotice(channelId, f) {
        var cat = CATS[f.cat];
        var content =
            "🛡️ **حارس بحر** رصد رسالة مشبوهة من **" + f.authorName + "**\n" +
            "النوع: **" + cat.label + "**\n" +
            "طريقة الإبلاغ: " + cat.steps.join(" ← ") +
            (cat.extra ? "\n" + cat.extra : "") +
            "\n" + messageLink(f) +
            "\n-# (هذا التنبيه يظهر لك وحدك ولا يُرسل لأحد)";
        var msgObj = {
            id: String(Date.now()) + String(Math.floor(Math.random() * 1000)),
            type: 0,
            channel_id: channelId,
            content: content,
            timestamp: new Date().toISOString(),
            edited_timestamp: null,
            tts: false,
            mention_everyone: false,
            mentions: [],
            mention_roles: [],
            attachments: [],
            embeds: [],
            pinned: false,
            flags: 64,
            state: "SENT",
            _bahrGuard: true,
            author: {
                id: NOTICE_AUTHOR_ID,
                username: "حارس بحر",
                global_name: "حارس بحر 🛡️",
                discriminator: "0000",
                avatar: null,
                bot: true
            }
        };
        setTimeout(function () {
            try {
                if (mods.MessageActions && typeof mods.MessageActions.receiveMessage === "function") {
                    mods.MessageActions.receiveMessage(channelId, msgObj);
                    return;
                }
            } catch (e) {}
            try {
                if (mods.Dispatcher) {
                    mods.Dispatcher.dispatch({ type: "MESSAGE_CREATE", channelId: channelId, message: msgObj, optimistic: false, isPushNotification: false, _bahrGuard: true });
                }
            } catch (e) {}
        }, 300);
    }

    function scanChannel(channelId, force) {
        var n = 0;
        try {
            if (!mods.MessageStore || !channelId) return 0;
            var msgs = mods.MessageStore.getMessages(channelId);
            var arr = msgs && (msgs._array || (typeof msgs.toArray === "function" ? msgs.toArray() : null));
            if (!Array.isArray(arr)) return 0;
            for (var i = 0; i < arr.length; i++) {
                if (enqueueMessage(arr[i], channelId, force)) n++;
            }
        } catch (e) {}
        return n;
    }

    // ===================== التشغيل =====================
    exports.default = plugin({
        jsonStorage: {
            load: true,
            default: JSON.parse(JSON.stringify(DEFAULTS))
        },
        start: function (ctx) {
            stopped = false;
            var cleanup = ctx.cleanup;
            var finders = valenced.modules.finders;
            var filters = finders.filters;
            var patcher = valenced.patcher;

            storageRef = ctx.jsonStorage || null;
            var applyLoaded = function (c) {
                if (!c || typeof c !== "object") return;
                for (var k in DEFAULTS) {
                    if (Object.prototype.hasOwnProperty.call(DEFAULTS, k) && c[k] !== undefined && typeof c[k] === typeof DEFAULTS[k]) {
                        cfg[k] = c[k];
                    }
                }
                if (!Array.isArray(cfg.findings)) cfg.findings = [];
                for (var i = 0; i < cfg.findings.length; i++) markSeen(cfg.findings[i].messageId);
                emitState();
            };
            if (storageRef) {
                if (storageRef.cache) applyLoaded(storageRef.cache);
                if (typeof storageRef.get === "function") {
                    Promise.resolve(storageRef.get()).then(applyLoaded).catch(function () {});
                }
            }

            try {
                var d = valenced.discord;
                if (d) {
                    if (d.common && d.common.flux && d.common.flux.Dispatcher) mods.Dispatcher = d.common.flux.Dispatcher;
                    if (d.flux && d.flux.Stores) {
                        var S = d.flux.Stores;
                        if (S.UserStore) mods.UserStore = S.UserStore;
                        if (S.ChannelStore) mods.ChannelStore = S.ChannelStore;
                        if (S.GuildStore) mods.GuildStore = S.GuildStore;
                        if (S.SelectedChannelStore) mods.SelectedChannelStore = S.SelectedChannelStore;
                        if (S.MessageStore) mods.MessageStore = S.MessageStore;
                    }
                }
            } catch (e) {}

            var take = function (key, props, check) {
                try {
                    cleanup(finders.getModules(filters.withProps.apply(null, props), function (m) {
                        if (!m) return;
                        if (check && !check(m)) return;
                        if (!mods[key]) mods[key] = m;
                    }));
                } catch (e) {}
            };
            take("UserStore", ["getCurrentUser", "getUser"]);
            take("ChannelStore", ["getChannel", "getDMFromUserId"]);
            take("GuildStore", ["getGuild", "getGuilds"]);
            take("SelectedChannelStore", ["getChannelId", "getVoiceChannelId"]);
            take("MessageStore", ["getMessage", "getMessages"]);
            take("Toast", ["showToast"]);
            take("MessageActions", ["sendMessage", "receiveMessage"]);
            take("Router", ["transitionTo"], function (m) { return typeof m.transitionTo === "function"; });
            take("URLOpener", ["openURL"], function (m) { return typeof m.openURL === "function"; });
            take("Clipboard", ["setString", "getString"]);

            var hooked = false;
            var hook = function (fd) {
                if (hooked || !fd || typeof fd.dispatch !== "function") return;
                hooked = true;
                mods.Dispatcher = fd;
                try {
                    cleanup(patcher.before(fd, "dispatch", function (args) {
                        try {
                            if (stopped || !cfg.enabled) return args;
                            var action = Array.isArray(args) ? args[0] : args;
                            if (!action || action._bahrGuard || action._arTranslated) return args;
                            if (action.type === "MESSAGE_CREATE" && action.message && cfg.scanNew && !action.optimistic) {
                                var m = action.message;
                                var cid = action.channelId || m.channel_id || m.channelId;
                                setTimeout(function () { enqueueMessage(m, cid, false); }, 0);
                            } else if (action.type === "LOAD_MESSAGES_SUCCESS" && Array.isArray(action.messages) && cfg.scanLoaded) {
                                var list = action.messages.slice();
                                var lcid = action.channelId;
                                setTimeout(function () {
                                    for (var i = 0; i < list.length; i++) enqueueMessage(list[i], lcid || (list[i] && list[i].channel_id), false);
                                }, 0);
                            }
                        } catch (e) {}
                        return args;
                    }));
                } catch (e) {}
            };
            if (mods.Dispatcher) hook(mods.Dispatcher);
            try {
                cleanup(finders.getModules(filters.withProps("_interceptors", "dispatch"), function (m) { hook(m); }));
            } catch (e) {}

            cleanup(function () {
                stopped = true;
                queue.length = 0;
                state.queued = 0;
                state.busy = false;
            });
        },

        // ===================== واجهة الإعدادات =====================
        SettingsComponent: function (props) {
            var R = getReact();
            var RN = getRN();
            if (!R || !RN) return null;
            if (!storageRef && props && props.api && props.api.jsonStorage) {
                storageRef = props.api.jsonStorage;
            }
            var View = RN.View, Text = RN.Text, ScrollView = RN.ScrollView, TouchableOpacity = RN.TouchableOpacity, TextInput = RN.TextInput;
            var h = R.createElement;

            var tick = R.useState(0);
            R.useEffect(function () {
                return subscribeState(function () { tick[1](function (n) { return n + 1; }); });
            }, []);

            var filterState = R.useState("all");
            var filter = filterState[0], setFilter = filterState[1];
            var keyDraft = R.useState(null);
            var expanded = R.useState(null);
            var testState = R.useState("");
            var testStatus = testState[0], setTestStatus = testState[1];

            var card = { backgroundColor: "#2B2D31", borderRadius: 10, padding: 14, gap: 10 };
            var title = { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" };
            var small = { fontSize: 12, color: "#B5BAC1", textAlign: "right" };
            function btn(bg, extra) {
                return Object.assign({ backgroundColor: bg, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8, alignItems: "center", justifyContent: "center" }, extra || {});
            }
            function button(label, bg, onPress, extra) {
                return h(TouchableOpacity, { onPress: onPress, style: btn(bg, extra) }, h(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 13 } }, label));
            }
            function toggle(label, key, hint) {
                var on = !!cfg[key];
                return h(TouchableOpacity, {
                    key: key,
                    onPress: function () { var p = {}; p[key] = !on; saveCfg(p); },
                    style: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingVertical: 6 }
                },
                    h(View, { style: { flex: 1 } },
                        h(Text, { style: { color: "#FFFFFF", fontSize: 14, textAlign: "right" } }, label),
                        hint ? h(Text, { style: small }, hint) : null
                    ),
                    h(View, { style: { width: 46, height: 26, borderRadius: 13, backgroundColor: on ? "#23A55A" : "#4E5058", justifyContent: "center", padding: 3 } },
                        h(View, { style: { width: 20, height: 20, borderRadius: 10, backgroundColor: "#FFFFFF", alignSelf: on ? "flex-start" : "flex-end" } })
                    )
                );
            }
            function chip(label, active, onPress, key) {
                return h(TouchableOpacity, { key: key || label, onPress: onPress, style: btn(active ? "#5865F2" : "#1E1F22", { paddingVertical: 8, marginLeft: 6, marginBottom: 6 }) },
                    h(Text, { style: { color: "#FFFFFF", fontSize: 12, fontWeight: active ? "bold" : "normal" } }, label));
            }

            var providerKeyName = cfg.provider === "gemini" ? "geminiKey" : "openaiKey";
            var currentKey = cfg[providerKeyName] || "";
            var draft = keyDraft[0] !== null ? keyDraft[0] : "";

            var findings = cfg.findings || [];
            var counts = {};
            for (var i = 0; i < findings.length; i++) counts[findings[i].cat] = (counts[findings[i].cat] || 0) + 1;
            var shown = filter === "all" ? findings : findings.filter(function (f) { return f.cat === filter; });

            var curCh = getCurrentChannelId();
            var curInfo = curCh ? getChannelInfo(curCh) : null;

            var thresholds = [
                { label: "حساس جداً (0.3)", v: 0.3 },
                { label: "متوازن (0.5)", v: 0.5 },
                { label: "الواضح فقط (0.8)", v: 0.8 }
            ];

            return h(ScrollView, { style: { flex: 1, padding: 16, backgroundColor: "#1E1F22" } },
                h(View, { style: { gap: 14, paddingBottom: 60 } },
                    h(Text, { style: { fontSize: 19, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } }, "🛡️ حارس بحر — كشف المحتوى الممنوع"),
                    h(Text, { style: small }, "يفحص الرسائل التي تظهر لك فقط، ويخبرك بمكانها ونوعها وطريقة الإبلاغ. الإبلاغ يدوي منك (الإبلاغ الآلي يعرّض حسابك للحظر)."),

                    // الحالة
                    h(View, { style: card },
                        toggle("تشغيل الحارس", "enabled"),
                        h(Text, { style: small }, "تم فحص: " + state.scanned + "  |  في الانتظار: " + state.queued + "  |  مرصود: " + findings.length + (state.busy ? "  |  ⏳ يعمل…" : "")),
                        state.lastError ? h(Text, { style: { fontSize: 12, color: "#F23F43", textAlign: "right" } }, "آخر خطأ: " + state.lastError) : null,
                        curInfo ? button("🔍 فحص الروم المفتوح الآن: " + (curInfo.guildName ? curInfo.guildName + " / " : "") + curInfo.channelName, "#5865F2", function () {
                            var n = scanChannel(curCh, true);
                            showToast(n ? ("جارٍ فحص " + n + " رسالة محمّلة…") : "لا توجد رسائل نصية للفحص في هذا الروم");
                        }) : h(Text, { style: small }, "افتح روماً ثم ارجع هنا لفحص رسائله المحمّلة.")
                    ),

                    // المزوّد
                    h(View, { style: card },
                        h(Text, { style: title }, "محرك الفحص"),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            chip("محلي (بدون مفتاح)", cfg.provider === "local", function () { saveCfg({ provider: "local" }); keyDraft[1](null); setTestStatus(""); }),
                            chip("OpenAI Moderation (مجاني)", cfg.provider === "openai", function () { saveCfg({ provider: "openai" }); keyDraft[1](null); setTestStatus(""); }),
                            chip("Gemini", cfg.provider === "gemini", function () { saveCfg({ provider: "gemini" }); keyDraft[1](null); setTestStatus(""); })
                        ),
                        cfg.provider === "local" ? h(Text, { style: small }, "الكشف المحلي يعتمد على كلمات وأنماط (روابط احتيال، ألفاظ، بيع ممنوعات…). للدقة الأعلى استخدم OpenAI أو Gemini.") : null,
                        cfg.provider !== "local" ? h(View, { style: { gap: 8 } },
                            h(Text, { style: small }, cfg.provider === "openai"
                                ? "المفتاح من platform.openai.com/api-keys — واجهة Moderation مجانية."
                                : "المفتاح من aistudio.google.com/apikey"),
                            h(Text, { style: { fontSize: 13, color: currentKey ? "#23A55A" : "#F0B232", textAlign: "right" } },
                                currentKey ? ("✅ المفتاح محفوظ (…" + currentKey.slice(-4) + ")") : "⚠️ لم يُحفظ مفتاح بعد"),
                            TextInput ? h(TextInput, {
                                value: draft,
                                onChangeText: function (t) { keyDraft[1](t); },
                                placeholder: cfg.provider === "openai" ? "sk-..." : "AIza...",
                                placeholderTextColor: "#72767D",
                                secureTextEntry: true,
                                autoCapitalize: "none",
                                autoCorrect: false,
                                style: { backgroundColor: "#111214", color: "#FFFFFF", padding: 10, borderRadius: 8, textAlign: "left" }
                            }) : null,
                            h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                                button("حفظ المفتاح", "#248046", function () {
                                    var clean = String(draft || "").trim();
                                    if (!clean) { showToast("أدخل المفتاح أولاً"); return; }
                                    var p = {}; p[providerKeyName] = clean; saveCfg(p); keyDraft[1](null);
                                    setTestStatus("");
                                    showToast("تم حفظ المفتاح");
                                }, { flex: 1 }),
                                button("اختبار المفتاح", "#5865F2", function () {
                                    var k = String(draft || currentKey || "").trim();
                                    if (!k) { setTestStatus("⚠️ أدخل المفتاح أو احفظه أولاً"); return; }
                                    var prev = cfg[providerKeyName];
                                    cfg[providerKeyName] = k;
                                    setTestStatus("⏳ جارٍ اختبار الاتصال…");
                                    var fn = cfg.provider === "gemini" ? geminiModerate : openaiModerate;
                                    fn(["السلام عليكم، رسالة تجريبية"]).then(function () {
                                        if (!prev && draft) { var p = {}; p[providerKeyName] = k; saveCfg(p); keyDraft[1](null); }
                                        else { cfg[providerKeyName] = prev || k; }
                                        setTestStatus("✅ المفتاح يعمل بنجاح!");
                                    }).catch(function (err) {
                                        cfg[providerKeyName] = prev;
                                        setTestStatus("❌ فشل الاتصال: " + String((err && err.message) || err));
                                    });
                                }, { flex: 1 }),
                                currentKey ? button("حذف", "#DA373C", function () { var p = {}; p[providerKeyName] = ""; saveCfg(p); setTestStatus(""); }) : null
                            ),
                            testStatus ? h(Text, { style: { fontSize: 12, color: testStatus.indexOf("✅") === 0 ? "#23A55A" : "#F0B232", textAlign: "right" } }, testStatus) : null,
                            toggle("تشغيل الكشف المحلي أيضاً", "localAlways", "يكشف روابط الاحتيال فوراً حتى قبل رد الذكاء الاصطناعي")
                        ) : null,
                        h(Text, { style: title }, "الحساسية"),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            thresholds.map(function (t) {
                                return chip(t.label, Math.abs(cfg.threshold - t.v) < 0.01, function () { saveCfg({ threshold: t.v }); }, "th" + t.v);
                            })
                        )
                    ),

                    // خيارات
                    h(View, { style: card },
                        h(Text, { style: title }, "الخيارات"),
                        toggle("فحص الرسائل الجديدة", "scanNew"),
                        toggle("فحص الرسائل عند فتح أي روم", "scanLoaded"),
                        toggle("تجاهل رسائلي", "skipOwn"),
                        toggle("تنبيه منبثق عند الرصد", "toast"),
                        toggle("تنبيه داخل الروم (يظهر لك وحدك)", "inChatNotice", "رسالة محلية تحت الرسالة المشبوهة فيها النوع وطريقة الإبلاغ")
                    ),

                    // النتائج
                    h(View, { style: card },
                        h(View, { style: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" } },
                            h(Text, { style: title }, "🚩 الرسائل المرصودة (" + findings.length + ")"),
                            findings.length ? h(TouchableOpacity, { onPress: function () { saveCfg({ findings: [] }); } },
                                h(Text, { style: { color: "#F23F43", fontSize: 13 } }, "مسح الكل")) : null
                        ),
                        findings.length ? h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            [chip("الكل (" + findings.length + ")", filter === "all", function () { setFilter("all"); }, "all")].concat(
                                Object.keys(counts).map(function (k) {
                                    return chip((CATS[k] ? CATS[k].label : k) + " (" + counts[k] + ")", filter === k, function () { setFilter(k); }, k);
                                })
                            )
                        ) : h(Text, { style: small }, "لا توجد رسائل مرصودة حتى الآن."),

                        shown.slice(0, 80).map(function (f) {
                            var cat = CATS[f.cat] || { label: f.cat, color: "#999", steps: [] };
                            var isOpen = expanded[0] === f.messageId;
                            var where = (f.guildName ? f.guildName + " / " : (f.typeLabel === "خاص" ? "خاص / " : "")) + (f.channelName || f.channelId);
                            var when = "";
                            try { when = new Date(f.ts).toLocaleString(); } catch (e) { when = f.ts; }
                            return h(View, { key: f.messageId, style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 10, gap: 6, borderRightWidth: 4, borderRightColor: cat.color } },
                                h(TouchableOpacity, { onPress: function () { expanded[1](isOpen ? null : f.messageId); } },
                                    h(Text, { style: { color: cat.color, fontWeight: "bold", fontSize: 14, textAlign: "right" } }, cat.label + "  (" + Math.round((f.score || 0) * 100) + "%)"),
                                    h(Text, { style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } }, "📍 " + where),
                                    h(Text, { style: small }, "👤 " + f.authorName + (f.authorUsername ? " (@" + f.authorUsername + ")" : "") + (f.authorBot ? " [بوت]" : "") + "  •  🕒 " + when),
                                    h(Text, { style: { color: "#949BA4", fontSize: 12, textAlign: "right", fontStyle: "italic" } }, "«" + f.snippet + "»" + (f.hasAttach ? "  📎 يحتوي مرفقاً (لم يُحلَّل)" : "")),
                                    h(Text, { style: { color: "#F0B232", fontSize: 12, textAlign: "right", marginTop: 2 } }, "⚖️ الإبلاغ: " + cat.steps.join(" ← ") + (isOpen ? "  ▲" : "  ▼"))
                                ),
                                isOpen ? h(View, { style: { gap: 6 } },
                                    h(Text, { style: { color: "#FFFFFF", fontSize: 13, fontWeight: "bold", textAlign: "right" } }, "خطوات الإبلاغ:"),
                                    cat.steps.map(function (s, idx) {
                                        return h(Text, { key: idx, style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } }, (idx + 1) + ") " + s);
                                    }),
                                    cat.extra ? h(Text, { style: { color: "#F0B232", fontSize: 12, textAlign: "right" } }, cat.extra) : null,
                                    f.guildId ? h(Text, { style: small }, "إذا كان السيرفر كله مخصصاً لهذا المحتوى: اضغط مطولاً على أيقونة السيرفر ← إبلاغ عن السيرفر، أو أرسل بلاغاً عبر dis.gd/request مع روابط الرسائل.") : null,
                                    h(Text, { style: { color: "#72767D", fontSize: 11, textAlign: "right" } }, "المصدر: " + f.source + " — " + (f.reason || "")),
                                    h(Text, { style: { color: "#72767D", fontSize: 11, textAlign: "left" } }, "Server: " + (f.guildId || "DM") + "  Channel: " + f.channelId + "  Msg: " + f.messageId + "  User: " + f.authorId)
                                ) : null,
                                h(View, { style: { flexDirection: "row-reverse", gap: 6, flexWrap: "wrap" } },
                                    button("↪️ انتقال للرسالة", "#5865F2", function () {
                                        if (!jumpToMessage(f)) showToast("تعذّر الانتقال — انسخ الرابط وافتحه");
                                    }),
                                    button("📋 نسخ الرابط", "#4E5058", function () {
                                        showToast(copyText(messageLink(f)) ? "تم نسخ رابط الرسالة" : messageLink(f));
                                    }),
                                    button("📋 نسخ المعرّفات", "#4E5058", function () {
                                        var t = "Server ID: " + (f.guildId || "DM") + "\nChannel ID: " + f.channelId + "\nMessage ID: " + f.messageId + "\nUser ID: " + f.authorId + "\nLink: " + messageLink(f) + "\nType: " + cat.label;
                                        showToast(copyText(t) ? "تم نسخ بيانات البلاغ" : "تعذّر النسخ");
                                    }),
                                    button("✖ تجاهل", "#3F4147", function () {
                                        saveCfg({ findings: (cfg.findings || []).filter(function (x) { return x.messageId !== f.messageId; }) });
                                    })
                                )
                            );
                        })
                    ),

                    // روابط إبلاغ خارجية
                    h(View, { style: card },
                        h(Text, { style: title }, "جهات الإبلاغ"),
                        button("نموذج ثقة وأمان ديسكورد (dis.gd/request)", "#4E5058", function () { openExternal("https://dis.gd/request"); }),
                        button("NCMEC — الإبلاغ عن استغلال الأطفال", "#A12D2F", function () { openExternal("https://report.cybertip.org/"); }),
                        h(Text, { style: small }, "⚠️ عند الاشتباه باستغلال الأطفال: لا تحفظ ولا تصوّر ولا تعيد نشر أي شيء، فقط انسخ المعرّفات والروابط وبلّغ.")
                    )
                )
            );
        }
    });

    return exports;
})({});
