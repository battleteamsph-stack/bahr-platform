(function (exports) {
    "use strict";

    /*
     * حارس بحر (bahr.guard) v1.6.0
     * ----------------------------
     * - بحث مخصص داخل الخادم المستهدف عن رسائل معرّفات الإدارة المحددة فقط
     *   مع حفظ تلقائي لنقطة التوقف (الإداري والصفحة والرسائل المفحوصة) والمتابعة
     *   من حيث توقف حتى بعد إعادة تشغيل التطبيق.
     * - دعم OmniRoute المحلي بدون API (http://localhost:20128/v1 — النموذج: auto)
     *   إضافةً لتعدد مفاتيح API لكل نموذج ومزوّد والانتقال التلقائي عند انتهاء الحصة.
     * - وضع تدقيق مركّز على المخالفات الخطيرة الموجبة لحظر الخادم (مثل دعم الإرهاب
     *   والتطرف العنيف وسلامة الأطفال والتهديدات الخطيرة) لتفادي الضوضاء.
     * - فحص بكل اللغات وخاصة العربية والإنجليزية بدفعات 30 رسالة عبر جميع النماذج
     *   (OmniRoute / OpenRouter / Groq / Grok / Gemini / OpenAI Moderation / مخصص / محلي).
     * - إرسال رابط الرسالة وسبب المنع ومسار الإبلاغ المناسب تلقائياً للمجموعة المحددة.
     *
     * قواعد أمان ثابتة:
     *  - لا إبلاغ تلقائي لديسكورد (الإبلاغ يدوي من المستخدم دائماً).
     *  - النصوص فقط؛ المرفقات والصور لا تُنزَّل ولا تُرسل لأي جهة.
     */

    // ===================== الإعدادات =====================
    var DEFAULTS = {
        enabled: true,
        auditMode: "server_ban",  // "server_ban" (مخالفات حظر الخادم فقط) | "all" (جميع المخالفات)
        provider: "local",        // "local" | "omniroute" | "openrouter" | "groq" | "grok" | "gemini" | "openai" | "custom"
        autoFailoverProviders: true, // الانتقال التلقائي لمزوّد آخر عند انتهاء حصة كل مفاتيح المزوّد الحالي
        omnirouteUrl: "http://127.0.0.1:20128/v1",
        omnirouteKey: "",
        omnirouteModel: "auto",
        omnirouteInFailover: false, // تضمين OmniRoute في التبديل التلقائي مع المزوّدات الأخرى
        openaiKey: "",
        geminiKey: "",
        geminiModel: "gemini-2.5-flash",
        groqKey: "",
        groqModel: "llama-3.3-70b-versatile",
        grokKey: "",
        grokModel: "grok-3-mini",
        openrouterKey: "",
        openrouterModel: "openrouter/free",
        customUrl: "https://api.deepseek.com/v1/chat/completions",
        customKey: "",
        customModel: "deepseek-chat",
        batchSize: 30,            // عدد الرسائل في الدفعة الواحدة (15 / 30 / 50)
        searchDepth: 75,          // عدد الرسائل المجلوبة لكل إداري عند البحث في الخادم (25 / 75 / 200)
        autoResumeSearch: false,  // متابعة البحث تلقائياً بعد إعادة تشغيل التطبيق إن لم يكتمل
        threshold: 0.5,           // عتبة الحساسية (0..1)
        filterUsersOnly: false,   // فحص معرّفات الإدارة المحددة فقط
        targetUserIds: "",        // معرّفات الإدارة (IDs)
        targetGuildId: "",        // معرّف الخادم المستهدف
        reportChannelId: "",      // معرّف المجموعة/القناة (أو رابط Webhook) لإرسال التقارير إليها
        autoForward: true,        // إرسال تلقائي للمجموعة المحددة عند الرصد
        scanNew: true,            // فحص الرسائل الجديدة
        scanLoaded: true,         // فحص الرسائل عند تحميل الروم أو البحث
        localAlways: true,        // تشغيل الكشف المحلي مع الذكاء الاصطناعي
        skipOwn: true,            // تجاهل رسائلي (إلا إذا أُضيف معرّفي ضمن الإدارة)
        toast: true,              // تنبيه منبثق
        inChatNotice: true,       // تنبيه محلي داخل الروم المفتوح
        findings: [],
        scannedIds: [],           // آخر 5000 معرّف رسالة تم فحصها فعلياً (تُحفظ عبر إعادة التشغيل)
        adminNames: {},           // أسماء معرّفات الإدارة المكتشفة
        searchProgress: {
            guildId: "",
            admins: {},           // { uid: { nextOffset, reachedEnd, fetched, total, updatedAt } }
            fetchedTotal: 0,
            queuedTotal: 0,
            updatedAt: 0
        }
    };

    var PROVIDERS = {
        local: {
            label: "محلي (بدون مفتاح)",
            sourceName: "محلي"
        },
        omniroute: {
            label: "OmniRoute (محلي بدون API)",
            sourceName: "OmniRoute",
            urlProp: "omnirouteUrl",
            keyProp: "omnirouteKey",
            modelProp: "omnirouteModel",
            keyOptional: true,
            defaultBearer: "omniroute",
            keyPlaceholder: "مفتاح OmniRoute (اختياري — اتركه فارغاً للعمل بدون API)",
            keyHint: "يتصل بخادم OmniRoute المحلي (http://localhost:20128/v1) بالنموذج auto للحصول على ملايين التوكن بدون مفاتيح API. شغّل OmniRoute وفعّل المزوّدين أولاً.",
            urlPresets: ["http://127.0.0.1:20128/v1", "http://localhost:20128/v1"],
            presets: ["auto"]
        },
        openai: {
            label: "OpenAI Moderation (مجاني)",
            sourceName: "OpenAI",
            keyProp: "openaiKey",
            keyPlaceholder: "sk-...",
            keyHint: "المفتاح من platform.openai.com/api-keys — واجهة Moderation مجانية. يمكنك إضافة أكثر من مفتاح (مفتاح في كل سطر).",
            maxBatch: 30
        },
        gemini: {
            label: "جيميني (Gemini)",
            sourceName: "Gemini",
            keyProp: "geminiKey",
            modelProp: "geminiModel",
            keyPlaceholder: "AIza...",
            keyHint: "المفتاح من aistudio.google.com/apikey — أضف عدة مفاتيح للتبديل التلقائي عند انتهاء الحصة.",
            presets: ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.0-flash"]
        },
        groq: {
            label: "Groq (جروك السريع)",
            sourceName: "Groq",
            endpoint: "https://api.groq.com/openai/v1/chat/completions",
            keyProp: "groqKey",
            modelProp: "groqModel",
            keyPlaceholder: "gsk_...",
            keyHint: "المفتاح من console.groq.com/keys — أضف عدة مفاتيح للتبديل التلقائي عند انتهاء الحصة اليومية.",
            presets: [
                "llama-3.3-70b-versatile",
                "meta-llama/llama-4-scout-17b-16e-instruct",
                "llama-3.1-8b-instant",
                "qwen/qwen3-32b"
            ]
        },
        grok: {
            label: "Grok (xAI)",
            sourceName: "Grok",
            endpoint: "https://api.x.ai/v1/chat/completions",
            keyProp: "grokKey",
            modelProp: "grokModel",
            keyPlaceholder: "xai-...",
            keyHint: "المفتاح من console.x.ai — يمكنك إضافة أكثر من مفتاح للتبديل التلقائي.",
            presets: ["grok-3-mini", "grok-3-mini-fast", "grok-3", "grok-2-latest"]
        },
        openrouter: {
            label: "OpenRouter (كل النماذج)",
            sourceName: "OpenRouter",
            endpoint: "https://openrouter.ai/api/v1/chat/completions",
            keyProp: "openrouterKey",
            modelProp: "openrouterModel",
            keyPlaceholder: "sk-or-v1-...",
            keyHint: "المفتاح من openrouter.ai/keys — يمكنك إضافة عدة مفاتيح وعدة نماذج (بفاصلة) للتبديل التلقائي عند انتهاء الحصة.",
            extraHeaders: {
                "HTTP-Referer": "https://bahr.app",
                "X-Title": "Bahr Guard"
            },
            presets: [
                "openrouter/free",
                "meta-llama/llama-3.3-70b-instruct:free",
                "google/gemini-2.5-flash",
                "openai/gpt-4o-mini",
                "x-ai/grok-3-mini",
                "deepseek/deepseek-chat-v3-0324:free"
            ]
        },
        custom: {
            label: "مخصص (أي API)",
            sourceName: "مخصص",
            urlProp: "customUrl",
            keyProp: "customKey",
            modelProp: "customModel",
            keyOptional: true,
            keyPlaceholder: "مفاتيح API (اختياري للخوادم المحلية)...",
            keyHint: "يدعم أي مزوّد متوافق مع OpenAI مثل DeepSeek أو Together أو Mistral أو Cerebras أو Ollama المحلي.",
            presets: ["deepseek-chat", "mistral-small-latest", "llama3.1"]
        }
    };

    var PROVIDER_ORDER = ["local", "omniroute", "openrouter", "groq", "grok", "gemini", "openai", "custom"];

    var cfg = JSON.parse(JSON.stringify(DEFAULTS));
    var storageRef = null;
    var MAX_FINDINGS = 250;
    var REQUEST_GAP_MS = 1000;
    var FORWARD_GAP_MS = 3500;
    var SEARCH_GAP_MS = 2800;
    var MAX_TEXT = 900;
    var NOTICE_AUTHOR_ID = "1";

    var mods = {
        RestAPI: null,
        UserStore: null,
        GuildMemberStore: null,
        ChannelStore: null,
        GuildChannelStore: null,
        GuildStore: null,
        SelectedChannelStore: null,
        MessageStore: null,
        MessageActions: null,
        Dispatcher: null,
        Toast: null,
        Router: null,
        URLOpener: null,
        Clipboard: null
    };

    var nameCache = {};

    var state = {
        queued: 0,
        scanned: 0,
        flagged: 0,
        forwarded: 0,
        forwardQueued: 0,
        activeRoute: "",
        keyRotations: 0,
        lastError: "",
        lastForwardError: "",
        busy: false
    };

    var serverSearch = {
        running: false,
        stopRequested: false,
        adminIndex: 0,
        adminTotal: 0,
        currentAdmin: "",
        fetchedMsgs: 0,
        queuedMsgs: 0,
        status: "",
        lastError: ""
    };

    // ===================== أدوات عامة =====================
    var listeners = [];
    function emitState() {
        for (var i = 0; i < listeners.length; i++) {
            try { listeners[i](); } catch (e) {}
        }
    }
    function subscribeState(fn) {
        listeners.push(fn);
        return function () {
            var idx = listeners.indexOf(fn);
            if (idx !== -1) listeners.splice(idx, 1);
        };
    }

    function getReact() {
        return (typeof valenced !== "undefined" && valenced.react && (valenced.react.React || valenced.react)) || null;
    }
    function getRN() {
        return (typeof valenced !== "undefined" && valenced.react && valenced.react.ReactNative) || null;
    }
    function sleep(ms) {
        return new Promise(function (resolve) { setTimeout(resolve, ms); });
    }

    function normalizeDigits(str) {
        if (typeof str !== "string") return "";
        var arabic = "٠١٢٣٤٥٦٧٨٩";
        var persian = "۰۱۲۳۴۵۶۷۸۹";
        var out = "";
        for (var i = 0; i < str.length; i++) {
            var ch = str.charAt(i);
            var idx = arabic.indexOf(ch);
            if (idx !== -1) out += String(idx);
            else {
                var pidx = persian.indexOf(ch);
                out += pidx !== -1 ? String(pidx) : ch;
            }
        }
        return out;
    }

    function extractSnowflakes(raw) {
        var norm = normalizeDigits(String(raw || ""));
        var matches = norm.match(/\d{15,22}/g) || [];
        var seen = {};
        var list = [];
        for (var i = 0; i < matches.length; i++) {
            if (!seen[matches[i]]) {
                seen[matches[i]] = true;
                list.push(matches[i]);
            }
        }
        return { list: list, map: seen, count: list.length };
    }

    function extractSingleIdOrWebhook(raw) {
        var t = normalizeDigits(String(raw || "")).trim();
        if (!t) return "";
        if (/^https?:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\//i.test(t)) return t;
        var m = t.match(/\d{15,22}/);
        return m ? m[0] : "";
    }

    function isWebhookUrl(v) {
        return /^https?:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\//i.test(String(v || "").trim());
    }

    function saveCfg(patch) {
        for (var k in patch) {
            if (Object.prototype.hasOwnProperty.call(patch, k)) cfg[k] = patch[k];
        }
        if (storageRef && typeof storageRef.set === "function") {
            try { storageRef.set(patch); } catch (e) {}
        }
        emitState();
    }

    function showToast(text) {
        try {
            if (mods.Toast && typeof mods.Toast.showToast === "function") {
                mods.Toast.showToast(String(text));
                return;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.ToastAndroid && typeof RN.ToastAndroid.show === "function") {
                RN.ToastAndroid.show(String(text), RN.ToastAndroid.LONG);
            }
        } catch (e) {}
    }

    function copyText(text) {
        try {
            if (mods.Clipboard && typeof mods.Clipboard.setString === "function") {
                mods.Clipboard.setString(text);
                return true;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.Clipboard && typeof RN.Clipboard.setString === "function") {
                RN.Clipboard.setString(text);
                return true;
            }
        } catch (e) {}
        return false;
    }

    function getMyUserId() {
        try {
            if (mods.UserStore && typeof mods.UserStore.getCurrentUser === "function") {
                var u = mods.UserStore.getCurrentUser();
                if (u && u.id) return String(u.id);
            }
        } catch (e) {}
        return null;
    }

    var nameSaveTimer = null;
    function scheduleSaveAdminNames() {
        if (nameSaveTimer) return;
        nameSaveTimer = setTimeout(function () {
            nameSaveTimer = null;
            try { saveCfg({ adminNames: Object.assign({}, cfg.adminNames || {}) }); } catch (e) {}
        }, 3000);
    }

    function cacheAuthorName(author) {
        if (!author || !author.id) return;
        var uid = String(author.id);
        var dn = author.globalName || author.global_name || author.username || "";
        var un = author.username || "";
        var label = (dn && un && dn !== un) ? (dn + " (@" + un + ")") : dn;
        if (!label) return;
        nameCache[uid] = label;
        try {
            var targets = extractSnowflakes(cfg.targetUserIds);
            if (targets.map[uid]) {
                if (!cfg.adminNames || typeof cfg.adminNames !== "object") cfg.adminNames = {};
                if (cfg.adminNames[uid] !== label) {
                    cfg.adminNames[uid] = label;
                    scheduleSaveAdminNames();
                }
            }
        } catch (e) {}
    }

    function resolveUserLabel(uid, guildId) {
        var id = String(uid || "");
        if (!id) return "";
        try {
            if (mods.UserStore && typeof mods.UserStore.getUser === "function") {
                var u = mods.UserStore.getUser(id);
                if (u) {
                    var dn = u.globalName || u.global_name || u.username || "";
                    var un = u.username || "";
                    var nick = "";
                    try {
                        if (guildId && mods.GuildMemberStore && typeof mods.GuildMemberStore.getNick === "function") {
                            nick = mods.GuildMemberStore.getNick(guildId, id) || "";
                        }
                    } catch (e) {}
                    var best = nick || dn;
                    if (best && un && best !== un) {
                        nameCache[id] = best + " (@" + un + ")";
                        return nameCache[id];
                    }
                    if (best) {
                        nameCache[id] = best;
                        return best;
                    }
                }
            }
        } catch (e) {}
        try {
            if (guildId && mods.GuildMemberStore && typeof mods.GuildMemberStore.getNick === "function") {
                var nk = mods.GuildMemberStore.getNick(guildId, id);
                if (nk) { nameCache[id] = nk; return nk; }
            }
        } catch (e) {}
        return nameCache[id] || "";
    }

    function getGuildName(guildId) {
        if (!guildId) return "";
        try {
            if (mods.GuildStore && typeof mods.GuildStore.getGuild === "function") {
                var g = mods.GuildStore.getGuild(String(guildId));
                if (g && g.name) return g.name;
            }
        } catch (e) {}
        return "";
    }

    function getCurrentChannelId() {
        try {
            if (mods.SelectedChannelStore && typeof mods.SelectedChannelStore.getChannelId === "function") {
                return mods.SelectedChannelStore.getChannelId() || "";
            }
        } catch (e) {}
        return "";
    }

    function getChannelInfo(channelId) {
        var info = { channelId: channelId || "", guildId: null, guildName: "", channelName: "", typeLabel: "قناة" };
        if (!channelId) return info;
        var ch = null;
        try {
            if (mods.ChannelStore && typeof mods.ChannelStore.getChannel === "function") ch = mods.ChannelStore.getChannel(channelId);
        } catch (e) {}
        if (!ch) { info.channelName = "قناة " + channelId; return info; }
        info.guildId = ch.guild_id || ch.guildId || null;
        if (ch.type === 1) {
            info.typeLabel = "خاص";
            var recName = "محادثة خاصة";
            try {
                var rIds = ch.recipients || ch.rawRecipients;
                if (Array.isArray(rIds) && rIds.length > 0) {
                    var first = rIds[0];
                    if (typeof first === "object" && first) recName = first.globalName || first.global_name || first.username || recName;
                    else { var lbl = resolveUserLabel(first, null); if (lbl) recName = lbl; }
                }
            } catch (e) {}
            info.channelName = recName;
        } else if (ch.type === 3) {
            info.typeLabel = "قروب";
            var gName = ch.name || "";
            if (!gName) {
                try {
                    var names = [];
                    var rList = ch.recipients || [];
                    for (var i = 0; i < rList.length && i < 3; i++) {
                        var rid = typeof rList[i] === "object" ? rList[i].id : String(rList[i]);
                        var rl = resolveUserLabel(rid, null);
                        if (rl) names.push(rl);
                    }
                    gName = names.length ? names.join("، ") : "قروب خاص";
                } catch (e) { gName = "قروب خاص"; }
            }
            info.channelName = gName;
        } else if (ch.type === 11 || ch.type === 12 || ch.type === 10) {
            info.typeLabel = "ثريد";
            info.channelName = ch.name ? ("🧵 " + ch.name) : channelId;
        } else {
            info.typeLabel = "سيرفر";
            info.channelName = ch.name ? ("#" + ch.name) : channelId;
        }
        if (info.guildId) info.guildName = getGuildName(info.guildId);
        return info;
    }

    function listPrivateChannels(maxItems) {
        var out = [];
        try {
            if (!mods.ChannelStore) return out;
            var raw = null;
            if (typeof mods.ChannelStore.getSortedPrivateChannels === "function") {
                raw = mods.ChannelStore.getSortedPrivateChannels();
            } else if (typeof mods.ChannelStore.getMutablePrivateChannels === "function") {
                var map = mods.ChannelStore.getMutablePrivateChannels();
                if (map && typeof map === "object") raw = Object.keys(map).map(function (k) { return map[k]; });
            }
            if (Array.isArray(raw)) {
                for (var i = 0; i < raw.length && out.length < (maxItems || 25); i++) {
                    var c = raw[i];
                    if (c && c.id && (c.type === 1 || c.type === 3)) out.push(getChannelInfo(c.id));
                }
            }
        } catch (e) {}
        return out;
    }

    function listGuildChannelIds(guildId) {
        var ids = [];
        var seen = {};
        function add(id) {
            if (!id) return;
            var s = String(id);
            if (!seen[s]) { seen[s] = true; ids.push(s); }
        }
        try {
            if (mods.ChannelStore && typeof mods.ChannelStore.getMutableGuildChannelsForGuild === "function") {
                var m = mods.ChannelStore.getMutableGuildChannelsForGuild(guildId);
                if (m && typeof m === "object") {
                    for (var k in m) if (Object.prototype.hasOwnProperty.call(m, k)) add(k);
                }
            }
        } catch (e) {}
        try {
            if (mods.GuildChannelStore && typeof mods.GuildChannelStore.getChannels === "function") {
                var gc = mods.GuildChannelStore.getChannels(guildId);
                if (gc) {
                    var lists = [gc.SELECTABLE, gc.VOCAL, gc.THREADS];
                    for (var i = 0; i < lists.length; i++) {
                        if (Array.isArray(lists[i])) {
                            for (var j = 0; j < lists[i].length; j++) {
                                var ch = lists[i][j] && lists[i][j].channel;
                                if (ch && ch.id) add(ch.id);
                            }
                        }
                    }
                }
            }
        } catch (e) {}
        return ids;
    }

    function messageLink(f) {
        return "https://discord.com/channels/" + (f.guildId || "@me") + "/" + f.channelId + "/" + f.messageId;
    }

    function jumpToMessage(f) {
        var path = "/channels/" + (f.guildId || "@me") + "/" + f.channelId + "/" + f.messageId;
        var url = "https://discord.com" + path;
        try {
            if (mods.Router && typeof mods.Router.transitionTo === "function") {
                mods.Router.transitionTo(path);
                return true;
            }
        } catch (e) {}
        try {
            if (mods.URLOpener && typeof mods.URLOpener.openURL === "function") {
                mods.URLOpener.openURL(url);
                return true;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.Linking && typeof RN.Linking.openURL === "function") {
                RN.Linking.openURL(url);
                return true;
            }
        } catch (e) {}
        return false;
    }

    function openExternal(url) {
        try {
            var RN = getRN();
            if (RN && RN.Linking) RN.Linking.openURL(url);
        } catch (e) {}
    }

    function normalizeChatEndpoint(url) {
        var u = String(url || "").trim();
        if (!u) return "";
        if (/\/chat\/completions\/?$/i.test(u)) return u.replace(/\/+$/, "");
        return u.replace(/\/+$/, "") + "/chat/completions";
    }

    function normalizeModelsEndpoint(url) {
        var u = String(url || "").trim();
        if (!u) return "";
        u = u.replace(/\/chat\/completions\/?$/i, "").replace(/\/+$/, "");
        if (/\/models$/i.test(u)) return u;
        return u + "/models";
    }

    function parseKeyList(raw) {
        if (typeof raw !== "string") return [];
        var parts = raw.split(/[\r\n,;\s]+/);
        var seen = {};
        var list = [];
        for (var i = 0; i < parts.length; i++) {
            var k = parts[i].trim();
            if (k && k.length >= 4 && !seen[k]) {
                seen[k] = true;
                list.push(k);
            }
        }
        return list;
    }

    function parseModelList(raw) {
        if (typeof raw !== "string") return [];
        var parts = raw.split(/[\r\n,;]+/);
        var seen = {};
        var list = [];
        for (var i = 0; i < parts.length; i++) {
            var m = parts[i].trim();
            if (m && !seen[m]) {
                seen[m] = true;
                list.push(m);
            }
        }
        return list;
    }

    function maskKey(k) {
        var s = String(k || "").trim();
        if (!s) return "(بدون مفتاح)";
        if (s.length <= 6) return "…" + s.slice(-2);
        return "…" + s.slice(-4);
    }

    function getProviderKeys(providerId) {
        var p = PROVIDERS[providerId];
        if (!p || !p.keyProp) return [];
        return parseKeyList(cfg[p.keyProp] || "");
    }

    function getProviderModels(providerId) {
        var p = PROVIDERS[providerId];
        if (!p) return [];
        if (!p.modelProp) return ["omni-moderation-latest"];
        var list = parseModelList(cfg[p.modelProp] || "");
        if (list.length) return list;
        return (p.presets && p.presets.length) ? [p.presets[0]] : [];
    }

    function isProviderReady(providerId, forFailover) {
        var p = PROVIDERS[providerId];
        if (!p || providerId === "local") return false;
        if (providerId === "omniroute") {
            if (forFailover && !cfg.omnirouteInFailover) return false;
            return !!String(cfg.omnirouteUrl || "").trim() && getProviderModels("omniroute").length > 0;
        }
        if (providerId === "custom") {
            if (forFailover && getProviderKeys("custom").length === 0) return false;
            return !!String(cfg.customUrl || "").trim() && getProviderModels("custom").length > 0;
        }
        if (getProviderKeys(providerId).length === 0) return false;
        if (p.modelProp && getProviderModels(providerId).length === 0) return false;
        return true;
    }

    function hasAnyAiProvider() {
        if (cfg.provider === "local") return false;
        if (isProviderReady(cfg.provider, false)) return true;
        if (!cfg.autoFailoverProviders) return false;
        for (var i = 0; i < PROVIDER_ORDER.length; i++) {
            var pid = PROVIDER_ORDER[i];
            if (pid !== "local" && isProviderReady(pid, true)) return true;
        }
        return false;
    }

    // ===================== التصنيفات ومسارات الإبلاغ =====================
    var CATS = {
        "sexual/minors": {
            label: "استغلال جنسي للأطفال (CSAM)",
            severity: 100,
            banRisk: true,
            color: "#FF0033",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "سلامة الأطفال / مواد استغلال جنسي للأطفال"],
            extra: "⚠️ لا تفتح أو تحفظ أو تصوّر أو تشارك أي مرفق. بلّغ ديسكورد، وبلّغ أيضاً مركز NCMEC عبر report.cybertip.org. وبلّغ عن الخادم نفسه.",
            hideSnippet: true
        },
        "terrorism": {
            label: "إرهاب / تطرف عنيف / تجنيد",
            severity: 95,
            banRisk: true,
            color: "#B71C1C",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "معلومات مضللة ضارة أو تمجيد العنف", "التطرف العنيف أو الإرهاب"],
            extra: "🔥 مخالفة خطيرة موجبة لحظر الخادم: انسخ المعرّفات وروابط رسائل الإدارة وبلّغ أيضاً عن الخادم عبر dis.gd/request (فئة التطرف العنيف والإرهاب)."
        },
        "self-harm": {
            label: "إيذاء النفس / انتحار",
            severity: 90,
            banRisk: true,
            color: "#E67E22",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "إيذاء النفس أو الانتحار"],
            extra: "إن كان الشخص في خطر حقيقي فتواصل معه بلطف ووجّهه لخط مساعدة: findahelpline.com"
        },
        "violence": {
            label: "تهديد بالقتل / تحريض على العنف / دموية",
            severity: 85,
            banRisk: true,
            color: "#C0392B",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "معلومات مضللة ضارة أو تمجيد العنف", "تمجيد العنف أو التحريض عليه"]
        },
        "illicit": {
            label: "نشاط غير قانوني خطير / أسلحة / مخدرات / اختراق",
            severity: 75,
            banRisk: true,
            color: "#8E44AD",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "بيع سلع غير قانونية أو خاضعة للرقابة"]
        },
        "hate": {
            label: "خطاب كراهية عنيف / تحريض ضد فئة",
            severity: 65,
            banRisk: true,
            color: "#D35400",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "إساءة أو مضايقة", "خطاب كراهية"]
        },
        "sexual": {
            label: "محتوى جنسي صريح / غير توافقي",
            severity: 55,
            banRisk: true,
            color: "#E91E63",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "عري أو محتوى جنسي"]
        },
        "doxxing": {
            label: "نشر معلومات شخصية خاصة (تشهير)",
            severity: 50,
            banRisk: true,
            color: "#3498DB",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "كشف معلومات شخصية خاصة"]
        },
        "harassment": {
            label: "إساءة / مضايقة / سب",
            severity: 45,
            banRisk: false,
            color: "#E74C3C",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "إساءة أو مضايقة"]
        },
        "scam": {
            label: "احتيال / تصيّد / سبام",
            severity: 40,
            banRisk: false,
            color: "#F1C40F",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "رسائل مزعجة (سبام)"],
            extra: "لا تضغط على الرابط ولا تدخل بيانات حسابك."
        },
        "blocked": {
            label: "محتوى رفض النموذج تحليله (مشبوه جداً)",
            severity: 88,
            banRisk: true,
            color: "#FF5555",
            steps: ["افتح الرسالة بحذر وراجعها بنفسك", "إن تأكدت: اضغط مطولاً ← إبلاغ ← اختر النوع المناسب"],
            extra: "حجب مزوّد الذكاء الاصطناعي الرد لأن النص يحوي محتوى محظوراً بشدة. لا تفتح المرفقات."
        }
    };

    var SERVER_BAN_CATS = ["sexual/minors", "terrorism", "self-harm", "violence", "illicit", "hate", "doxxing", "sexual"];
    var ALL_AI_CATS = ["sexual/minors", "terrorism", "self-harm", "violence", "illicit", "hate", "harassment", "sexual", "scam", "doxxing"];

    var OPENAI_MAP = {
        "sexual/minors": "sexual/minors",
        "self-harm": "self-harm",
        "self-harm/intent": "self-harm",
        "self-harm/instructions": "self-harm",
        "violence": "violence",
        "violence/graphic": "violence",
        "harassment/threatening": "violence",
        "hate/threatening": "violence",
        "illicit": "illicit",
        "illicit/violent": "illicit",
        "hate": "hate",
        "harassment": "harassment",
        "sexual": "sexual"
    };

    // ===================== الكشف المحلي =====================
    var OFFICIAL_DOMAINS = /^(?:[a-z0-9-]+\.)*(discord\.com|discord\.gg|discordapp\.com|discordapp\.net|discord\.media|discord\.new|discord\.gift|discordstatus\.com|steampowered\.com|steamcommunity\.com|tenor\.com|giphy\.com|youtube\.com|youtu\.be|google\.com)$/i;
    var LOOKALIKE = /(d[i1l!|][s5$][ckq][o0][r][dcl]|disc[o0]rd|dlscord|discrod|d1scord|nitr[o0]|st[e3]am|ste[a@]m)/i;
    var URL_RE = /https?:\/\/([^\s\/<>"']+)/gi;

    var RULES = [
        { cat: "sexual/minors", severe: true, score: 0.92, re: /(child\s*porn|\bcp\s*(link|vid|pack|sell|trade|for sale)|pedo\s*(link|pack|vid)|preteen\s*(nude|sex)|underage\s*(nude|sex|porn)|loli\s*(porn|nude|sex|hentai)|\bjailbait\b|اباحية\s*اطفال|إباحية\s*أطفال|سكس\s*(اطفال|أطفال|قاصر|قاصرات)|صور\s*(اطفال|قاصرات)\s*(عاري|عارية|سكس))/i },
        { cat: "terrorism", severe: true, score: 0.94, re: /(باقية\s*وتتمدد|الدولة\s*(الاسلامية|الإسلامية)\s*(في\s*العراق\s*والشام|باقية|على\s*منهاج)|دولة\s*الخلافة\s*(باقية|تنتصر)|بيعة\s*(ل?داعش|ل?لبغدادي|ل?أبو\s*بكر|ل?تنظيم|ل?لدولة)|أبايع\s*(تنظيم|داعش|الخليفة|الدولة)|انضم(وا)?\s*(ل?داعش|ل?تنظيم|ل?لجهاد\s*المسلح|ل?لذئاب)|داعش\s*(تنتصر|باقية|على\s*حق|أبطال|ابطال|منصور)|تنظيم\s*القاعدة\s*(أبطال|ابطال|على\s*حق|نصر)|أسامة\s*بن\s*لادن\s*(بطل|شهيدنا|قدوتنا|رحمه\s*الله\s*على\s*عملية)|عملية\s*استشهادية\s*(مباركة|تقبل|نفذ|استهدف|فجر)|انغماسي(ين|ة)?\s*(تقبل|بارك|مبارك)|حزام\s*ناسف|تفخيخ\s*(سيارة|سيارات|عبوة|عبوات)|(صناعة|طريقة\s*صنع|تحضير|تركيب)\s*(قنبلة|قنابل|متفجرات|عبوة\s*ناسفة|الريسين|تي\s*ان\s*تي|\btnt\b|\bc4\b)|(اصدارات|إصدارات)\s*(ولاية|داعش|الفرقان|أعماق|اعماق|الحياة)|وكالة\s*(أعماق|اعماق)|مؤسسة\s*(الفرقان|الاعتصام|أجناد|اجناد)|نشر\s*(اصدار|إصدار)\s*(ذبح|نحر|داعش)|ذبح\s*(الكفار|المرتدين|الروافض|الطواغيت|الصليبيين)|اقتلوا\s*(الكفار|المرتدين|المشركين|المدنيين|اليهود|النصارى)|فجروا\s*(المساجد|الكنائس|السفارات|المدارس)|الذئاب\s*المنفردة|تفجير\s*(مسجد|كنيسة|مدرسة|مول|سوق|سفارة|مطار)|join\s*(isis|daesh|da3esh|isil|al[\s-]?qaeda)|pledge\s*(allegiance|bayah)\s*to\s*(isis|daesh|da3esh|isil|islamic\s*state|al[\s-]?qaeda)|(isis|daesh|da3esh|isil)\s*(nasheed|nasheeds|release|beheading|propaganda|amaq|edit|edits)|amaq\s*(news|agency)|baqiya(h)?\s*(wa\s*tatamaddad)?|how\s*to\s*(make|build|craft)\s*(a\s*)?(bomb|ied|explosive|pipe\s*bomb|suicide\s*vest|\btnt\b|\bc4\b|ricin)|(bomb|ied|explosive)\s*(recipe|manual|tutorial|instructions)|lone\s*wolf\s*attack|mass\s*shooting\s*(plan|manifesto|livestream)|(praise|glory\s*to|heil|based)\s*(isis|daesh|brenton\s*tarrant|anders\s*breivik|osama\s*bin\s*laden|al[\s-]?baghdadi)|suicide\s*(vest|belt|bombing\s*tutorial))/i },
        { cat: "self-harm", severe: true, score: 0.8, re: /(\bkill\s*my\s*self\b|\bkms\b|\bsuicide\b|cut\s*my\s*self|ابي\s*انتحر|أبي\s*أنتحر|بنتحر|سأنتحر|راح\s*انتحر|اريد\s*الانتحار|أريد\s*الانتحار|اقتل\s*نفسي|أقتل\s*نفسي|اذبح\s*نفسي|انتحر\s*أحسن|انصحك\s*تنتحر)/i },
        { cat: "violence", severe: true, score: 0.8, re: /(i\s*(will|'ll|am\s*going\s*to)\s*(kill|shoot|stab)\s*(you|u)|bomb\s*(the|a)\s*(school|mosque|church)|shoot\s*up\s*(the|a)\s*(school|mosque|church|mall)|سأقتلك|راح\s*اقتلك|بقتلك|والله\s*لاقتلك|بذبحك|راح\s*اذبحك|سأذبحك|فيديو\s*(ذبح|نحر|تقطيع))/i },
        { cat: "illicit", severe: true, score: 0.78, re: /((weed|cocaine|coke|meth|mdma|xanax|lsd|heroin|ecstasy)\s*(for\s*sale|dm\s*me|available|plug)|selling\s*(weed|coke|meth|drugs|guns|firearms|cc\b|fullz|botnet|ddos)|\bcc\s*dumps?\b|(حشيش|مخدرات|كبتاجون|كبتاغون|شبو|كريستال|ترامادول|سلاح|اسلحة|أسلحة|مسدس|كلاشنكوف)\s*(للبيع|متوفر|متوفرة|توصيل)|بيع\s*(حشيش|مخدرات|كبتاجون|سلاح|أسلحة|فيزا\s*مسروقة|بطاقات\s*مسروقة))/i },
        { cat: "sexual", severe: false, score: 0.65, re: /(\bporn(hub)?\b|\bxvideos\b|\bxnxx\b|onlyfans\s*(leak|leaks|free)|\bnudes?\s*(leak|pack|for\s*sale|dm)|\bnsfw\s*(link|leak)|سكس|نيك|افلام\s*اباحية|أفلام\s*إباحية|مقاطع\s*اباحية|صور\s*عارية|محارم)/i },
        { cat: "scam", severe: false, score: 0.7, re: /(free\s*nitro|nitro\s*(for\s*)?free|claim\s*(your\s*)?(nitro|gift|reward)|steam\s*gift|\$\d+\s*steam|airdrop|crypto\s*giveaway|نيترو\s*مجان|نيترو\s*ببلاش|هدية\s*ستيم|اربح\s*نيترو)/i },
        { cat: "hate", severe: false, score: 0.65, re: /(\bn[i1]gg(er|a)s?\b|\bfaggots?\b|\bkikes?\b|gas\s*the\s*jews|يا\s*(عبد|عبيد)\b|يا\s*زنجي|الله\s*يلعن\s*(دينك|دين\s*ابوك|دين\s*أبوك))/i },
        { cat: "harassment", severe: false, score: 0.55, re: /(\bkys\b|kill\s*yourself|يا\s*(كلب|حمار|خنزير|حيوان|منيوك|قحبة|شرموط|شرموطة|عاهر|عاهرة|ديوث|لوطي)|ابن\s*(القحبة|الكلب|الشرموطة)|كس\s*(امك|أمك|اختك|أختك))/i }
    ];

    var DOX_CONTEXT = /(رقمه|رقمها|رقم\s*(جواله|جوالها|تلفونه|هاتفه|هاتفها)|عنوانه|عنوانها|ساكن|ساكنة|يسكن|تسكن|بيته|بيتها|\bdox(x)?(ed|ing)?\b|home\s*address|his\s*address|her\s*address|lives\s*at|ip\s*:?)/i;
    var PHONE_RE = /(\+?\d[\d\s\-]{8,}\d)/;
    var IP_RE = /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/;

    function localDetect(text) {
        var hits = [];
        if (!text) return hits;
        var severeOnly = cfg.auditMode === "server_ban";
        for (var i = 0; i < RULES.length; i++) {
            if (severeOnly && !RULES[i].severe) continue;
            if (RULES[i].re.test(text)) hits.push({ cat: RULES[i].cat, score: RULES[i].score, reason: "تطابق مباشر (كشف محلي)" });
        }
        if (!severeOnly) {
            var m;
            URL_RE.lastIndex = 0;
            while ((m = URL_RE.exec(text)) !== null) {
                var host = String(m[1] || "").toLowerCase().split(":")[0];
                if (!OFFICIAL_DOMAINS.test(host) && LOOKALIKE.test(host)) {
                    hits.push({ cat: "scam", score: 0.9, reason: "رابط مقلّد: " + host });
                    break;
                }
            }
        }
        if ((PHONE_RE.test(text) || IP_RE.test(text)) && DOX_CONTEXT.test(text)) {
            hits.push({ cat: "doxxing", score: 0.75, reason: "نشر رقم/عنوان شخصي" });
        }
        return hits;
    }

    // ===================== مزوّدات الذكاء الاصطناعي =====================
    var CLASSIFY_SERVER_BAN_SYSTEM =
        "You are a senior Discord Trust & Safety investigator auditing messages sent by SERVER ADMINISTRATORS / MODERATORS in ALL languages (especially Arabic — Modern Standard, Gulf, Levantine, Egyptian, Maghrebi, Franco-Arabic/Arabizi, coded/obfuscated spelling — and English, plus any other language).\n" +
        "Your ONLY mission is to detect CLEAR, UNDENIABLE, SEVERE violations that are likely to cause Discord Trust & Safety to TERMINATE / BAN THE ENTIRE SERVER to protect the community.\n" +
        "Allowed categories: " + SERVER_BAN_CATS.join(", ") + ".\n" +
        "ONLY flag serious server-bannable violations:\n" +
        "- terrorism (HIGHEST PRIORITY): supporting, praising, glorifying, justifying, defending, pledging allegiance to, or recruiting for terrorist organizations or violent extremist groups (e.g., ISIS/Daesh/داعش, Al-Qaeda/القاعدة, violent extremist militias, neo-Nazi/white-supremacist terrorists), distributing terrorist propaganda/nasheeds/beheading/attack videos, inciting terrorist attacks, suicide bombings, mass shootings, calling to kill/slaughter civilians or religious/ethnic groups, or sharing bomb/explosive/weapon-making instructions.\n" +
        "- sexual/minors (HIGHEST PRIORITY): CSAM, child sexual exploitation, grooming minors, or sexualizing minors.\n" +
        "- violence: credible threats of real-world murder/bombings/shootings, organizing violent attacks, or extreme graphic gore/beheadings.\n" +
        "- self-harm: encouraging, praising, or instructing suicide or self-harm.\n" +
        "- illicit: selling illegal weapons/explosives/drugs, cybercrime/malware/DDoS/stolen cards, or human trafficking.\n" +
        "- hate: severe violent hate speech calling for death, violence, extermination, or extreme dehumanization against protected religious/ethnic groups (especially by server admins).\n" +
        "- doxxing: exposing someone's private address, phone, ID, or IP to incite real-world harm/swatting.\n" +
        "- sexual: non-consensual intimate images (revenge porn) or explicit pornography posted by staff in non-NSFW channels.\n" +
        "STRICT ANTI-NOISE RULES:\n" +
        "- DO NOT flag mild swearing, casual insults, arguments, memes, gaming talk, mild spam, or ordinary religious/political debate.\n" +
        "- DO NOT flag neutral news reporting, historical quotes, or messages CONDEMNING / REFUTING terrorism or extremism.\n" +
        "- Only flag messages with strong, clear evidence (score >= 0.75) that justify reporting to Discord Trust & Safety for server enforcement.\n" +
        "ALWAYS write \"reason\" in clear, concise Arabic explaining specifically WHY this message is dangerous and warrants a Discord Trust & Safety server report (even if the message is in English or another language).\n" +
        "Respond with ONLY valid JSON (no markdown, no explanation): " +
        "{\"flags\":[{\"i\":0,\"cats\":[\"terrorism\"],\"score\":0.95,\"reason\":\"سبب المنع بوضوح بالعربية\"}]}. " +
        "Return {\"flags\":[]} if none are severe server-ban violations.";

    var CLASSIFY_ALL_SYSTEM =
        "You are a strict, accurate multilingual content-safety classifier auditing Discord messages in ALL languages (especially Arabic — Modern Standard, dialects, Arabizi, coded spelling — and English, plus any other language).\n" +
        "Allowed categories: " + ALL_AI_CATS.join(", ") + ".\n" +
        "- terrorism: praising, promoting, glorifying, justifying, pledging allegiance to, or recruiting for terrorist/violent extremist groups (ISIS/Daesh/داعش, Al-Qaeda/القاعدة, neo-Nazi terror, etc.), terrorist propaganda/beheading/attack media, inciting attacks, or bomb/explosive instructions (do NOT flag neutral news or condemnation).\n" +
        "- sexual/minors: CSAM, child exploitation, grooming.\n" +
        "- self-harm: suicide or self-harm encouragement/intent.\n" +
        "- violence: direct threats, inciting violence, graphic gore.\n" +
        "- illicit: illegal drugs, weapons, stolen cards/accounts, hacking/malware.\n" +
        "- hate: slurs, dehumanization, hate speech.\n" +
        "- harassment: severe abuse, bullying, sexual harassment.\n" +
        "- sexual: explicit porn, nudes leaks, sexual solicitation.\n" +
        "- scam: phishing, fake Nitro/Steam gifts, crypto scams.\n" +
        "- doxxing: exposing private phone, address, ID, or IP.\n" +
        "ALWAYS write \"reason\" in clear, concise Arabic.\n" +
        "Respond with ONLY valid JSON: {\"flags\":[{\"i\":0,\"cats\":[\"terrorism\"],\"score\":0.95,\"reason\":\"سبب المنع بالعربية\"}]}. Return {\"flags\":[]} if none violate.";

    function getActiveSystemPrompt() {
        return cfg.auditMode === "server_ban" ? CLASSIFY_SERVER_BAN_SYSTEM : CLASSIFY_ALL_SYSTEM;
    }

    function buildUserPrompt(texts) {
        var listing = texts.map(function (t, i) {
            return i + ": " + JSON.stringify(t);
        }).join("\n");
        return "Audit these " + texts.length + " Discord messages (in any language):\n" + listing;
    }

    function parseAiFlags(rawText, count, sourceLabel) {
        var out = [];
        for (var k = 0; k < count; k++) out.push([]);
        if (!rawText || typeof rawText !== "string") return out;

        var cleaned = rawText
            .replace(/<think>[\s\S]*?<\/think>/gi, "")
            .replace(/```(?:json)?/gi, "")
            .replace(/```/g, "")
            .trim();

        var parsed = null;
        try { parsed = JSON.parse(cleaned); } catch (e) {}
        if (!parsed) {
            var objMatch = cleaned.match(/\{[\s\S]*\}/);
            if (objMatch) { try { parsed = JSON.parse(objMatch[0]); } catch (e2) {} }
        }
        if (!parsed) {
            var arrMatch = cleaned.match(/\[[\s\S]*\]/);
            if (arrMatch) { try { parsed = JSON.parse(arrMatch[0]); } catch (e3) {} }
        }

        var arr = Array.isArray(parsed)
            ? parsed
            : (parsed && Array.isArray(parsed.flags) ? parsed.flags : (parsed && Array.isArray(parsed.results) ? parsed.results : []));

        var severeOnly = cfg.auditMode === "server_ban";

        for (var a = 0; a < arr.length; a++) {
            var it = arr[a] || {};
            var idx = Number(it.i);
            if (!(idx >= 0 && idx < count)) continue;
            var sc = Number(it.score);
            if (!(sc >= 0)) sc = 0.8;
            var cats = Array.isArray(it.cats) ? it.cats : (it.cat ? [it.cat] : []);
            for (var c = 0; c < cats.length; c++) {
                var catId = String(cats[c] || "").trim().toLowerCase();
                var catObj = CATS[catId];
                if (!catObj) continue;
                if (severeOnly && !catObj.banRisk) continue;
                var isTopPriority = catId === "sexual/minors" || catId === "terrorism";
                var minLimit = severeOnly
                    ? (isTopPriority ? Math.max(Math.min(cfg.threshold, 0.65), 0.5) : Math.max(cfg.threshold, 0.72))
                    : (isTopPriority ? Math.min(cfg.threshold, 0.35) : cfg.threshold);
                if (sc < minLimit) continue;
                out[idx].push({ cat: catId, score: sc, reason: it.reason ? String(it.reason) : (sourceLabel + ": " + catObj.label) });
            }
        }
        return out;
    }

    function makeHttpError(status, message, headersObj) {
        var err = new Error(message || ("HTTP " + status));
        err.status = status;
        try {
            if (headersObj && typeof headersObj.get === "function") {
                var ra = headersObj.get("retry-after");
                if (ra) {
                    var sec = parseFloat(ra);
                    if (!isNaN(sec) && sec > 0) err.retryAfterSec = sec;
                }
            }
        } catch (e) {}
        return err;
    }

    function openaiModerate(texts, apiKeyOverride) {
        var key = String(apiKeyOverride !== undefined ? apiKeyOverride : (getProviderKeys("openai")[0] || "")).trim();
        if (!key) return Promise.reject(makeHttpError(401, "مفتاح OpenAI غير محفوظ"));
        if (texts.length > 30) {
            return openaiModerate(texts.slice(0, 30), key).then(function (first) {
                return openaiModerate(texts.slice(30), key).then(function (rest) {
                    return first.concat(rest);
                });
            });
        }
        return fetch("https://api.openai.com/v1/moderations", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + key
            },
            body: JSON.stringify({ model: "omni-moderation-latest", input: texts })
        }).then(function (r) {
            return r.text().then(function (raw) {
                var j = null;
                try { j = JSON.parse(raw); } catch (e) {}
                if (!r.ok) throw makeHttpError(r.status, (j && j.error && j.error.message) || ("HTTP " + r.status), r.headers);
                return j || {};
            });
        }).then(function (j) {
            var out = [];
            var results = (j && j.results) || [];
            var severeOnly = cfg.auditMode === "server_ban";
            for (var i = 0; i < texts.length; i++) {
                var res = results[i] || {};
                var scores = res.category_scores || {};
                var flags = res.categories || {};
                var hits = [];
                var seen = {};
                for (var k in OPENAI_MAP) {
                    if (!Object.prototype.hasOwnProperty.call(OPENAI_MAP, k)) continue;
                    var our = OPENAI_MAP[k];
                    if (severeOnly && !(CATS[our] && CATS[our].banRisk)) continue;
                    var s = Number(scores[k] || 0);
                    var limit = k === "sexual/minors" ? Math.min(cfg.threshold, 0.3) : (severeOnly ? Math.max(cfg.threshold, 0.7) : cfg.threshold);
                    if (flags[k] === true || s >= limit) {
                        if (!seen[our] || seen[our].score < s) {
                            seen[our] = { cat: our, score: s, reason: "OpenAI: " + k + " (" + Math.round(s * 100) + "%)" };
                        }
                    }
                }
                for (var c in seen) if (Object.prototype.hasOwnProperty.call(seen, c)) hits.push(seen[c]);
                out.push(hits);
            }
            return out;
        });
    }

    function geminiModerate(texts, apiKeyOverride, modelOverride) {
        var key = String(apiKeyOverride !== undefined ? apiKeyOverride : (getProviderKeys("gemini")[0] || "")).trim();
        var model = String(modelOverride !== undefined ? modelOverride : (getProviderModels("gemini")[0] || "gemini-2.5-flash")).trim();
        if (!key) return Promise.reject(makeHttpError(401, "مفتاح Gemini غير محفوظ"));
        var url = "https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(model) + ":generateContent";
        return fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": key },
            body: JSON.stringify({
                systemInstruction: { parts: [{ text: getActiveSystemPrompt() }] },
                contents: [{ role: "user", parts: [{ text: buildUserPrompt(texts) }] }],
                generationConfig: { temperature: 0, responseMimeType: "application/json" },
                safetySettings: [
                    { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
                    { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
                ]
            })
        }).then(function (r) {
            return r.text().then(function (raw) {
                var j = null;
                try { j = JSON.parse(raw); } catch (e) {}
                if (!r.ok) throw makeHttpError(r.status, (j && j.error && j.error.message) || ("HTTP " + r.status), r.headers);
                return j || {};
            });
        }).then(function (j) {
            var blocked = (j && j.promptFeedback && j.promptFeedback.blockReason) ||
                (j && j.candidates && j.candidates[0] && (j.candidates[0].finishReason === "SAFETY" || j.candidates[0].finishReason === "PROHIBITED_CONTENT") && j.candidates[0].finishReason);
            if (blocked) {
                var err = new Error("BLOCKED");
                err.blocked = String(blocked);
                throw err;
            }
            var txt = "";
            try { txt = j.candidates[0].content.parts.map(function (p) { return p.text || ""; }).join(""); } catch (e) {}
            return parseAiFlags(txt, texts.length, "Gemini");
        });
    }

    function openaiCompatModerate(providerId, texts, apiKeyOverride, modelOverride) {
        var p = PROVIDERS[providerId];
        var endpoint = p.urlProp ? normalizeChatEndpoint(cfg[p.urlProp]) : p.endpoint;
        var apiKey = String(apiKeyOverride !== undefined ? apiKeyOverride : (getProviderKeys(providerId)[0] || "")).trim();
        var model = String(modelOverride !== undefined ? modelOverride : (getProviderModels(providerId)[0] || "")).trim();
        if (!endpoint) return Promise.reject(new Error("رابط الـ API فارغ"));
        if (!model) return Promise.reject(new Error("اسم النموذج فارغ"));
        if (!apiKey && !p.keyOptional) return Promise.reject(makeHttpError(401, "مفتاح الـ API غير محفوظ"));

        var headers = { "Content-Type": "application/json" };
        var bearer = apiKey || p.defaultBearer || "";
        if (bearer) headers["Authorization"] = "Bearer " + bearer;
        if (p.extraHeaders) {
            for (var hk in p.extraHeaders) {
                if (Object.prototype.hasOwnProperty.call(p.extraHeaders, hk)) headers[hk] = p.extraHeaders[hk];
            }
        }

        return fetch(endpoint, {
            method: "POST",
            headers: headers,
            body: JSON.stringify({
                model: model,
                temperature: 0,
                messages: [
                    { role: "system", content: getActiveSystemPrompt() },
                    { role: "user", content: buildUserPrompt(texts) }
                ]
            })
        }).then(function (r) {
            return r.text().then(function (raw) {
                var j = null;
                try { j = JSON.parse(raw); } catch (e) {}
                if (!r.ok) {
                    var msg = (j && j.error && (j.error.message || (typeof j.error === "string" ? j.error : ""))) ||
                        (j && j.message) || ("HTTP " + r.status);
                    throw makeHttpError(r.status, msg, r.headers);
                }
                if (!j) throw new Error("استجابة غير صالحة من الخادم");
                return j;
            });
        }).then(function (j) {
            var ch = j && j.choices && j.choices[0];
            if (ch && ch.finish_reason === "content_filter") {
                var err = new Error("BLOCKED");
                err.blocked = "content_filter";
                throw err;
            }
            var txt = "";
            if (ch && ch.message) {
                if (typeof ch.message.content === "string") txt = ch.message.content;
                else if (Array.isArray(ch.message.content)) {
                    txt = ch.message.content.map(function (part) { return (part && part.text) || ""; }).join("");
                }
            }
            if (!txt && ch && ch.message && ch.message.refusal) {
                var rErr = new Error("BLOCKED");
                rErr.blocked = "refusal";
                throw rErr;
            }
            return parseAiFlags(txt, texts.length, p.sourceName);
        });
    }

    function fetchServerModels(baseUrl, apiKey, defaultBearer) {
        var url = normalizeModelsEndpoint(baseUrl);
        if (!url) return Promise.reject(new Error("رابط الخادم فارغ"));
        var headers = {};
        var bearer = String(apiKey || defaultBearer || "").trim();
        if (bearer) headers["Authorization"] = "Bearer " + bearer;
        return fetch(url, { method: "GET", headers: headers }).then(function (r) {
            return r.text().then(function (raw) {
                var j = null;
                try { j = JSON.parse(raw); } catch (e) {}
                if (!r.ok) throw makeHttpError(r.status, (j && j.error && j.error.message) || ("HTTP " + r.status), r.headers);
                var data = (j && Array.isArray(j.data)) ? j.data : (Array.isArray(j) ? j : []);
                var ids = [];
                for (var i = 0; i < data.length && ids.length < 15; i++) {
                    var id = data[i] && (data[i].id || data[i].name);
                    if (id && ids.indexOf(String(id)) === -1) ids.push(String(id));
                }
                return ids;
            });
        });
    }

    function runProviderModerate(providerId, texts, apiKeyOverride, modelOverride) {
        if (providerId === "openai") return openaiModerate(texts, apiKeyOverride);
        if (providerId === "gemini") return geminiModerate(texts, apiKeyOverride, modelOverride);
        return openaiCompatModerate(providerId, texts, apiKeyOverride, modelOverride);
    }

    // ===================== التبديل التلقائي بين المفاتيح والمزوّدات =====================
    var keyHealth = {};          // keyId -> { cooldownUntil, kind, reason, lastOk }
    var slotHealth = {};         // keyId + "::" + model -> { cooldownUntil, kind, reason }
    var providerKeyCursor = {};  // providerId -> next preferred key index
    var lastUsedProvider = "";
    var lastUsedKeyId = "";

    function makeKeyId(pid, key) {
        return pid + "::" + (key || "NOKEY");
    }

    function resetAllKeyCooldowns() {
        keyHealth = {};
        slotHealth = {};
        providerKeyCursor = {};
        state.lastError = "";
        emitState();
    }

    function getKeyBadgeInfo(pid, key) {
        var kid = makeKeyId(pid, key);
        var info = keyHealth[kid];
        var now = Date.now();
        if (!info) {
            return { text: "جاهز", color: "#949BA4", cooling: false };
        }
        if (info.cooldownUntil && info.cooldownUntil > now) {
            var sec = Math.ceil((info.cooldownUntil - now) / 1000);
            var minTxt = sec >= 90 ? (Math.ceil(sec / 60) + " د") : (sec + " ث");
            if (info.kind === "auth") return { text: "❌ مفتاح غير صالح (" + minTxt + ")", color: "#F23F43", cooling: true };
            if (info.kind === "quota") return { text: "⏳ انتهت الحصة (" + minTxt + ")", color: "#F0B232", cooling: true };
            if (info.kind === "net") return { text: "🔌 الخادم غير متصل (" + minTxt + ")", color: "#F0B232", cooling: true };
            return { text: "⏳ ضغط مؤقت (" + minTxt + ")", color: "#F0B232", cooling: true };
        }
        if (lastUsedKeyId === kid) return { text: "⚡ نشط ويعمل", color: "#23A55A", cooling: false };
        if (info.lastOk) return { text: "✅ يعمل", color: "#23A55A", cooling: false };
        return { text: "جاهز", color: "#949BA4", cooling: false };
    }

    function classifyApiError(err) {
        var status = Number(err && err.status) || 0;
        var msg = String((err && err.message) || err || "");
        var low = msg.toLowerCase();

        // مفتاح غير صالح / منتهي / غير مصرح
        if (status === 401 || status === 403 || /invalid.*api.?key|incorrect.*api.?key|unauthorized|api.?key.*not.?valid|revoked|expired|authentication/.test(low)) {
            return { rotate: true, scope: "key", kind: "auth", cooldownMs: 60 * 60 * 1000 };
        }
        // نفاد الرصيد أو الحصة اليومية (402 / quota / credits)
        if (status === 402 || /insufficient.*credit|out of credit|quota|resource_exhausted|exceeded.*quota|daily.*limit|rpd|tpd|spend.*limit|billing|balance|payment required|free.*limit|limit.*reached/.test(low)) {
            var qMs = (err && err.retryAfterSec) ? Math.max(120000, Math.min(3600000, err.retryAfterSec * 1000)) : (15 * 60 * 1000);
            return { rotate: true, scope: "key", kind: "quota", cooldownMs: qMs };
        }
        // حد سرعة مؤقت (429 / RPM / TPM)
        if (status === 429 || /rate.?limit|too many requests|requests per min|tokens per min|rpm|tpm|try again/.test(low)) {
            var rMs = (err && err.retryAfterSec) ? Math.max(30000, Math.min(300000, err.retryAfterSec * 1000)) : 70000;
            return { rotate: true, scope: "key", kind: "rate", cooldownMs: rMs };
        }
        // النموذج غير متوفر أو مزدحم (404 / 502 / 503 / 529)
        if (status === 404 || status === 502 || status === 503 || status === 529 || /overloaded|temporarily unavailable|no endpoints|model.*not found|capacity|upstream/.test(low)) {
            return { rotate: true, scope: "slot", kind: "model", cooldownMs: 90000 };
        }
        // خطأ اتصال / خادم محلي غير شغّال (مثل OmniRoute متوقف)
        if (status === 0 && /network request failed|failed to fetch|econnrefused|connection refused|timeout|aborted/.test(low)) {
            return { rotate: true, scope: "key", kind: "net", cooldownMs: 60000 };
        }
        return { rotate: false, scope: "slot", kind: "err", cooldownMs: 0 };
    }

    function buildCandidateSlots() {
        var order = [];
        if (cfg.provider && cfg.provider !== "local" && isProviderReady(cfg.provider, false)) {
            order.push(cfg.provider);
        }
        if (cfg.autoFailoverProviders) {
            for (var i = 0; i < PROVIDER_ORDER.length; i++) {
                var pid = PROVIDER_ORDER[i];
                if (pid !== "local" && pid !== cfg.provider && isProviderReady(pid, true)) {
                    order.push(pid);
                }
            }
        }
        var slots = [];
        for (var p = 0; p < order.length; p++) {
            var id = order[p];
            var pInfo = PROVIDERS[id];
            var keys = getProviderKeys(id);
            if (keys.length === 0 && pInfo.keyOptional) keys = [""];
            var models = getProviderModels(id);
            var startCursor = (providerKeyCursor[id] || 0) % Math.max(1, keys.length);
            for (var kOff = 0; kOff < keys.length; kOff++) {
                var kIdx = (startCursor + kOff) % keys.length;
                for (var mIdx = 0; mIdx < models.length; mIdx++) {
                    slots.push({
                        providerId: id,
                        sourceName: pInfo.sourceName,
                        keyIdx: kIdx,
                        key: keys[kIdx],
                        keyId: makeKeyId(id, keys[kIdx]),
                        model: models[mIdx],
                        slotId: makeKeyId(id, keys[kIdx]) + "::" + models[mIdx]
                    });
                }
            }
        }
        return slots;
    }

    function getSlotCooldownUntil(slot) {
        var kh = keyHealth[slot.keyId];
        var sh = slotHealth[slot.slotId];
        var t1 = (kh && kh.cooldownUntil) || 0;
        var t2 = (sh && sh.cooldownUntil) || 0;
        return Math.max(t1, t2);
    }

    function moderateWithFailover(texts) {
        var allSlots = buildCandidateSlots();
        if (allSlots.length === 0) {
            return Promise.reject(new Error("لا يوجد مفتاح API جاهز لأي مزوّد"));
        }

        var now = Date.now();
        var ready = [];
        var soonestWaitMs = Infinity;
        for (var i = 0; i < allSlots.length; i++) {
            var until = getSlotCooldownUntil(allSlots[i]);
            if (until <= now) {
                ready.push(allSlots[i]);
            } else {
                var rem = until - now;
                if (rem < soonestWaitMs) soonestWaitMs = rem;
            }
        }

        if (ready.length === 0) {
            var waitErr = new Error("كل المفاتيح في استراحة مؤقتة");
            waitErr.allCooldown = true;
            waitErr.waitMs = Math.max(10000, Math.min(60000, isFinite(soonestWaitMs) ? soonestWaitMs : 25000));
            return Promise.reject(waitErr);
        }

        var idx = 0;
        var lastErr = null;

        function tryNext() {
            if (idx >= ready.length) {
                var now2 = Date.now();
                var minRem = Infinity;
                var anyCooling = false;
                for (var j = 0; j < allSlots.length; j++) {
                    var u2 = getSlotCooldownUntil(allSlots[j]);
                    if (u2 > now2) {
                        anyCooling = true;
                        if ((u2 - now2) < minRem) minRem = u2 - now2;
                    }
                }
                if (anyCooling) {
                    var ce = new Error((lastErr && lastErr.message) || "انتهت حصة كل المفاتيح مؤقتاً");
                    ce.allCooldown = true;
                    ce.waitMs = Math.max(10000, Math.min(60000, isFinite(minRem) ? minRem : 25000));
                    return Promise.reject(ce);
                }
                return Promise.reject(lastErr || new Error("فشل الاتصال بجميع المفاتيح"));
            }

            var slot = ready[idx++];
            return runProviderModerate(slot.providerId, texts, slot.key, slot.model).then(function (results) {
                keyHealth[slot.keyId] = { cooldownUntil: 0, kind: "ok", reason: "", lastOk: Date.now() };
                delete slotHealth[slot.slotId];
                providerKeyCursor[slot.providerId] = slot.keyIdx;
                var prevProv = lastUsedProvider;
                lastUsedProvider = slot.providerId;
                lastUsedKeyId = slot.keyId;
                state.activeRoute = slot.sourceName + " (#" + (slot.keyIdx + 1) + " " + maskKey(slot.key) + ")";
                if (prevProv && prevProv !== slot.providerId && cfg.toast) {
                    showToast("🔄 تم التحويل تلقائياً إلى " + state.activeRoute);
                }
                return {
                    results: results,
                    sourceLabel: slot.sourceName,
                    providerId: slot.providerId,
                    keyIdx: slot.keyIdx,
                    model: slot.model
                };
            }).catch(function (err) {
                if (err && err.blocked) throw err; // الحجب خاص بالنص نفسه وليس بالمفتاح
                lastErr = err;
                var cl = classifyApiError(err);
                var nowFail = Date.now();
                if (cl.rotate) {
                    if (cl.scope === "key") {
                        keyHealth[slot.keyId] = {
                            cooldownUntil: nowFail + cl.cooldownMs,
                            kind: cl.kind,
                            reason: String((err && err.message) || err),
                            lastOk: (keyHealth[slot.keyId] && keyHealth[slot.keyId].lastOk) || 0
                        };
                        var pKeys = getProviderKeys(slot.providerId);
                        if (pKeys.length > 1) {
                            providerKeyCursor[slot.providerId] = (slot.keyIdx + 1) % pKeys.length;
                        }
                    } else {
                        slotHealth[slot.slotId] = {
                            cooldownUntil: nowFail + cl.cooldownMs,
                            kind: cl.kind,
                            reason: String((err && err.message) || err)
                        };
                    }
                    state.keyRotations++;
                    state.lastError = slot.sourceName + " (#" + (slot.keyIdx + 1) + "): " + String((err && err.message) || err);
                    emitState();
                    // تخطَّ بقية نماذج نفس المفتاح فوراً إذا كان الخطأ على مستوى المفتاح كله
                    while (cl.scope === "key" && idx < ready.length && ready[idx].keyId === slot.keyId) {
                        idx++;
                    }
                    return tryNext();
                }
                throw err;
            });
        }
        return tryNext();
    }

    // ===================== البحث في الخادم المحدد عن رسائل الإدارة فقط =====================
    function apiGet(url, query) {
        if (!mods.RestAPI || typeof mods.RestAPI.get !== "function") {
            return Promise.reject(new Error("وحدة RestAPI غير متوفرة حالياً"));
        }
        var req = { url: url };
        if (query) req.query = query;
        return Promise.resolve(mods.RestAPI.get(req)).then(function (res) {
            if (res && res.body !== undefined) return { status: res.status || 200, body: res.body };
            return { status: 200, body: res };
        });
    }

    function extractRetryMs(errOrRes) {
        try {
            if (errOrRes && errOrRes.body && typeof errOrRes.body.retry_after === "number") {
                return Math.ceil(errOrRes.body.retry_after * 1000) + 1000;
            }
            if (errOrRes && errOrRes.headers && errOrRes.headers["retry-after"]) {
                var s = parseFloat(errOrRes.headers["retry-after"]);
                if (!isNaN(s)) return Math.ceil(s * 1000) + 1000;
            }
        } catch (e) {}
        return 4500;
    }

    function searchAdminPage(guildId, authorId, offset) {
        function attempt(tries) {
            if (stopped || serverSearch.stopRequested) return Promise.resolve({ stopped: true });
            return apiGet("/guilds/" + guildId + "/messages/search", {
                author_id: authorId,
                sort_by: "timestamp",
                sort_order: "desc",
                offset: offset
            }).then(function (res) {
                if (res && res.status === 202 && tries < 5) {
                    var wait = extractRetryMs(res);
                    serverSearch.status = "ديسكورد يجهّز فهرس البحث… انتظار " + Math.ceil(wait / 1000) + " ث";
                    emitState();
                    return sleep(wait).then(function () { return attempt(tries + 1); });
                }
                var body = (res && res.body) || {};
                var groups = Array.isArray(body.messages) ? body.messages : [];
                var hits = [];
                for (var i = 0; i < groups.length; i++) {
                    var g = groups[i];
                    if (Array.isArray(g)) {
                        for (var j = 0; j < g.length; j++) {
                            var m = g[j];
                            if (m && m.hit && m.author && String(m.author.id) === authorId) {
                                cacheAuthorName(m.author);
                                hits.push(m);
                            }
                        }
                    } else if (g && g.author && String(g.author.id) === authorId) {
                        cacheAuthorName(g.author);
                        hits.push(g);
                    }
                }
                return {
                    messages: hits,
                    totalResults: Number(body.total_results || 0),
                    rawCount: groups.length
                };
            }).catch(function (err) {
                var status = err && err.status;
                if (status === 429 && tries < 5) {
                    var waitMs = extractRetryMs(err);
                    serverSearch.status = "حد مؤقت للبحث… انتظار " + Math.ceil(waitMs / 1000) + " ث";
                    emitState();
                    return sleep(waitMs).then(function () { return attempt(tries + 1); });
                }
                throw err;
            });
        }
        return attempt(0);
    }

    function emptyProgress(guildId) {
        return {
            guildId: guildId || "",
            admins: {},
            fetchedTotal: 0,
            queuedTotal: 0,
            updatedAt: 0
        };
    }

    function getProgressForGuild(guildId) {
        var sp = cfg.searchProgress;
        if (sp && typeof sp === "object" && sp.guildId === guildId && sp.admins && typeof sp.admins === "object") {
            return sp;
        }
        return emptyProgress(guildId);
    }

    function getSearchSummary(guildId, adminList, maxMsgs) {
        var total = adminList.length;
        var maxM = Math.max(25, Number(maxMsgs) || Number(cfg.searchDepth) || 75);
        var prog = getProgressForGuild(guildId);
        var doneCount = 0;
        var startedCount = 0;
        var nextAdminId = "";
        var nextOffset = 0;
        for (var i = 0; i < total; i++) {
            var uid = adminList[i];
            var ap = prog.admins[uid];
            var isDone = !!(ap && (ap.reachedEnd || (Number(ap.nextOffset) || 0) >= maxM));
            if (isDone) {
                doneCount++;
            } else {
                if (!nextAdminId) {
                    nextAdminId = uid;
                    nextOffset = (ap && Number(ap.nextOffset)) || 0;
                }
                if (ap && (Number(ap.nextOffset) || 0) > 0) startedCount++;
            }
        }
        return {
            total: total,
            doneCount: doneCount,
            remainingCount: total - doneCount,
            startedCount: startedCount,
            hasProgress: doneCount > 0 || startedCount > 0,
            allDone: total > 0 && doneCount === total,
            nextAdminId: nextAdminId,
            nextOffset: nextOffset,
            fetchedTotal: Number(prog.fetchedTotal) || 0,
            queuedTotal: Number(prog.queuedTotal) || 0
        };
    }

    function persistSearchProgress(prog) {
        try {
            var copy = {
                guildId: prog.guildId,
                admins: JSON.parse(JSON.stringify(prog.admins || {})),
                fetchedTotal: prog.fetchedTotal || 0,
                queuedTotal: prog.queuedTotal || 0,
                updatedAt: Date.now()
            };
            saveCfg({ searchProgress: copy });
        } catch (e) {}
    }

    function stopServerAdminSearch() {
        if (!serverSearch.running) return;
        serverSearch.stopRequested = true;
        serverSearch.status = "جارٍ الإيقاف وحفظ نقطة التوقف…";
        emitState();
    }

    function startServerAdminSearch(forceNewOnly) {
        if (serverSearch.running) return;
        var guildId = extractSingleIdOrWebhook(cfg.targetGuildId);
        if (!guildId || isWebhookUrl(guildId)) {
            showToast("حدّد معرّف الخادم (Server ID) أولاً");
            return;
        }
        var admins = extractSnowflakes(cfg.targetUserIds);
        if (admins.count === 0) {
            showToast("أضف معرّفات الإدارة (User IDs) أولاً");
            return;
        }
        if (!cfg.enabled) saveCfg({ enabled: true });
        if (!cfg.filterUsersOnly) saveCfg({ filterUsersOnly: true });

        var maxMsgsPerAdmin = Math.max(25, Number(cfg.searchDepth) || 75);
        var maxPages = Math.max(1, Math.ceil(maxMsgsPerAdmin / 25));

        var prog = getProgressForGuild(guildId);
        if (prog !== cfg.searchProgress) {
            cfg.searchProgress = prog;
            persistSearchProgress(prog);
        }

        var summary = getSearchSummary(guildId, admins.list, maxMsgsPerAdmin);
        var checkNewOnly = !!forceNewOnly || summary.allDone;

        serverSearch.running = true;
        serverSearch.stopRequested = false;
        serverSearch.adminIndex = summary.doneCount;
        serverSearch.adminTotal = admins.count;
        serverSearch.currentAdmin = "";
        serverSearch.fetchedMsgs = prog.fetchedTotal || 0;
        serverSearch.queuedMsgs = prog.queuedTotal || 0;
        serverSearch.lastError = "";
        serverSearch.status = checkNewOnly
            ? ("فحص الرسائل الجديدة فقط لـ " + admins.count + " إداري…")
            : (summary.hasProgress
                ? ("▶️ متابعة البحث من حيث توقف (المكتمل: " + summary.doneCount + "/" + admins.count + ")…")
                : ("بدء البحث عن رسائل " + admins.count + " إداري…"));
        emitState();
        showToast(checkNewOnly
            ? "🔎 فحص الرسائل الجديدة للإدارة فقط…"
            : (summary.hasProgress
                ? ("▶️ متابعة البحث (المتبقي " + summary.remainingCount + " إداري)")
                : ("🔎 بدأ البحث في الخادم عن رسائل " + admins.count + " إداري")));

        var idx = 0;
        var newCheckedCount = 0;

        function waitIfAiBacklogged() {
            var maxBacklog = Math.max(40, (Number(cfg.batchSize) || 30) * 2);
            if (stopped || serverSearch.stopRequested || !hasAnyAiProvider() || queue.length < maxBacklog) {
                return Promise.resolve();
            }
            serverSearch.status = "⏳ انتظار الذكاء الاصطناعي لإنهاء الدفعة الحالية (" + queue.length + " رسالة)…";
            emitState();
            return sleep(2000).then(waitIfAiBacklogged);
        }

        function nextAdmin() {
            if (stopped || serverSearch.stopRequested || idx >= admins.list.length) {
                var wasStopped = serverSearch.stopRequested;
                serverSearch.running = false;
                serverSearch.stopRequested = false;
                persistSearchProgress(prog);
                var endSum = getSearchSummary(guildId, admins.list, maxMsgsPerAdmin);
                if (wasStopped) {
                    serverSearch.status = "⏸️ تم الحفظ والتوقف عند " + endSum.doneCount + "/" + admins.count + " إداري — اضغط متابعة للإكمال من نفس النقطة";
                    showToast("⏸️ تم حفظ التقدم — يمكنك المتابعة لاحقاً");
                } else if (checkNewOnly) {
                    serverSearch.status = "✅ اكتمل فحص الجديد لـ " + admins.count + " إداري (جديد للفحص: " + newCheckedCount + ")";
                    showToast("✅ اكتمل فحص الرسائل الجديدة (" + newCheckedCount + " رسالة جديدة)");
                } else {
                    serverSearch.status = "✅ اكتمل البحث لكل الإدارة (" + endSum.doneCount + "/" + admins.count + ") • إجمالي المجلوب: " + prog.fetchedTotal;
                    showToast("✅ اكتمل البحث لكل الإدارة!");
                }
                emitState();
                return;
            }

            var uid = admins.list[idx];
            idx++;
            var ap = prog.admins[uid];
            if (!ap || typeof ap !== "object") {
                ap = { nextOffset: 0, reachedEnd: false, fetched: 0, total: 0, updatedAt: 0 };
                prog.admins[uid] = ap;
            }

            // تخطي فوري للإداريين المكتملين عند وضع المتابعة
            if (!checkNewOnly && (ap.reachedEnd || (Number(ap.nextOffset) || 0) >= maxMsgsPerAdmin)) {
                nextAdmin();
                return;
            }

            serverSearch.adminIndex = idx;
            serverSearch.currentAdmin = resolveUserLabel(uid, guildId) || uid;
            var startPage = checkNewOnly ? 0 : Math.floor((Number(ap.nextOffset) || 0) / 25);
            var endPage = checkNewOnly ? 1 : maxPages;
            serverSearch.status = (checkNewOnly ? "فحص الجديد " : "بحث ") + idx + "/" + admins.count + ": " + serverSearch.currentAdmin + (startPage > 0 ? (" (من رسالة " + (startPage * 25) + ")") : "");
            emitState();

            var page = startPage;
            function nextPage() {
                if (stopped || serverSearch.stopRequested || page >= endPage) {
                    if (!checkNewOnly && !stopped && !serverSearch.stopRequested) {
                        persistSearchProgress(prog);
                    }
                    return sleep(SEARCH_GAP_MS).then(nextAdmin);
                }
                var offset = page * 25;
                return waitIfAiBacklogged().then(function () {
                    if (stopped || serverSearch.stopRequested) return { stopped: true };
                    return searchAdminPage(guildId, uid, offset);
                }).then(function (res) {
                    if (!res || res.stopped) return nextAdmin();
                    var msgs = res.messages || [];
                    var newlyQueued = 0;
                    for (var i = 0; i < msgs.length; i++) {
                        prog.fetchedTotal++;
                        ap.fetched = (ap.fetched || 0) + 1;
                        serverSearch.fetchedMsgs = prog.fetchedTotal;
                        var m = msgs[i];
                        if (!m.guild_id) m.guild_id = guildId;
                        if (enqueueMessage(m, m.channel_id, false)) {
                            prog.queuedTotal++;
                            serverSearch.queuedMsgs = prog.queuedTotal;
                            newlyQueued++;
                            newCheckedCount++;
                        }
                    }
                    ap.total = res.totalResults || ap.total || 0;
                    ap.updatedAt = Date.now();
                    if (!checkNewOnly) {
                        ap.nextOffset = offset + 25;
                        if (res.rawCount < 25 || (offset + 25) >= res.totalResults) {
                            ap.reachedEnd = true;
                        }
                        persistSearchProgress(prog);
                    }
                    serverSearch.currentAdmin = resolveUserLabel(uid, guildId) || uid;
                    serverSearch.status = (checkNewOnly ? "جديد " : "إداري ") + idx + "/" + admins.count + " (" + serverSearch.currentAdmin + ") • أُضيف: " + newlyQueued + " • الإجمالي: " + prog.fetchedTotal;
                    emitState();
                    page++;
                    if (checkNewOnly || res.rawCount < 25 || (offset + 25) >= res.totalResults) {
                        return sleep(SEARCH_GAP_MS).then(nextAdmin);
                    }
                    return sleep(SEARCH_GAP_MS).then(nextPage);
                }).catch(function (err) {
                    var status = err && err.status;
                    serverSearch.lastError = String((err && (err.message || (err.body && err.body.message))) || err);
                    emitState();
                    if (status === 403 || status === 401 || status === 404) {
                        serverSearch.stopRequested = true;
                        serverSearch.status = "❌ لا توجد صلاحية بحث في هذا الخادم (" + status + ")";
                        return nextAdmin();
                    }
                    return sleep(SEARCH_GAP_MS).then(nextAdmin);
                });
            }
            nextPage();
        }
        nextAdmin();
    }

    function scanServerCachedChannels(guildId) {
        var chIds = listGuildChannelIds(guildId);
        var total = 0;
        for (var i = 0; i < chIds.length; i++) {
            total += scanChannel(chIds[i], false);
        }
        return { channels: chIds.length, scanned: total };
    }

    // ===================== إرسال التقارير للمجموعة المحددة =====================
    var forwardQueue = [];
    var forwardRunning = false;
    var forwardedSet = {};

    function formatGroupReport(f) {
        var cat = CATS[f.cat] || { label: f.cat, steps: [], banRisk: false };
        var where = (f.guildName ? f.guildName + " / " : (f.typeLabel === "خاص" ? "خاص / " : "")) + (f.channelName || f.channelId);
        var authorLine = f.authorName + (f.authorUsername ? " (@" + f.authorUsername + ")" : "") + (f.authorId ? " | ID: `" + f.authorId + "`" : "");
        var lines = [
            cat.banRisk ? "🚨🔥 **رصد مخالفة خطيرة موجبة لحظر الخادم — حارس بحر**" : "🚨 **رصد مخالفة — حارس بحر**",
            "• **نوع المخالفة:** " + cat.label + " (" + Math.round((f.score || 0) * 100) + "%)",
            "• **سبب المنع:** " + (f.reason || cat.label),
            "• **الكاتب (الإدارة):** " + authorLine,
            "• **المكان:** " + where,
            "• **رابط الرسالة:** " + messageLink(f),
            "• **الإبلاغ المناسب:** " + cat.steps.join(" ← ")
        ];
        if (f.cat === "sexual/minors") {
            lines.push("⚠️ **تحذير سلامة الأطفال:** لا تفتح أو تحفظ أو تصوّر أو تشارك أي مرفق؛ بلّغ ديسكورد و `https://report.cybertip.org` مباشرة.");
        } else if (f.hasAttach) {
            lines.push("• **ملاحظة:** الرسالة تحتوي مرفقاً (لم يُحلَّل).");
        }
        lines.push("-# Server: `" + (f.guildId || "DM") + "` • Channel: `" + f.channelId + "` • Msg: `" + f.messageId + "` • المحرك: " + (f.source || ""));
        var msg = lines.join("\n");
        if (msg.length > 1950) msg = msg.slice(0, 1945) + "…";
        return msg;
    }

    function postToDestination(target, content) {
        var dest = extractSingleIdOrWebhook(target);
        if (!dest) return Promise.reject(new Error("معرّف المجموعة/القناة غير محدد"));

        if (isWebhookUrl(dest)) {
            return fetch(dest, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content: content })
            }).then(function (r) {
                if (!r.ok) {
                    var err = new Error("Webhook HTTP " + r.status);
                    err.status = r.status;
                    throw err;
                }
                return "sent";
            });
        }

        if (mods.RestAPI && typeof mods.RestAPI.post === "function") {
            return Promise.resolve(mods.RestAPI.post({
                url: "/channels/" + dest + "/messages",
                body: { content: content, tts: false }
            })).then(function () { return "sent"; });
        }
        if (mods.MessageActions && typeof mods.MessageActions.sendMessage === "function") {
            return Promise.resolve(mods.MessageActions.sendMessage(dest, {
                content: content,
                invalidEmojis: [],
                tts: false,
                validNonShortcutEmojis: []
            })).then(function () { return "sent"; });
        }
        return Promise.reject(new Error("وحدة الإرسال غير متاحة حالياً"));
    }

    function markFindingForwarded(messageId) {
        forwardedSet[messageId] = true;
        var list = cfg.findings || [];
        var changed = false;
        for (var i = 0; i < list.length; i++) {
            if (list[i].messageId === messageId && !list[i].forwarded) {
                list[i].forwarded = true;
                changed = true;
            }
        }
        if (changed) saveCfg({ findings: list.slice() });
    }

    function enqueueForward(f, forceResend) {
        var dest = extractSingleIdOrWebhook(cfg.reportChannelId);
        if (!dest || !f || !f.messageId) return false;
        if (!isWebhookUrl(dest) && f.channelId === dest) return false;
        if (!forceResend && (f.forwarded || forwardedSet[f.messageId])) return false;
        forwardedSet[f.messageId] = true;
        forwardQueue.push({ finding: f, tries: 0 });
        state.forwardQueued = forwardQueue.length;
        emitState();
        pumpForward();
        return true;
    }

    function pumpForward() {
        if (forwardRunning || stopped || forwardQueue.length === 0) return;
        forwardRunning = true;
        var step = function () {
            if (stopped || forwardQueue.length === 0) {
                forwardRunning = false;
                state.forwardQueued = forwardQueue.length;
                emitState();
                return;
            }
            var dest = extractSingleIdOrWebhook(cfg.reportChannelId);
            if (!dest) {
                forwardQueue.length = 0;
                forwardRunning = false;
                state.forwardQueued = 0;
                emitState();
                return;
            }
            var jobItem = forwardQueue.shift();
            state.forwardQueued = forwardQueue.length;
            var text = formatGroupReport(jobItem.finding);
            postToDestination(dest, text).then(function () {
                state.lastForwardError = "";
                state.forwarded++;
                markFindingForwarded(jobItem.finding.messageId);
                emitState();
                return sleep(FORWARD_GAP_MS);
            }).catch(function (err) {
                var status = err && err.status;
                var msg = String((err && (err.message || (err.body && err.body.message))) || err);
                state.lastForwardError = msg;
                if (status === 429 && jobItem.tries < 3) {
                    jobItem.tries++;
                    forwardQueue.unshift(jobItem);
                    var retrySec = (err && err.body && Number(err.body.retry_after)) || 6;
                    emitState();
                    return sleep(Math.max(4000, Math.ceil(retrySec * 1000) + 500));
                }
                delete forwardedSet[jobItem.finding.messageId];
                emitState();
                return sleep(FORWARD_GAP_MS);
            }).then(step, step);
        };
        step();
    }

    // ===================== الطابور (بدفعات 30 + تقسيم ثنائي + حفظ دائم للمفحوص) =====================
    var MAX_PERSISTED_SCANNED = 5000;
    var seenIds = {};
    var seenOrder = [];
    var persistedScannedSet = {};
    var scannedSaveTimer = null;
    var queue = [];
    var running = false;
    var stopped = false;
    var nextChunkId = 1;

    function markSeen(id) {
        if (!id || seenIds[id]) return;
        seenIds[id] = 1;
        seenOrder.push(id);
        if (seenOrder.length > 8000) {
            var old = seenOrder.splice(0, 2000);
            for (var i = 0; i < old.length; i++) delete seenIds[old[i]];
        }
    }

    function scheduleSaveScannedIds() {
        if (scannedSaveTimer) return;
        scannedSaveTimer = setTimeout(function () {
            scannedSaveTimer = null;
            try {
                if (!Array.isArray(cfg.scannedIds)) cfg.scannedIds = [];
                if (cfg.scannedIds.length > MAX_PERSISTED_SCANNED) {
                    var dropped = cfg.scannedIds.splice(0, cfg.scannedIds.length - MAX_PERSISTED_SCANNED);
                    for (var i = 0; i < dropped.length; i++) delete persistedScannedSet[dropped[i]];
                }
                saveCfg({ scannedIds: cfg.scannedIds.slice() });
            } catch (e) {}
        }, 2500);
    }

    function markPersistedScanned(id) {
        if (!id || persistedScannedSet[id]) return;
        persistedScannedSet[id] = 1;
        markSeen(id);
        if (!Array.isArray(cfg.scannedIds)) cfg.scannedIds = [];
        cfg.scannedIds.push(String(id));
        scheduleSaveScannedIds();
    }

    function resetAllProgress() {
        if (serverSearch.running) stopServerAdminSearch();
        seenIds = {};
        seenOrder = [];
        persistedScannedSet = {};
        if (scannedSaveTimer) { clearTimeout(scannedSaveTimer); scannedSaveTimer = null; }
        for (var i = 0; i < (cfg.findings || []).length; i++) {
            markSeen(cfg.findings[i].messageId);
        }
        state.scanned = 0;
        serverSearch.fetchedMsgs = 0;
        serverSearch.queuedMsgs = 0;
        serverSearch.status = "";
        serverSearch.lastError = "";
        var gid = extractSingleIdOrWebhook(cfg.targetGuildId);
        if (isWebhookUrl(gid)) gid = "";
        saveCfg({
            scannedIds: [],
            searchProgress: emptyProgress(gid)
        });
    }

    function extractText(msg) {
        var parts = [];
        if (typeof msg.content === "string" && msg.content) parts.push(msg.content);
        var embeds = msg.embeds || [];
        for (var i = 0; i < embeds.length && i < 3; i++) {
            var e = embeds[i] || {};
            if (e.title || e.rawTitle) parts.push(String(e.title || e.rawTitle));
            if (e.description || e.rawDescription) parts.push(String(e.description || e.rawDescription));
        }
        var t = parts.join("\n").trim();
        if (t.length > MAX_TEXT) t = t.slice(0, MAX_TEXT);
        return t;
    }

    function authorOf(msg) {
        var a = msg.author || {};
        if (a && a.id) cacheAuthorName(a);
        return {
            id: String(a.id || ""),
            name: a.globalName || a.global_name || a.username || "مجهول",
            username: a.username || "",
            bot: !!a.bot
        };
    }

    function enqueueMessage(msg, channelId, force) {
        try {
            if (stopped || !cfg.enabled || !msg || !msg.id) return false;
            if (msg._bahrGuard) return false;

            var chId = String(channelId || msg.channel_id || msg.channelId || "");
            var reportDest = extractSingleIdOrWebhook(cfg.reportChannelId);
            if (reportDest && !isWebhookUrl(reportDest) && chId && chId === reportDest) {
                return false;
            }

            var a = authorOf(msg);
            if (a.id === NOTICE_AUTHOR_ID) return false;

            var targetUsers = extractSnowflakes(cfg.targetUserIds);
            var isTargetAdmin = !!(a.id && targetUsers.map[a.id]);
            if (cfg.filterUsersOnly) {
                if (targetUsers.count === 0 || !isTargetAdmin) return false;
            }

            if (cfg.skipOwn && !isTargetAdmin && a.id && a.id === getMyUserId()) return false;

            var targetGuild = extractSingleIdOrWebhook(cfg.targetGuildId);
            if (targetGuild && !isWebhookUrl(targetGuild)) {
                var msgGuild = String(msg.guild_id || msg.guildId || "");
                if (!msgGuild && chId) {
                    var ci = getChannelInfo(chId);
                    msgGuild = String(ci.guildId || "");
                }
                if (msgGuild !== targetGuild) return false;
            }

            var id = String(msg.id);
            if (!force && seenIds[id]) return false;
            markSeen(id);

            var text = extractText(msg);
            var hasAttach = Array.isArray(msg.attachments) && msg.attachments.length > 0;
            if (!text) return false;

            var item = {
                messageId: id,
                channelId: chId,
                guildId: String(msg.guild_id || msg.guildId || ""),
                author: a,
                text: text,
                hasAttach: hasAttach,
                ts: msg.timestamp ? String(msg.timestamp) : new Date().toISOString()
            };

            var aiReady = hasAnyAiProvider();
            if (cfg.provider === "local" || cfg.localAlways || !aiReady) {
                var lh = localDetect(text);
                if (lh.length) recordFinding(item, lh, "محلي");
            }
            if (aiReady) { queue.push(item); }
            else {
                state.scanned++;
                markPersistedScanned(id);
            }
            state.queued = queue.length;
            emitState();
            pump();
            return true;
        } catch (e) {
            return false;
        }
    }

    function popNextBatch(providerId) {
        if (queue.length === 0) return [];
        var pInfo = PROVIDERS[providerId] || {};
        var limit = Math.max(1, Number(cfg.batchSize) || 30);
        if (pInfo.maxBatch && limit > pInfo.maxBatch) limit = pInfo.maxBatch;

        if (queue[0]._chunkId) {
            var cid = queue[0]._chunkId;
            var count = 0;
            while (count < queue.length && queue[count]._chunkId === cid && count < limit) count++;
            return queue.splice(0, count);
        }
        var n = 0;
        while (n < queue.length && n < limit && !queue[n]._chunkId) n++;
        return queue.splice(0, Math.max(1, n));
    }

    function pump() {
        if (running || stopped || queue.length === 0) return;
        running = true;
        state.busy = true;
        emitState();
        var loop = function () {
            if (stopped || queue.length === 0 || !cfg.enabled || !hasAnyAiProvider()) {
                running = false;
                state.busy = false;
                state.queued = queue.length;
                emitState();
                return;
            }
            var activeProvider = lastUsedProvider && isProviderReady(lastUsedProvider) ? lastUsedProvider : cfg.provider;
            var batch = popNextBatch(activeProvider);
            state.queued = queue.length;
            var texts = batch.map(function (b) { return b.text; });

            moderateWithFailover(texts).then(function (out) {
                state.lastError = "";
                var results = (out && out.results) || [];
                var sourceLabel = (out && out.sourceLabel) || "AI";
                for (var i = 0; i < batch.length; i++) {
                    state.scanned++;
                    markPersistedScanned(batch[i].messageId);
                    var hits = results[i] || [];
                    if (hits.length) recordFinding(batch[i], hits, sourceLabel);
                }
            }).catch(function (err) {
                if (err && err.blocked) {
                    if (batch.length > 1) {
                        var mid = Math.floor(batch.length / 2);
                        var leftId = nextChunkId++;
                        var rightId = nextChunkId++;
                        for (var r = batch.length - 1; r >= mid; r--) {
                            batch[r]._chunkId = rightId;
                            queue.unshift(batch[r]);
                        }
                        for (var l = mid - 1; l >= 0; l--) {
                            batch[l]._chunkId = leftId;
                            queue.unshift(batch[l]);
                        }
                    } else {
                        state.scanned++;
                        markPersistedScanned(batch[0].messageId);
                        recordFinding(batch[0], [{ cat: "blocked", score: 1, reason: "نموذج الذكاء الاصطناعي حجب التحليل: " + err.blocked }], state.activeRoute || "AI");
                    }
                } else if (err && err.allCooldown) {
                    var waitMs = Math.max(10000, Math.min(60000, Number(err.waitMs) || 25000));
                    state.lastError = "⏳ انتهت حصة كل المفاتيح مؤقتاً — إعادة المحاولة بعد " + Math.ceil(waitMs / 1000) + " ث…";
                    for (var q = batch.length - 1; q >= 0; q--) {
                        queue.unshift(batch[q]);
                    }
                    state.queued = queue.length;
                    emitState();
                    return sleep(waitMs);
                } else {
                    state.lastError = String((err && err.message) || err);
                    var requeued = false;
                    for (var rq = batch.length - 1; rq >= 0; rq--) {
                        batch[rq]._retries = (batch[rq]._retries || 0) + 1;
                        if (batch[rq]._retries <= 2) {
                            queue.unshift(batch[rq]);
                            requeued = true;
                        }
                    }
                    if (requeued) return sleep(8000);
                    state.scanned += batch.length;
                }
            }).then(function () {
                emitState();
                return sleep(REQUEST_GAP_MS);
            }).then(loop, loop);
        };
        loop();
    }

    // ===================== تسجيل النتائج =====================
    function pickPrimary(hits) {
        var best = null;
        for (var i = 0; i < hits.length; i++) {
            var c = CATS[hits[i].cat];
            if (!c) continue;
            if (!best || c.severity > CATS[best.cat].severity || (c.severity === CATS[best.cat].severity && hits[i].score > best.score)) best = hits[i];
        }
        return best;
    }

    function recordFinding(item, hits, source) {
        var primary = pickPrimary(hits);
        if (!primary) return;
        var list = cfg.findings || [];
        for (var i = 0; i < list.length; i++) {
            if (list[i].messageId === item.messageId) {
                if (CATS[primary.cat].severity > (CATS[list[i].cat] ? CATS[list[i].cat].severity : 0)) {
                    list[i].cat = primary.cat;
                    list[i].score = primary.score;
                    list[i].reason = primary.reason;
                    list[i].source = source;
                    saveCfg({ findings: list.slice() });
                }
                return;
            }
        }
        var info = getChannelInfo(item.channelId);
        var finalGuildId = info.guildId || item.guildId || null;
        var finalGuildName = info.guildName || (finalGuildId ? getGuildName(finalGuildId) : "");
        var cat = CATS[primary.cat];
        var snippet;
        if (cat.hideSnippet) {
            snippet = "[النص مخفي لحمايتك]";
        } else {
            var rawSnippet = item.text.replace(/\s+/g, " ").slice(0, 160);
            if (primary.cat === "doxxing") {
                rawSnippet = rawSnippet
                    .replace(/\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g, "[IP مخفي]")
                    .replace(/\+?\d[\d\s\-]{8,}\d/g, "[رقم مخفي]");
            }
            snippet = rawSnippet;
        }
        var f = {
            messageId: item.messageId,
            channelId: item.channelId,
            guildId: finalGuildId,
            guildName: finalGuildName,
            channelName: info.channelName,
            typeLabel: info.typeLabel,
            authorId: item.author.id,
            authorName: item.author.name,
            authorUsername: item.author.username,
            authorBot: item.author.bot,
            ts: item.ts,
            cat: primary.cat,
            allCats: hits.map(function (h) { return h.cat; }).filter(function (v, idx, arr) { return arr.indexOf(v) === idx; }),
            score: primary.score,
            reason: primary.reason,
            source: source,
            snippet: snippet,
            hasAttach: item.hasAttach,
            forwarded: false,
            foundAt: Date.now()
        };
        list = [f].concat(list).slice(0, MAX_FINDINGS);
        state.flagged++;
        saveCfg({ findings: list });

        var where = (finalGuildName ? finalGuildName + " / " : "") + info.channelName;
        if (cfg.toast) showToast("🛡️ حارس بحر: " + cat.label + " — " + where);
        if (cfg.inChatNotice && item.channelId && item.channelId === getCurrentChannelId()) {
            postLocalNotice(item.channelId, f);
        }
        if (cfg.autoForward && extractSingleIdOrWebhook(cfg.reportChannelId)) {
            enqueueForward(f, false);
        }
    }

    function postLocalNotice(channelId, f) {
        var cat = CATS[f.cat];
        var content =
            "🛡️ **حارس بحر** رصد رسالة مخالفة من **" + f.authorName + "**\n" +
            "النوع: **" + cat.label + "**\n" +
            "سبب المنع: " + (f.reason || cat.label) + "\n" +
            "طريقة الإبلاغ: " + cat.steps.join(" ← ") +
            (cat.extra ? "\n" + cat.extra : "") +
            "\n" + messageLink(f) +
            "\n-# (هذا التنبيه يظهر لك وحدك ولا يُرسل لأحد)";
        var msgObj = {
            id: String(Date.now()) + String(Math.floor(Math.random() * 1000)),
            type: 0,
            channel_id: channelId,
            content: content,
            timestamp: new Date().toISOString(),
            edited_timestamp: null,
            tts: false,
            mention_everyone: false,
            mentions: [],
            mention_roles: [],
            attachments: [],
            embeds: [],
            pinned: false,
            flags: 64,
            state: "SENT",
            _bahrGuard: true,
            author: {
                id: NOTICE_AUTHOR_ID,
                username: "حارس بحر",
                global_name: "حارس بحر 🛡️",
                discriminator: "0000",
                avatar: null,
                bot: true
            }
        };
        setTimeout(function () {
            try {
                if (mods.MessageActions && typeof mods.MessageActions.receiveMessage === "function") {
                    mods.MessageActions.receiveMessage(channelId, msgObj);
                    return;
                }
            } catch (e) {}
            try {
                if (mods.Dispatcher) {
                    mods.Dispatcher.dispatch({ type: "MESSAGE_CREATE", channelId: channelId, message: msgObj, optimistic: false, isPushNotification: false, _bahrGuard: true });
                }
            } catch (e) {}
        }, 300);
    }

    function scanChannel(channelId, force) {
        var n = 0;
        try {
            if (!mods.MessageStore || !channelId) return 0;
            var msgs = mods.MessageStore.getMessages(channelId);
            var arr = msgs && (msgs._array || (typeof msgs.toArray === "function" ? msgs.toArray() : null));
            if (!Array.isArray(arr)) return 0;
            for (var i = 0; i < arr.length; i++) {
                if (enqueueMessage(arr[i], channelId, force)) n++;
            }
        } catch (e) {}
        return n;
    }

    function enqueueMessageArray(rawList, fallbackChannelId) {
        if (!Array.isArray(rawList)) return;
        for (var i = 0; i < rawList.length; i++) {
            var entry = rawList[i];
            if (Array.isArray(entry)) {
                for (var j = 0; j < entry.length; j++) {
                    var sub = entry[j];
                    if (sub && sub.id) enqueueMessage(sub, fallbackChannelId || sub.channel_id || sub.channelId, false);
                }
            } else if (entry && entry.id) {
                enqueueMessage(entry, fallbackChannelId || entry.channel_id || entry.channelId, false);
            }
        }
    }

    // ===================== التشغيل =====================
    exports.default = plugin({
        jsonStorage: {
            load: true,
            default: JSON.parse(JSON.stringify(DEFAULTS))
        },
        start: function (ctx) {
            stopped = false;
            var cleanup = ctx.cleanup;
            var finders = valenced.modules.finders;
            var filters = finders.filters;
            var patcher = valenced.patcher;

            storageRef = ctx.jsonStorage || null;
            var autoResumedOnce = false;
            var applyLoaded = function (c) {
                if (!c || typeof c !== "object") return;
                for (var k in DEFAULTS) {
                    if (Object.prototype.hasOwnProperty.call(DEFAULTS, k) && c[k] !== undefined && typeof c[k] === typeof DEFAULTS[k]) {
                        cfg[k] = c[k];
                    }
                }
                if (!PROVIDERS[cfg.provider]) cfg.provider = "local";
                if (cfg.auditMode !== "server_ban" && cfg.auditMode !== "all") cfg.auditMode = "server_ban";
                if (!(cfg.batchSize >= 5 && cfg.batchSize <= 100)) cfg.batchSize = 30;
                if (!(cfg.searchDepth >= 25 && cfg.searchDepth <= 500)) cfg.searchDepth = 75;
                if (!Array.isArray(cfg.findings)) cfg.findings = [];
                if (!Array.isArray(cfg.scannedIds)) cfg.scannedIds = [];
                if (!cfg.adminNames || typeof cfg.adminNames !== "object" || Array.isArray(cfg.adminNames)) cfg.adminNames = {};
                if (!cfg.searchProgress || typeof cfg.searchProgress !== "object" || !cfg.searchProgress.admins || typeof cfg.searchProgress.admins !== "object") {
                    cfg.searchProgress = emptyProgress("");
                }

                for (var nKey in cfg.adminNames) {
                    if (Object.prototype.hasOwnProperty.call(cfg.adminNames, nKey) && cfg.adminNames[nKey]) {
                        nameCache[nKey] = String(cfg.adminNames[nKey]);
                    }
                }
                for (var s = 0; s < cfg.scannedIds.length; s++) {
                    var sid = String(cfg.scannedIds[s] || "");
                    if (sid) {
                        persistedScannedSet[sid] = 1;
                        markSeen(sid);
                    }
                }
                for (var i = 0; i < cfg.findings.length; i++) {
                    markSeen(cfg.findings[i].messageId);
                    if (cfg.findings[i].forwarded) forwardedSet[cfg.findings[i].messageId] = true;
                }
                emitState();

                if (!autoResumedOnce && cfg.autoResumeSearch && cfg.enabled && !serverSearch.running) {
                    var gid = extractSingleIdOrWebhook(cfg.targetGuildId);
                    var adm = extractSnowflakes(cfg.targetUserIds);
                    if (gid && !isWebhookUrl(gid) && adm.count > 0) {
                        var sum = getSearchSummary(gid, adm.list, cfg.searchDepth);
                        if (sum.hasProgress && !sum.allDone) {
                            autoResumedOnce = true;
                            setTimeout(function () {
                                if (!stopped && cfg.enabled && !serverSearch.running) {
                                    startServerAdminSearch(false);
                                }
                            }, 5000);
                        }
                    }
                }
            };
            if (storageRef) {
                if (storageRef.cache) applyLoaded(storageRef.cache);
                if (typeof storageRef.get === "function") {
                    Promise.resolve(storageRef.get()).then(applyLoaded).catch(function () {});
                }
            }

            try {
                var d = valenced.discord;
                if (d) {
                    if (d.rest) mods.RestAPI = d.rest;
                    if (d.common && d.common.RestAPI && !mods.RestAPI) mods.RestAPI = d.common.RestAPI;
                    if (d.common && d.common.flux && d.common.flux.Dispatcher) mods.Dispatcher = d.common.flux.Dispatcher;
                    if (d.flux && d.flux.Stores) {
                        var S = d.flux.Stores;
                        if (S.UserStore) mods.UserStore = S.UserStore;
                        if (S.GuildMemberStore) mods.GuildMemberStore = S.GuildMemberStore;
                        if (S.ChannelStore) mods.ChannelStore = S.ChannelStore;
                        if (S.GuildChannelStore) mods.GuildChannelStore = S.GuildChannelStore;
                        if (S.GuildStore) mods.GuildStore = S.GuildStore;
                        if (S.SelectedChannelStore) mods.SelectedChannelStore = S.SelectedChannelStore;
                        if (S.MessageStore) mods.MessageStore = S.MessageStore;
                    }
                }
            } catch (e) {}

            try {
                cleanup(finders.getModules(filters.withProps("get", "post", "put", "del"), function (m) {
                    if (m && typeof m.post === "function" && typeof m.get === "function") {
                        if (!mods.RestAPI || typeof m.getAPIBaseURL === "function" || typeof m.patch === "function") {
                            mods.RestAPI = m;
                        }
                    }
                }));
            } catch (e) {}

            var take = function (key, props, check) {
                try {
                    cleanup(finders.getModules(filters.withProps.apply(null, props), function (m) {
                        if (!m) return;
                        if (check && !check(m)) return;
                        if (!mods[key]) mods[key] = m;
                    }));
                } catch (e) {}
            };
            take("UserStore", ["getCurrentUser", "getUser"]);
            take("GuildMemberStore", ["getMember", "getNick"]);
            take("ChannelStore", ["getChannel", "getDMFromUserId"]);
            take("GuildChannelStore", ["getChannels", "getDefaultChannel"]);
            take("GuildStore", ["getGuild", "getGuilds"]);
            take("SelectedChannelStore", ["getChannelId", "getVoiceChannelId"]);
            take("MessageStore", ["getMessage", "getMessages"]);
            take("Toast", ["showToast"]);
            take("MessageActions", ["sendMessage", "receiveMessage"]);
            take("Router", ["transitionTo"], function (m) { return typeof m.transitionTo === "function"; });
            take("URLOpener", ["openURL"], function (m) { return typeof m.openURL === "function"; });
            take("Clipboard", ["setString", "getString"]);

            var hooked = false;
            var hook = function (fd) {
                if (hooked || !fd || typeof fd.dispatch !== "function") return;
                hooked = true;
                mods.Dispatcher = fd;
                try {
                    cleanup(patcher.before(fd, "dispatch", function (args) {
                        try {
                            if (stopped || !cfg.enabled) return args;
                            var action = Array.isArray(args) ? args[0] : args;
                            if (!action || action._bahrGuard || action._arTranslated) return args;
                            if (action.type === "MESSAGE_CREATE" && action.message && cfg.scanNew && !action.optimistic) {
                                var m = action.message;
                                var cid = action.channelId || m.channel_id || m.channelId;
                                setTimeout(function () { enqueueMessage(m, cid, false); }, 0);
                            } else if (action.type === "LOAD_MESSAGES_SUCCESS" && Array.isArray(action.messages) && cfg.scanLoaded) {
                                var list = action.messages.slice();
                                var lcid = action.channelId;
                                setTimeout(function () { enqueueMessageArray(list, lcid); }, 0);
                            } else if ((action.type === "SEARCH_FINISH" || action.type === "SEARCH_MESSAGES_SUCCESS") && cfg.scanLoaded) {
                                var sm = action.messages || (action.data && action.data.messages);
                                if (Array.isArray(sm)) {
                                    var smCopy = sm.slice();
                                    setTimeout(function () { enqueueMessageArray(smCopy, ""); }, 0);
                                }
                            }
                        } catch (e) {}
                        return args;
                    }));
                } catch (e) {}
            };
            if (mods.Dispatcher) hook(mods.Dispatcher);
            try {
                cleanup(finders.getModules(filters.withProps("_interceptors", "dispatch"), function (m) { hook(m); }));
            } catch (e) {}

            cleanup(function () {
                stopped = true;
                serverSearch.stopRequested = true;
                if (scannedSaveTimer) {
                    clearTimeout(scannedSaveTimer);
                    scannedSaveTimer = null;
                    try { saveCfg({ scannedIds: (cfg.scannedIds || []).slice(-MAX_PERSISTED_SCANNED) }); } catch (e) {}
                }
                if (nameSaveTimer) {
                    clearTimeout(nameSaveTimer);
                    nameSaveTimer = null;
                }
                queue.length = 0;
                forwardQueue.length = 0;
                state.queued = 0;
                state.forwardQueued = 0;
                state.busy = false;
            });
        },

        // ===================== واجهة الإعدادات =====================
        SettingsComponent: function (props) {
            var R = getReact();
            var RN = getRN();
            if (!R || !RN) return null;
            if (!storageRef && props && props.api && props.api.jsonStorage) {
                storageRef = props.api.jsonStorage;
            }
            var View = RN.View, Text = RN.Text, ScrollView = RN.ScrollView, TouchableOpacity = RN.TouchableOpacity, TextInput = RN.TextInput;
            var h = R.createElement;

            var tick = R.useState(0);
            R.useEffect(function () {
                return subscribeState(function () { tick[1](function (n) { return n + 1; }); });
            }, []);

            var filterState = R.useState("all");
            var filter = filterState[0], setFilter = filterState[1];
            var keyDraft = R.useState(null);
            var modelDraft = R.useState(null);
            var urlDraft = R.useState(null);
            var discoveredModels = R.useState([]);
            var adminsDraft = R.useState(null);
            var guildDraft = R.useState(null);
            var reportChDraft = R.useState(null);
            var showGroups = R.useState(false);
            var showAdminList = R.useState(false);
            var expanded = R.useState(null);
            var testState = R.useState("");
            var testStatus = testState[0], setTestStatus = testState[1];
            var fwdTestState = R.useState("");
            var fwdTestStatus = fwdTestState[0], setFwdTestStatus = fwdTestState[1];

            var card = { backgroundColor: "#2B2D31", borderRadius: 10, padding: 14, gap: 10 };
            var title = { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" };
            var small = { fontSize: 12, color: "#B5BAC1", textAlign: "right" };
            var inputStyle = { backgroundColor: "#111214", color: "#FFFFFF", padding: 10, borderRadius: 8, textAlign: "left" };
            function btn(bg, extra) {
                return Object.assign({ backgroundColor: bg, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8, alignItems: "center", justifyContent: "center" }, extra || {});
            }
            function button(label, bg, onPress, extra) {
                return h(TouchableOpacity, { onPress: onPress, style: btn(bg, extra) },
                    h(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 13, textAlign: "center" } }, label)
                );
            }
            function toggle(label, key, hint) {
                var on = !!cfg[key];
                return h(TouchableOpacity, {
                    key: key,
                    onPress: function () { var p = {}; p[key] = !on; saveCfg(p); },
                    style: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingVertical: 6 }
                },
                    h(View, { style: { flex: 1 } },
                        h(Text, { style: { color: "#FFFFFF", fontSize: 14, textAlign: "right" } }, label),
                        hint ? h(Text, { style: small }, hint) : null
                    ),
                    h(View, { style: { width: 46, height: 26, borderRadius: 13, backgroundColor: on ? "#23A55A" : "#4E5058", justifyContent: "center", padding: 3 } },
                        h(View, { style: { width: 20, height: 20, borderRadius: 10, backgroundColor: "#FFFFFF", alignSelf: on ? "flex-start" : "flex-end" } })
                    )
                );
            }
            function chip(label, active, onPress, key) {
                return h(TouchableOpacity, { key: key || label, onPress: onPress, style: btn(active ? "#5865F2" : "#1E1F22", { paddingVertical: 8, marginLeft: 6, marginBottom: 6 }) },
                    h(Text, { style: { color: "#FFFFFF", fontSize: 12, fontWeight: active ? "bold" : "normal", textAlign: "center" } }, label));
            }

            var pInfo = PROVIDERS[cfg.provider] || PROVIDERS.local;
            var currentKey = pInfo.keyProp ? (cfg[pInfo.keyProp] || "") : "";
            var currentModel = pInfo.modelProp ? (cfg[pInfo.modelProp] || "") : "";
            var currentUrl = pInfo.urlProp ? (cfg[pInfo.urlProp] || "") : "";
            var draftKey = keyDraft[0] !== null ? keyDraft[0] : "";
            var draftModel = modelDraft[0] !== null ? modelDraft[0] : currentModel;
            var draftUrl = urlDraft[0] !== null ? urlDraft[0] : currentUrl;
            var draftAdmins = adminsDraft[0] !== null ? adminsDraft[0] : (cfg.targetUserIds || "");
            var draftGuild = guildDraft[0] !== null ? guildDraft[0] : (cfg.targetGuildId || "");
            var draftReportCh = reportChDraft[0] !== null ? reportChDraft[0] : (cfg.reportChannelId || "");

            var savedAdmins = extractSnowflakes(cfg.targetUserIds);
            var savedGuildId = extractSingleIdOrWebhook(cfg.targetGuildId);
            if (isWebhookUrl(savedGuildId)) savedGuildId = "";
            var savedGuildName = savedGuildId ? getGuildName(savedGuildId) : "";
            var savedReportDest = extractSingleIdOrWebhook(cfg.reportChannelId);
            var savedReportInfo = (savedReportDest && !isWebhookUrl(savedReportDest)) ? getChannelInfo(savedReportDest) : null;
            var privateChannels = showGroups[0] ? listPrivateChannels(25) : [];

            var findings = cfg.findings || [];
            var counts = {};
            var unforwardedCount = 0;
            for (var i = 0; i < findings.length; i++) {
                counts[findings[i].cat] = (counts[findings[i].cat] || 0) + 1;
                if (!findings[i].forwarded) unforwardedCount++;
            }
            var shown = filter === "all" ? findings : findings.filter(function (f) { return f.cat === filter; });

            var curCh = getCurrentChannelId();
            var curInfo = curCh ? getChannelInfo(curCh) : null;

            var depthOptions = [
                { label: "سريع (25/إداري)", v: 25 },
                { label: "متوسط (75/إداري)", v: 75 },
                { label: "عميق (200/إداري)", v: 200 }
            ];
            var batchOptions = [
                { label: "15 رسالة", v: 15 },
                { label: "30 رسالة (موصى به)", v: 30 },
                { label: "50 رسالة", v: 50 }
            ];
            var thresholds = [
                { label: "حساس جداً (0.3)", v: 0.3 },
                { label: "متوازن (0.5)", v: 0.5 },
                { label: "الواضح فقط (0.8)", v: 0.8 }
            ];

            function switchProvider(pid) {
                saveCfg({ provider: pid });
                keyDraft[1](null);
                modelDraft[1](null);
                urlDraft[1](null);
                discoveredModels[1]([]);
                setTestStatus("");
            }

            var savedKeysList = pInfo.keyProp ? getProviderKeys(cfg.provider) : [];

            function addProviderSettings() {
                var patch = {};
                var addedCount = 0;
                if (pInfo.keyProp && keyDraft[0] !== null && String(keyDraft[0]).trim()) {
                    var incoming = parseKeyList(String(keyDraft[0]));
                    var existing = getProviderKeys(cfg.provider);
                    var seen = {};
                    var merged = [];
                    for (var i = 0; i < existing.length; i++) {
                        seen[existing[i]] = true;
                        merged.push(existing[i]);
                    }
                    for (var j = 0; j < incoming.length; j++) {
                        if (!seen[incoming[j]]) {
                            seen[incoming[j]] = true;
                            merged.push(incoming[j]);
                            addedCount++;
                        }
                    }
                    if (merged.length) patch[pInfo.keyProp] = merged.join("\n");
                }
                if (pInfo.modelProp && String(draftModel || "").trim()) {
                    patch[pInfo.modelProp] = String(draftModel).trim();
                }
                if (pInfo.urlProp && String(draftUrl || "").trim()) {
                    patch[pInfo.urlProp] = String(draftUrl).trim();
                }
                if (Object.keys(patch).length === 0) {
                    showToast("أدخل مفتاحاً أو إعدادات أولاً");
                    return;
                }
                saveCfg(patch);
                keyDraft[1](null);
                modelDraft[1](null);
                urlDraft[1](null);
                setTestStatus("");
                if (addedCount > 0) showToast("تمت إضافة " + addedCount + " مفتاح إلى " + pInfo.sourceName);
                else showToast("تم حفظ إعدادات " + pInfo.sourceName);
            }

            function removeProviderKey(keyToRemove) {
                if (!pInfo.keyProp) return;
                var next = getProviderKeys(cfg.provider).filter(function (k) { return k !== keyToRemove; });
                var patch = {};
                patch[pInfo.keyProp] = next.join("\n");
                delete keyHealth[makeKeyId(cfg.provider, keyToRemove)];
                saveCfg(patch);
                showToast("تم حذف المفتاح (" + maskKey(keyToRemove) + ")");
            }

            function checkLocalServerModels() {
                if (!pInfo.urlProp) return;
                var useUrl = String(draftUrl || currentUrl || "").trim();
                if (!useUrl) { setTestStatus("⚠️ أدخل رابط الخادم أولاً"); return; }
                var useKey = parseKeyList(String(draftKey || ""))[0] || savedKeysList[0] || "";
                setTestStatus("⏳ جارٍ فحص اتصال " + pInfo.sourceName + " على " + useUrl + "…");
                fetchServerModels(useUrl, useKey, pInfo.defaultBearer).then(function (ids) {
                    var patch = {};
                    if (useUrl !== currentUrl) patch[pInfo.urlProp] = useUrl;
                    if (Object.keys(patch).length) saveCfg(patch);
                    urlDraft[1](null);
                    discoveredModels[1](ids);
                    setTestStatus("✅ " + pInfo.sourceName + " متصل ويعمل! " + (ids.length ? ("النماذج المتاحة: " + ids.length) : "جاهز على النموذج auto"));
                }).catch(function (err) {
                    setTestStatus("❌ تعذّر الاتصال بـ " + useUrl + " — تأكد من تشغيل " + pInfo.sourceName + " (" + String((err && err.message) || err) + ")");
                });
            }

            function testSingleKey(keyToTest, indexLabel) {
                var pid = cfg.provider;
                var prevUrl = pInfo.urlProp ? cfg[pInfo.urlProp] : "";
                var useModel = parseModelList(String(draftModel || currentModel || ""))[0] || (pInfo.presets && pInfo.presets[0]) || "";
                var useUrl = String(draftUrl || prevUrl || "").trim();
                if (pInfo.modelProp && !useModel) {
                    setTestStatus("⚠️ أدخل اسم النموذج أولاً");
                    return Promise.resolve(false);
                }
                if (pInfo.urlProp && !useUrl) {
                    setTestStatus("⚠️ أدخل رابط الـ API أولاً");
                    return Promise.resolve(false);
                }
                if (pInfo.urlProp) cfg[pInfo.urlProp] = useUrl;

                var label = keyToTest ? ("مفتاح #" + (indexLabel || 1) + " (" + maskKey(keyToTest) + ")") : "بدون API";
                setTestStatus("⏳ جارٍ اختبار " + pInfo.sourceName + " — " + label + "…");
                var kid = makeKeyId(pid, keyToTest);

                return runProviderModerate(pid, ["السلام عليكم، هذه رسالة تجريبية عادية"], keyToTest, useModel).then(function () {
                    keyHealth[kid] = { cooldownUntil: 0, kind: "ok", reason: "", lastOk: Date.now() };
                    var patch = {};
                    if (pInfo.urlProp && useUrl !== prevUrl) patch[pInfo.urlProp] = useUrl;
                    if (pInfo.modelProp && draftModel && String(draftModel).trim() !== currentModel) patch[pInfo.modelProp] = String(draftModel).trim();
                    if (Object.keys(patch).length) saveCfg(patch);
                    setTestStatus("✅ نجح " + pInfo.sourceName + " (" + label + " • " + (useModel || "omni-moderation-latest") + ")");
                    emitState();
                    return true;
                }).catch(function (err) {
                    if (pInfo.urlProp) cfg[pInfo.urlProp] = prevUrl;
                    var cl = classifyApiError(err);
                    if (cl.rotate && cl.scope === "key") {
                        keyHealth[kid] = { cooldownUntil: Date.now() + cl.cooldownMs, kind: cl.kind, reason: String((err && err.message) || err), lastOk: 0 };
                    }
                    setTestStatus("❌ فشل " + label + ": " + String((err && err.message) || err));
                    emitState();
                    return false;
                });
            }

            function testAllProviderKeys() {
                var keys = getProviderKeys(cfg.provider);
                var pendingDraft = parseKeyList(String(draftKey || ""));
                if (pendingDraft.length > 0) {
                    addProviderSettings();
                    keys = getProviderKeys(cfg.provider);
                }
                if (keys.length === 0) {
                    if (pInfo.keyOptional) {
                        testSingleKey("", 1);
                    } else {
                        setTestStatus("⚠️ أضف مفتاحاً واحداً على الأقل أولاً");
                    }
                    return;
                }
                var okCount = 0;
                var idx = 0;
                function next() {
                    if (idx >= keys.length) {
                        setTestStatus("✅ اكتمل الاختبار: نجح " + okCount + " من " + keys.length + " مفتاح في " + pInfo.sourceName);
                        return;
                    }
                    var k = keys[idx];
                    idx++;
                    testSingleKey(k, idx).then(function (ok) {
                        if (ok) okCount++;
                        return sleep(400);
                    }).then(next);
                }
                next();
            }

            var totalAllKeys = 0;
            var readyProvidersCount = 0;
            for (var pi = 0; pi < PROVIDER_ORDER.length; pi++) {
                var pId = PROVIDER_ORDER[pi];
                if (pId === "local") continue;
                var pk = getProviderKeys(pId).length;
                totalAllKeys += pk;
                if (isProviderReady(pId, pId !== cfg.provider)) readyProvidersCount++;
            }

            var searchSum = (savedGuildId && savedAdmins.count > 0)
                ? getSearchSummary(savedGuildId, savedAdmins.list, cfg.searchDepth)
                : null;
            var guildProg = savedGuildId ? getProgressForGuild(savedGuildId) : null;
            var savedScannedCount = Array.isArray(cfg.scannedIds) ? cfg.scannedIds.length : 0;

            var mainSearchLabel = "🔎 حدّد الخادم ومعرّفات الإدارة للبدء";
            if (savedGuildId && savedAdmins.count > 0 && searchSum) {
                if (searchSum.allDone) {
                    mainSearchLabel = "🔎 فحص الرسائل الجديدة فقط للإدارة (" + savedAdmins.count + " إداري)";
                } else if (searchSum.hasProgress) {
                    mainSearchLabel = "▶️ متابعة البحث من حيث توقف (المتبقي " + searchSum.remainingCount + " / " + searchSum.total + " إداري)";
                } else {
                    mainSearchLabel = "🔎 بحث في الخادم المحدد عن رسائل الإدارة فقط (" + savedAdmins.count + " إداري)";
                }
            }

            return h(ScrollView, { style: { flex: 1, padding: 16, backgroundColor: "#1E1F22" } },
                h(View, { style: { gap: 14, paddingBottom: 60 } },
                    h(Text, { style: { fontSize: 19, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } }, "🛡️ حارس بحر v1.6 — OmniRoute وتبديل المفاتيح"),
                    h(Text, { style: small }, "يدعم OmniRoute المحلي بدون API (ملايين التوكن بالنموذج auto)، وتعدد مفاتيح API لكل مزوّد مع الانتقال التلقائي وحفظ نقطة التوقف."),

                    // 1) البحث في الخادم المحدد + الحالة + نقطة التوقف المحفوظة
                    h(View, { style: card },
                        toggle("تشغيل الحارس", "enabled"),
                        h(Text, { style: small },
                            "مفحوص محفوظ: " + savedScannedCount +
                            "  |  بالانتظار: " + state.queued +
                            "  |  مرصود: " + findings.length +
                            "  |  أُرسلت للمجموعة: " + state.forwarded +
                            (state.busy ? "  |  ⏳ AI يفحص…" : "")
                        ),
                        state.activeRoute ? h(Text, { style: { fontSize: 12, color: "#23A55A", textAlign: "right" } },
                            "⚡ المسار النشط: " + state.activeRoute + (state.keyRotations ? ("  •  تبديلات تلقائية: " + state.keyRotations) : "")
                        ) : null,
                        h(View, { style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 10, gap: 6 } },
                            h(Text, { style: { color: savedGuildId ? "#23A55A" : "#F0B232", fontSize: 13, fontWeight: "bold", textAlign: "right" } },
                                savedGuildId
                                    ? ("✅ الخادم المستهدف: " + (savedGuildName ? (savedGuildName + " (" + savedGuildId + ")") : savedGuildId))
                                    : "⚠️ لم يُحفظ معرّف الخادم بعد (احفظه أدناه)"),
                            h(Text, { style: { color: savedAdmins.count ? "#23A55A" : "#F0B232", fontSize: 13, textAlign: "right" } },
                                savedAdmins.count
                                    ? ("👥 معرّفات الإدارة المراقَبة: " + savedAdmins.count + " معرّف (كلها مفعّلة بالـ ID)")
                                    : "⚠️ لم تُضف معرّفات الإدارة بعد"),
                            searchSum && searchSum.hasProgress ? h(Text, { style: { color: "#60A5FA", fontSize: 12, fontWeight: "bold", textAlign: "right" } },
                                searchSum.allDone
                                    ? ("📌 التقدم المحفوظ: ✅ اكتمل فحص كل الإدارة (" + searchSum.doneCount + "/" + searchSum.total + ") لهذا العمق • المجلوب: " + searchSum.fetchedTotal)
                                    : ("📌 التقدم المحفوظ: اكتمل " + searchSum.doneCount + "/" + searchSum.total + " إداري • المتبقي: " + searchSum.remainingCount + " • المجلوب: " + searchSum.fetchedTotal + " (سيتابع من حيث توقف)")) : null,
                            h(Text, { style: small }, "عمق البحث لكل إداري في الخادم (عند زيادة العمق يكمّل تلقائياً دون إعادة القديم):"),
                            h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                                depthOptions.map(function (d) {
                                    return chip(d.label, cfg.searchDepth === d.v, function () { saveCfg({ searchDepth: d.v }); }, "dep_" + d.v);
                                })
                            ),
                            serverSearch.status ? h(Text, { style: { color: serverSearch.running ? "#23A55A" : "#DBDEE1", fontSize: 12, fontWeight: "bold", textAlign: "right" } }, serverSearch.status) : null,
                            serverSearch.lastError ? h(Text, { style: { color: "#F23F43", fontSize: 12, textAlign: "right" } }, "خطأ البحث: " + serverSearch.lastError) : null,
                            serverSearch.running
                                ? button("⏹️ إيقاف وحفظ نقطة التوقف", "#DA373C", stopServerAdminSearch)
                                : button(
                                    mainSearchLabel,
                                    (savedGuildId && savedAdmins.count > 0) ? "#248046" : "#4E5058",
                                    function () { startServerAdminSearch(false); }
                                ),
                            savedGuildId ? button("⚡ فحص القنوات المحمّلة حالياً في الخادم (فوري)", "#5865F2", function () {
                                var r = scanServerCachedChannels(savedGuildId);
                                showToast(r.scanned ? ("جارٍ فحص " + r.scanned + " رسالة جديدة للإدارة من " + r.channels + " قناة") : "لا توجد رسائل جديدة غير مفحوصة في القنوات المحمّلة حالياً");
                            }) : null
                        ),
                        state.lastError ? h(Text, { style: { fontSize: 12, color: "#F23F43", textAlign: "right" } }, "آخر خطأ AI: " + state.lastError) : null,
                        state.lastForwardError ? h(Text, { style: { fontSize: 12, color: "#F23F43", textAlign: "right" } }, "آخر خطأ إرسال للمجموعة: " + state.lastForwardError) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            curInfo ? button("🔍 فحص الروم المفتوح", "#4E5058", function () {
                                var n = scanChannel(curCh, false);
                                showToast(n ? ("جارٍ فحص " + n + " رسالة جديدة…") : "كل الرسائل في هذا الروم مفحوصة بالفعل أو ليست للإدارة");
                            }, { flex: 1 }) : null,
                            button("🔄 تصفير التقدم وبدء من الصفر", "#3F4147", function () {
                                resetAllProgress();
                                showToast("تم تصفير نقطة التوقف وذاكرة المفحوص");
                            }, { flex: 1 })
                        )
                    ),

                    // 2) نطاق الرصد (مخالفات حظر الخادم فقط)
                    h(View, { style: card },
                        h(Text, { style: title }, "🔥 نطاق الرصد (نوع المخالفات)"),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            chip("🔥 مخالفات حظر الخادم فقط (الإرهاب والانتهاكات الخطيرة)", cfg.auditMode === "server_ban", function () { saveCfg({ auditMode: "server_ban" }); }, "m_ban"),
                            chip("📋 جميع المخالفات (شامل السب والسبام)", cfg.auditMode === "all", function () { saveCfg({ auditMode: "all" }); }, "m_all")
                        ),
                        h(Text, { style: small }, cfg.auditMode === "server_ban"
                            ? "يركّز حصراً على الانتهاكات الموجبة لحظر الخادم لدى Trust & Safety: دعم/تمجيد/تجنيد الإرهاب، استغلال الأطفال، التهديدات بالقتل والعنف الدموي، التشجيع على الانتحار، بيع السلاح والمخدرات والاختراق، وخطاب الكراهية العنيف — ويتجاهل السب العادي والمزاح."
                            : "يفحص كل المخالفات بما فيها السب والمضايقات والسبام وروابط الاحتيال.")
                    ),

                    // 3) معرّفات الإدارة المستهدفة + معرّف الخادم
                    h(View, { style: card },
                        h(Text, { style: title }, "👤 معرّفات الإدارة والخادم المستهدف"),
                        toggle("فحص رسائل الإدارة المحددة فقط", "filterUsersOnly", "لن يُفحص أي عضو خارج قائمة المعرّفات أدناه"),
                        cfg.filterUsersOnly && savedAdmins.count === 0
                            ? h(Text, { style: { fontSize: 12, color: "#F0B232", textAlign: "right" } }, "⚠️ وضع الإدارة مفعّل لكن لم تضف أي معرّف (ID) بعد.")
                            : null,
                        h(Text, { style: small }, "معرّفات (IDs) الإدارة — كل معرّف في سطر أو بمسافة أو فاصلة:"),
                        TextInput ? h(TextInput, {
                            value: draftAdmins,
                            onChangeText: function (t) { adminsDraft[1](t); },
                            placeholder: "مثال:\n123456789012345678\n987654321098765432",
                            placeholderTextColor: "#72767D",
                            multiline: true,
                            autoCapitalize: "none",
                            autoCorrect: false,
                            style: Object.assign({}, inputStyle, { minHeight: 74, textAlignVertical: "top" })
                        }) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            button("حفظ معرّفات الإدارة", "#248046", function () {
                                var parsed = extractSnowflakes(draftAdmins);
                                var normalized = parsed.list.join("\n");
                                saveCfg({ targetUserIds: normalized, filterUsersOnly: parsed.count > 0 });
                                adminsDraft[1](null);
                                showToast(parsed.count ? ("تم حفظ وتفعيل " + parsed.count + " معرّف للإدارة") : "تم مسح القائمة");
                            }, { flex: 1 }),
                            savedAdmins.count ? button("مسح", "#DA373C", function () {
                                saveCfg({ targetUserIds: "", filterUsersOnly: false });
                                adminsDraft[1](null);
                            }) : null
                        ),
                        savedAdmins.count ? h(View, { style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 10, gap: 6 } },
                            h(TouchableOpacity, { onPress: function () { showAdminList[1](!showAdminList[0]); } },
                                h(Text, { style: { color: "#23A55A", fontSize: 13, fontWeight: "bold", textAlign: "right" } },
                                    "✅ جميع المعرّفات (" + savedAdmins.count + ") مفعّلة ومراقَبة بالـ ID  " + (showAdminList[0] ? "▲" : "▼")),
                                h(Text, { style: small }, "ملاحظة: عدم ظهور اسم الحساب بجانب بعض المعرّفات يعني فقط أنه غير محمّل في الذاكرة مؤقتاً، لكن الفحص والبحث يعملان لكل المعرّفات بالـ ID بدون استثناء.")
                            ),
                            showAdminList[0] ? savedAdmins.list.map(function (uid) {
                                var lbl = resolveUserLabel(uid, savedGuildId);
                                var ap = guildProg && guildProg.admins ? guildProg.admins[uid] : null;
                                var maxM = Math.max(25, Number(cfg.searchDepth) || 75);
                                var st = "⬜ بالانتظار";
                                if (ap) {
                                    if (ap.reachedEnd || (Number(ap.nextOffset) || 0) >= maxM) st = "✅ اكتمل (" + (ap.fetched || 0) + ")";
                                    else if ((Number(ap.nextOffset) || 0) > 0) st = "⏳ وصل " + ap.nextOffset;
                                }
                                return h(Text, { key: uid, style: { color: "#DBDEE1", fontSize: 12, textAlign: "right" } },
                                    st + " • " + uid + " — " + (lbl || "مفعّل بالـ ID"));
                            }) : null
                        ) : null,

                        h(Text, { style: { color: "#FFFFFF", fontSize: 14, fontWeight: "bold", textAlign: "right", marginTop: 4 } }, "معرّف الخادم المستهدف (Server ID):"),
                        h(Text, { style: { fontSize: 12, color: savedGuildId ? "#23A55A" : "#F0B232", textAlign: "right" } },
                            savedGuildId ? ("✅ محفوظ: " + (savedGuildName ? savedGuildName + " — " : "") + savedGuildId) : "غير محدد (يفحص كل الخوادم)"),
                        TextInput ? h(TextInput, {
                            value: draftGuild,
                            onChangeText: function (t) { guildDraft[1](t); },
                            placeholder: "أدخل Server ID هنا...",
                            placeholderTextColor: "#72767D",
                            keyboardType: "numeric",
                            style: inputStyle
                        }) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            button("حفظ الخادم", "#248046", function () {
                                var gid = extractSingleIdOrWebhook(draftGuild);
                                var clean = isWebhookUrl(gid) ? "" : gid;
                                saveCfg({ targetGuildId: clean });
                                guildDraft[1](null);
                                showToast(clean ? ("تم حفظ الخادم: " + (getGuildName(clean) || clean)) : "تم إلغاء تحديد الخادم");
                            }, { flex: 1 }),
                            curInfo && curInfo.guildId ? button("استخدام الخادم الحالي", "#5865F2", function () {
                                saveCfg({ targetGuildId: curInfo.guildId });
                                guildDraft[1](null);
                                showToast("تم حفظ الخادم: " + (curInfo.guildName || curInfo.guildId));
                            }, { flex: 1 }) : null,
                            savedGuildId ? button("مسح", "#DA373C", function () { saveCfg({ targetGuildId: "" }); guildDraft[1](null); }) : null
                        )
                    ),

                    // 4) مجموعة/قناة استقبال تقارير المخالفات
                    h(View, { style: card },
                        h(Text, { style: title }, "📤 مجموعة / قناة تقارير المخالفات"),
                        h(Text, { style: small }, "يرسل رابط الرسالة الممنوعة وسبب المنع ومسار الإبلاغ المناسب تلقائياً إلى هذه المجموعة (ولا يفحص رسائلها منعاً للتكرار)."),
                        toggle("إرسال تلقائي للمجموعة عند رصد مخالفة", "autoForward"),
                        h(Text, { style: { fontSize: 13, color: savedReportDest ? "#23A55A" : "#F0B232", textAlign: "right" } },
                            savedReportDest
                                ? (isWebhookUrl(savedReportDest)
                                    ? "✅ الوجهة: رابط Webhook محفوظ"
                                    : "✅ الوجهة: [" + (savedReportInfo ? savedReportInfo.typeLabel : "قناة") + "] " + (savedReportInfo ? ((savedReportInfo.guildName ? savedReportInfo.guildName + " / " : "") + savedReportInfo.channelName) : savedReportDest))
                                : "⚠️ لم تُحدد مجموعة/قناة للتقارير بعد"),
                        TextInput ? h(TextInput, {
                            value: draftReportCh,
                            onChangeText: function (t) { reportChDraft[1](t); },
                            placeholder: "أدخل معرّف المجموعة (Group/Channel ID) أو رابط Webhook...",
                            placeholderTextColor: "#72767D",
                            autoCapitalize: "none",
                            autoCorrect: false,
                            style: inputStyle
                        }) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            button("حفظ المجموعة", "#248046", function () {
                                var dest = extractSingleIdOrWebhook(draftReportCh);
                                saveCfg({ reportChannelId: dest });
                                reportChDraft[1](null);
                                setFwdTestStatus("");
                                showToast(dest ? "تم حفظ وجهة التقارير" : "تم مسح وجهة التقارير");
                            }, { flex: 1 }),
                            button("اختبار الإرسال", "#5865F2", function () {
                                var dest = extractSingleIdOrWebhook(draftReportCh || cfg.reportChannelId);
                                if (!dest) { setFwdTestStatus("⚠️ أدخل معرّف المجموعة أولاً"); return; }
                                setFwdTestStatus("⏳ جارٍ إرسال رسالة تجريبية…");
                                postToDestination(dest, "🛡️ **حارس بحر:** تم ربط هذه المجموعة بنجاح لاستقبال روابط الرسائل المخالفة وأسبابها وطريقة الإبلاغ.").then(function () {
                                    if (dest !== cfg.reportChannelId) saveCfg({ reportChannelId: dest });
                                    reportChDraft[1](null);
                                    setFwdTestStatus("✅ تم الإرسال للمجموعة بنجاح!");
                                }).catch(function (err) {
                                    setFwdTestStatus("❌ فشل الإرسال: " + String((err && (err.message || (err.body && err.body.message))) || err));
                                });
                            }, { flex: 1 }),
                            savedReportDest ? button("مسح", "#DA373C", function () { saveCfg({ reportChannelId: "" }); reportChDraft[1](null); setFwdTestStatus(""); }) : null
                        ),
                        fwdTestStatus ? h(Text, { style: { fontSize: 12, color: fwdTestStatus.indexOf("✅") === 0 ? "#23A55A" : "#F0B232", textAlign: "right" } }, fwdTestStatus) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            curInfo ? button("استخدام المحادثة المفتوحة الآن", "#4E5058", function () {
                                saveCfg({ reportChannelId: curCh });
                                reportChDraft[1](null);
                                showToast("تم اختيار: " + curInfo.channelName);
                            }, { flex: 1 }) : null,
                            button(showGroups[0] ? "إخفاء القروبات ▲" : "اختر من قروباتي ▼", "#4E5058", function () {
                                showGroups[1](!showGroups[0]);
                            }, { flex: 1 })
                        ),
                        showGroups[0] ? h(View, { style: { gap: 6 } },
                            privateChannels.length === 0
                                ? h(Text, { style: small }, "لم يتم العثور على قروبات أو محادثات خاصة محمّلة حالياً.")
                                : privateChannels.map(function (ch) {
                                    return h(TouchableOpacity, {
                                        key: ch.channelId,
                                        onPress: function () {
                                            saveCfg({ reportChannelId: ch.channelId });
                                            reportChDraft[1](null);
                                            showGroups[1](false);
                                            showToast("تم اختيار: " + ch.channelName);
                                        },
                                        style: btn(ch.channelId === savedReportDest ? "#248046" : "#1E1F22", { alignItems: "flex-end" })
                                    }, h(Text, { style: { color: "#FFFFFF", fontSize: 12 } }, "[" + ch.typeLabel + "] " + ch.channelName + " (" + ch.channelId + ")"));
                                })
                        ) : null
                    ),

                    // 5) المزوّد والنماذج وتعدد المفاتيح
                    h(View, { style: card },
                        h(Text, { style: title }, "🤖 محرك الفحص ومفاتيح الـ API (متعدد المفاتيح)"),
                        h(Text, { style: small },
                            "المجموع المحفوظ: " + totalAllKeys + " مفتاح عبر " + readyProvidersCount + " مزوّد جاهز" +
                            (state.activeRoute ? ("  •  النشط: " + state.activeRoute) : "")
                        ),
                        toggle(
                            "الانتقال التلقائي لمزوّد آخر عند انتهاء الحصة",
                            "autoFailoverProviders",
                            "إذا انتهت حصة كل مفاتيح المزوّد الحالي ينتقل تلقائياً لأي مزوّد آخر فيه مفاتيح محفوظة"
                        ),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            PROVIDER_ORDER.map(function (pid) {
                                var pCnt = pid === "local" ? 0 : getProviderKeys(pid).length;
                                var lbl = PROVIDERS[pid].label + (pCnt > 0 ? (" (" + pCnt + " 🔑)") : "");
                                return chip(lbl, cfg.provider === pid, function () { switchProvider(pid); }, "prov_" + pid);
                            })
                        ),
                        cfg.provider === "local" ? h(Text, { style: small }, "الكشف المحلي يرصد فوراً أنماط الإرهاب والتجنيد والانتهاكات الخطيرة. لفحص كل اللغات بدقة عالية اختر OmniRoute المحلي (بدون API) أو Groq أو OpenRouter أو جيميني أو Grok أو OpenAI.") : null,

                        cfg.provider !== "local" ? h(View, { style: { gap: 8 } },
                            h(Text, { style: small }, pInfo.keyHint || ""),

                            cfg.provider === "omniroute" ? toggle(
                                "تضمين OmniRoute في التبديل التلقائي مع المزوّدات الأخرى",
                                "omnirouteInFailover",
                                "عند التفعيل: إن كنت تستخدم مزوّداً آخر وانتهت حصته ينتقل تلقائياً لـ OmniRoute (والعكس)"
                            ) : null,

                            pInfo.urlProp ? h(View, { style: { gap: 6 } },
                                h(Text, { style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } },
                                    cfg.provider === "omniroute" ? "رابط خادم OmniRoute المحلي:" : "رابط الـ API (Base URL أو chat/completions):"),
                                pInfo.urlPresets ? h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                                    pInfo.urlPresets.map(function (uVal) {
                                        return chip("رابط: " + uVal, String(draftUrl).trim() === uVal, function () {
                                            var p = {}; p[pInfo.urlProp] = uVal; saveCfg(p); urlDraft[1](null); setTestStatus("");
                                        }, "url_" + uVal);
                                    })
                                ) : null,
                                TextInput ? h(TextInput, {
                                    value: draftUrl,
                                    onChangeText: function (t) { urlDraft[1](t); },
                                    placeholder: cfg.provider === "omniroute" ? "http://127.0.0.1:20128/v1" : "https://api.deepseek.com/v1/chat/completions",
                                    placeholderTextColor: "#72767D",
                                    autoCapitalize: "none",
                                    autoCorrect: false,
                                    style: inputStyle
                                }) : null,
                                button("🔍 فحص اتصال " + pInfo.sourceName + " وجلب النماذج", "#5865F2", checkLocalServerModels)
                            ) : null,

                            pInfo.modelProp ? (function () {
                                var combinedPresets = (pInfo.presets || []).slice();
                                var disc = discoveredModels[0] || [];
                                for (var di = 0; di < disc.length; di++) {
                                    if (combinedPresets.indexOf(disc[di]) === -1) combinedPresets.push(disc[di]);
                                }
                                return h(View, { style: { gap: 6 } },
                                    h(Text, { style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } }, "اسم النموذج (اختر جاهزاً أو اكتب نموذجاً أو عدة نماذج مفصولة بفاصلة للتبديل التلقائي):"),
                                    combinedPresets.length ? h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                                        combinedPresets.map(function (mName) {
                                            var activeModels = parseModelList(String(draftModel || ""));
                                            var isSel = activeModels.indexOf(mName) !== -1;
                                            return chip("نموذج: " + mName, isSel, function () {
                                                var curList = parseModelList(String(draftModel || ""));
                                                var nextList;
                                                if (curList.indexOf(mName) !== -1 && curList.length > 1) {
                                                    nextList = curList.filter(function (x) { return x !== mName; });
                                                } else if (curList.indexOf(mName) === -1) {
                                                    nextList = [mName].concat(curList);
                                                } else {
                                                    nextList = [mName];
                                                }
                                                var p = {}; p[pInfo.modelProp] = nextList.join(", "); saveCfg(p); modelDraft[1](null); setTestStatus("");
                                            }, "mod_" + mName);
                                        })
                                    ) : null,
                                    TextInput ? h(TextInput, {
                                        value: draftModel,
                                        onChangeText: function (t) { modelDraft[1](t); },
                                        placeholder: cfg.provider === "omniroute" ? "auto" : "مثال: openrouter/free, meta-llama/llama-3.3-70b-instruct:free",
                                        placeholderTextColor: "#72767D",
                                        autoCapitalize: "none",
                                        autoCorrect: false,
                                        style: inputStyle
                                    }) : null
                                );
                            })() : null,

                            // قائمة المفاتيح المحفوظة لهذا المزوّد
                            h(Text, { style: { fontSize: 13, fontWeight: "bold", color: (savedKeysList.length || pInfo.keyOptional) ? "#23A55A" : "#F0B232", textAlign: "right" } },
                                savedKeysList.length
                                    ? ("🔑 مفاتيح " + pInfo.sourceName + " المحفوظة (" + savedKeysList.length + ") — يتبدل بينها تلقائياً:")
                                    : (pInfo.keyOptional
                                        ? (cfg.provider === "omniroute" ? "✅ OmniRoute يعمل بدون مفتاح API (النموذج: auto)" : "ℹ️ المفتاح اختياري لهذا المزوّد")
                                        : "⚠️ لم يُحفظ أي مفتاح لـ " + pInfo.sourceName + " بعد")),

                            savedKeysList.length ? h(View, { style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 8, gap: 6 } },
                                savedKeysList.map(function (kVal, kIdx) {
                                    var badge = getKeyBadgeInfo(cfg.provider, kVal);
                                    return h(View, { key: kVal, style: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", gap: 6, paddingVertical: 4, borderBottomWidth: kIdx < savedKeysList.length - 1 ? 1 : 0, borderBottomColor: "#2B2D31" } },
                                        h(View, { style: { flex: 1 } },
                                            h(Text, { style: { color: "#FFFFFF", fontSize: 12, fontWeight: "bold", textAlign: "right" } },
                                                "مفتاح #" + (kIdx + 1) + "  (" + maskKey(kVal) + ")"),
                                            h(Text, { style: { color: badge.color, fontSize: 11, textAlign: "right" } }, badge.text)
                                        ),
                                        h(View, { style: { flexDirection: "row-reverse", gap: 6 } },
                                            button("اختبار", "#5865F2", function () { testSingleKey(kVal, kIdx + 1); }, { paddingVertical: 6, paddingHorizontal: 10 }),
                                            button("✖", "#DA373C", function () { removeProviderKey(kVal); }, { paddingVertical: 6, paddingHorizontal: 10 })
                                        )
                                    );
                                })
                            ) : null,

                            h(Text, { style: small },
                                cfg.provider === "omniroute"
                                    ? "مفتاح OmniRoute (اختياري تماماً — اتركه فارغاً إلا إذا فعّلت الحماية بمفتاح داخل لوحة OmniRoute):"
                                    : "إضافة مفتاح جديد أو عدة مفاتيح دفعة واحدة (كل مفتاح في سطر — لن يحذف المفاتيح القديمة):"),
                            TextInput ? h(TextInput, {
                                value: draftKey,
                                onChangeText: function (t) { keyDraft[1](t); },
                                placeholder: (pInfo.keyPlaceholder || "API Key...") + (cfg.provider === "omniroute" ? "" : "\n(يمكنك لصق عدة مفاتيح، كل مفتاح في سطر)"),
                                placeholderTextColor: "#72767D",
                                multiline: true,
                                autoCapitalize: "none",
                                autoCorrect: false,
                                style: Object.assign({}, inputStyle, { minHeight: cfg.provider === "omniroute" ? 44 : 62, textAlignVertical: "top" })
                            }) : null,
                            h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                                button(cfg.provider === "omniroute" ? "حفظ الإعدادات" : "+ إضافة / حفظ", "#248046", addProviderSettings, { flex: 1 }),
                                button(savedKeysList.length > 1 ? "اختبار الكل" : "اختبار الاتصال", "#5865F2", testAllProviderKeys, { flex: 1 })
                            ),
                            h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                                button("🔄 تصفير انتظار الحصة", "#4E5058", function () {
                                    resetAllKeyCooldowns();
                                    showToast("تم تصفير مؤقتات استراحة المفاتيح");
                                }, { flex: 1 }),
                                savedKeysList.length ? button("حذف كل مفاتيح " + pInfo.sourceName, "#DA373C", function () {
                                    var p = {}; p[pInfo.keyProp] = ""; saveCfg(p); setTestStatus("");
                                    showToast("تم حذف كل مفاتيح " + pInfo.sourceName);
                                }, { flex: 1 }) : null
                            ),
                            testStatus ? h(Text, { style: { fontSize: 12, color: testStatus.indexOf("✅") === 0 ? "#23A55A" : "#F0B232", textAlign: "right" } }, testStatus) : null,
                            toggle("تشغيل الكشف المحلي أيضاً", "localAlways", "يرصد كلمات الإرهاب والانتهاكات الخطيرة فوراً حتى قبل رد الذكاء الاصطناعي")
                        ) : null,

                        h(Text, { style: title }, "حجم الدفعة (عدد الرسائل في الطلب الواحد)"),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            batchOptions.map(function (b) {
                                return chip(b.label, cfg.batchSize === b.v, function () { saveCfg({ batchSize: b.v }); }, "bs_" + b.v);
                            })
                        ),

                        h(Text, { style: title }, "الحساسية"),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            thresholds.map(function (t) {
                                return chip(t.label, Math.abs(cfg.threshold - t.v) < 0.01, function () { saveCfg({ threshold: t.v }); }, "th_" + t.v);
                            })
                        )
                    ),

                    // 6) خيارات
                    h(View, { style: card },
                        h(Text, { style: title }, "الخيارات"),
                        toggle("متابعة البحث تلقائياً بعد إعادة تشغيل التطبيق", "autoResumeSearch", "إن أغلقت التطبيق قبل اكتمال فحص الإدارة يكمل تلقائياً من نفس النقطة بعد 5 ثوانٍ"),
                        toggle("فحص الرسائل الجديدة", "scanNew"),
                        toggle("فحص الرسائل عند فتح روم أو البحث", "scanLoaded"),
                        toggle("تجاهل رسائلي", "skipOwn"),
                        toggle("تنبيه منبثق عند الرصد", "toast"),
                        toggle("تنبيه داخل الروم (يظهر لك وحدك)", "inChatNotice", "رسالة محلية تحت الرسالة المشبوهة فيها النوع والسبب وطريقة الإبلاغ")
                    ),

                    // 7) النتائج
                    h(View, { style: card },
                        h(View, { style: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" } },
                            h(Text, { style: title }, "🚩 الرسائل المرصودة (" + findings.length + ")"),
                            findings.length ? h(TouchableOpacity, { onPress: function () { saveCfg({ findings: [] }); } },
                                h(Text, { style: { color: "#F23F43", fontSize: 13 } }, "مسح الكل")) : null
                        ),
                        savedReportDest && unforwardedCount > 0 ? button("📤 إرسال كل غير المرسل إلى المجموعة (" + unforwardedCount + ")", "#248046", function () {
                            var queuedN = 0;
                            for (var k = 0; k < findings.length; k++) {
                                if (!findings[k].forwarded && enqueueForward(findings[k], false)) queuedN++;
                            }
                            showToast(queuedN ? ("جارٍ إرسال " + queuedN + " بلاغ للمجموعة…") : "الكل مرسل بالفعل");
                        }) : null,
                        findings.length ? h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            [chip("الكل (" + findings.length + ")", filter === "all", function () { setFilter("all"); }, "all")].concat(
                                Object.keys(counts).map(function (k) {
                                    return chip((CATS[k] ? CATS[k].label : k) + " (" + counts[k] + ")", filter === k, function () { setFilter(k); }, k);
                                })
                            )
                        ) : h(Text, { style: small }, "لا توجد رسائل مرصودة حتى الآن."),

                        shown.slice(0, 80).map(function (f) {
                            var cat = CATS[f.cat] || { label: f.cat, color: "#999", steps: [] };
                            var isOpen = expanded[0] === f.messageId;
                            var where = (f.guildName ? f.guildName + " / " : (f.typeLabel === "خاص" ? "خاص / " : "")) + (f.channelName || f.channelId);
                            var when = "";
                            try { when = new Date(f.ts).toLocaleString(); } catch (e) { when = f.ts; }
                            return h(View, { key: f.messageId, style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 10, gap: 6, borderRightWidth: 4, borderRightColor: cat.color } },
                                h(TouchableOpacity, { onPress: function () { expanded[1](isOpen ? null : f.messageId); } },
                                    h(Text, { style: { color: cat.color, fontWeight: "bold", fontSize: 14, textAlign: "right" } }, cat.label + "  (" + Math.round((f.score || 0) * 100) + "%)" + (f.forwarded ? "  ✅ أُرسل" : "")),
                                    h(Text, { style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } }, "📍 " + where),
                                    h(Text, { style: small }, "👤 " + f.authorName + (f.authorUsername ? " (@" + f.authorUsername + ")" : "") + (f.authorBot ? " [بوت]" : "") + "  •  🕒 " + when),
                                    h(Text, { style: { color: "#E5E7EB", fontSize: 12, textAlign: "right" } }, "📌 سبب المنع: " + (f.reason || cat.label)),
                                    h(Text, { style: { color: "#949BA4", fontSize: 12, textAlign: "right", fontStyle: "italic" } }, "«" + f.snippet + "»" + (f.hasAttach ? "  📎 يحتوي مرفقاً (لم يُحلَّل)" : "")),
                                    h(Text, { style: { color: "#F0B232", fontSize: 12, textAlign: "right", marginTop: 2 } }, "⚖️ الإبلاغ: " + cat.steps.join(" ← ") + (isOpen ? "  ▲" : "  ▼"))
                                ),
                                isOpen ? h(View, { style: { gap: 6 } },
                                    h(Text, { style: { color: "#FFFFFF", fontSize: 13, fontWeight: "bold", textAlign: "right" } }, "خطوات الإبلاغ:"),
                                    cat.steps.map(function (s, idx) {
                                        return h(Text, { key: idx, style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } }, (idx + 1) + ") " + s);
                                    }),
                                    cat.extra ? h(Text, { style: { color: "#F0B232", fontSize: 12, textAlign: "right" } }, cat.extra) : null,
                                    f.guildId ? h(Text, { style: small }, "إذا كان الخادم ينشر هذا المحتوى: اضغط مطولاً على أيقونة الخادم ← إبلاغ عن الخادم، أو أرسل بلاغاً عبر dis.gd/request مع روابط الرسائل.") : null,
                                    h(Text, { style: { color: "#72767D", fontSize: 11, textAlign: "right" } }, "المصدر: " + f.source),
                                    h(Text, { style: { color: "#72767D", fontSize: 11, textAlign: "left" } }, "Server: " + (f.guildId || "DM") + "  Channel: " + f.channelId + "  Msg: " + f.messageId + "  User: " + f.authorId)
                                ) : null,
                                h(View, { style: { flexDirection: "row-reverse", gap: 6, flexWrap: "wrap" } },
                                    button("↪️ انتقال", "#5865F2", function () {
                                        if (!jumpToMessage(f)) showToast("تعذّر الانتقال — انسخ الرابط وافتحه");
                                    }),
                                    savedReportDest ? button(f.forwarded ? "📤 إعادة إرسال" : "📤 إرسال للمجموعة", "#248046", function () {
                                        enqueueForward(f, true);
                                        showToast("جارٍ الإرسال للمجموعة…");
                                    }) : null,
                                    button("📋 نسخ الرابط", "#4E5058", function () {
                                        showToast(copyText(messageLink(f)) ? "تم نسخ رابط الرسالة" : messageLink(f));
                                    }),
                                    button("📋 المعرّفات", "#4E5058", function () {
                                        var t = "Server ID: " + (f.guildId || "DM") + "\nChannel ID: " + f.channelId + "\nMessage ID: " + f.messageId + "\nUser ID: " + f.authorId + "\nLink: " + messageLink(f) + "\nType: " + cat.label + "\nReason: " + (f.reason || cat.label);
                                        showToast(copyText(t) ? "تم نسخ بيانات البلاغ" : "تعذّر النسخ");
                                    }),
                                    button("✖ تجاهل", "#3F4147", function () {
                                        saveCfg({ findings: (cfg.findings || []).filter(function (x) { return x.messageId !== f.messageId; }) });
                                    })
                                )
                            );
                        })
                    ),

                    // 8) روابط إبلاغ خارجية
                    h(View, { style: card },
                        h(Text, { style: title }, "جهات الإبلاغ"),
                        button("نموذج ثقة وأمان ديسكورد (dis.gd/request)", "#4E5058", function () { openExternal("https://dis.gd/request"); }),
                        button("NCMEC — الإبلاغ عن استغلال الأطفال", "#A12D2F", function () { openExternal("https://report.cybertip.org/"); }),
                        h(Text, { style: small }, "⚠️ عند الاشتباه باستغلال الأطفال: لا تحفظ ولا تصوّر ولا تعيد نشر أي شيء، فقط انسخ المعرّفات والروابط وبلّغ.")
                    )
                )
            );
        }
    });

    return exports;
})({});
