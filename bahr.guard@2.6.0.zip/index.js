(function (exports) {
    "use strict";

    /*
     * حارس بحر (bahr.guard) v2.5.3
     * ----------------------------
     * - نظام الطبقتين (Tiered Pipeline): الفرز الأساسي بالمزوّد المختار، والتأكيد المزدوج
     *   عبر أقوى نموذج متاح ومستقر مع Fallback تلقائي عند الفشل.
     * - النطاق الافتراضي الأضيق: لا يبدأ أي فحص إلا بعد تحديد خادم مستهدف ونطاق محدد
     *   (الإدارة المحددة افتراضياً أو كل أعضاء الخادم باختيار صريح من المستخدم).
     * - المراجعة البشرية أولاً: autoForward معطّل افتراضياً، ولا حظر/إبلاغ تلقائي لديسكورد.
     * - الخصوصية: لا تُسجَّل مفاتيح API أو نصوص الرسائل في السجلات التشخيصية أو الأخطاء.
     */

    // ===================== الإعدادات =====================
    var DEFAULTS = {
        enabled: true,
        auditMode: "server_ban",  // "server_ban" (مخالفات حظر الخادم فقط) | "all" (جميع المخالفات)
        provider: "omniroute",    // "omniroute" فقط
        autoFailoverProviders: false, // ممنوع الانتقال التلقائي لأي مزوّد آخر (ZERO Fallback)
        omnirouteOnly: true,        // حصر الفحص على OmniRoute فقط دون أي مزودات خارجية أخرى
        maxParallelBatches: 6,       // عدد الدفعات المتزامنة (6 دفعات بالتوازي لدعم 6 حسابات OmniRoute)
        tieredPipeline: false,       // فحص مباشر بنموذج Gemini 4 Hydrogen
        roundRobinProviders: false,  // معطّل
        strictModelLock: true,       // قفل صارم: نموذج Gemini 4 Hydrogen (Low) فقط
        batchSize: 100,              // 100 رسالة لكل استدعاء
        reasoningEffort: "low",      // ضبط مستوى التفكير على Low
        customInFailover: false,
        omnirouteUrl: "http://127.0.0.1:20128/v1",
        omnirouteKey: "",
        omnirouteModel: "gemini-4-hydrogen-low, agy/gemini-4-hydrogen-low",
        omnirouteInFailover: true,
        coarenaUrl: "https://coarena.ai/api/v1",
        coarenaKey: "",
        coarenaModel: "claude-sonnet-4-6, gemini-3-8-flash, gpt-6-luna, deepseek-v4-1-flash-1017, gpt-4o, gemini-2.5-flash",
        yepapiKey: "",
        yepapiModel: "nvidia/nemotron-3-super-120b-a12b:free, google/gemini-3.8-flash, qwen/qwen3.7-flash, google/gemini-2.5-flash-lite, google/gemini-2.5-flash",
        openaiKey: "",
        geminiKey: "",
        geminiModel: "gemini-3.8-flash, gemini-2.5-pro, gemma-4-31b-it, gemma-4-26b-a4b-it, gemini-2.5-flash-lite",
        groqKey: "",
        groqModel: "openai/gpt-oss-120b, qwen/qwen3.8-27b, meta-llama/llama-4-scout-17b-16e-instruct, openai/gpt-oss-20b, llama-3.3-70b-versatile",
        grokKey: "",
        grokModel: "grok-3, grok-2-vision-1212",
        openrouterKey: "",
        openrouterModel: "openai/gpt-4o, anthropic/claude-3.5-sonnet, google/gemini-2.5-pro, google/gemini-2.5-flash, openrouter/free",
        customUrl: "https://api.deepseek.com/v1/chat/completions",
        customKey: "",
        customModel: "deepseek-chat",
        scanImages: true,         // فحص الصور عبر 4 نماذج رؤية بالتوازي (10 صور/نموذج = 40 صورة/جولة)
        visionModel: "gemini-web/gemini-3.1-pro, gemini-web/gemini-3.7-flash, auto/best-vision, auto/pro-vision, auto/vision, antigravity/gemini-3-flash, agy/gemini-3.8-flash-high, agy/gemini-3.8-flash-medium, agy/gemini-3.1-flash-lite, gemini-web/gemini-3.1-flash-lite, gpt-4o-mini, gpt-4o",
        imageBatchSize: 10,       // 10 صور لكل نموذج فحص صور
        imageParallelBatches: 4,  // 4 نماذج رؤية تعمل بالتوازي (4 × 10 = 40 صورة)
        batchSize: 100,           // عدد الرسائل لكل استدعاء (100 رسالة دفعة واحدة)
        smartPreFilter: true,     // فرز ذكي مسبق لتخطي الإيموجي والتحيات القصيرة البديهية قبل إرسالها للذكاء الاصطناعي
        strictQuoteVerify: true,  // إلزام النموذج باقتباس العبارة المخالفة حرفياً (quote) والتحقق من وجودها وتصحيح رقم الرسالة
        doubleCheckBorderline: true, // تأكيد مزدوج عبر نموذج ثانٍ قوي ومستقل
        parallelBatches: true,    // تشغيل عدة نماذج بالتوازي لزيادة سرعة الفرز
        _v23BatchMigrated: false,
        searchDepth: 200,         // عدد الرسائل المجلوبة لكل إداري عند البحث في الخادم (25 / 75 / 200 / 1000 / 5000)
        autoResumeSearch: false,  // متابعة البحث تلقائياً بعد إعادة تشغيل التطبيق إن لم يكتمل
        threshold: 0.5,           // عتبة الحساسية (0..1)
        filterUsersOnly: true,    // أضيق نطاق افتراضي: الإدارة المحددة فقط
        targetUserIds: "",        // معرّفات الإدارة (IDs)
        targetGuildId: "",        // معرّف الخادم المستهدف (مطلوب لبدء أي فحص)
        targetChannelId: "",      // معرّف غرفة محددة فقط داخل الخادم (اختياري؛ فارغ = كل غرف الخادم)
        reportChannelId: "",      // معرّف المجموعة/القناة (أو رابط Webhook) لإرسال ملخصات المراجعة إليها
        autoForward: false,       // معطّل افتراضياً — لا يُرسل لأي وجهة خارجية إلا بتفعيل صريح من المستخدم
        scanNew: true,            // فحص الرسائل الجديدة والمعدّلة في الخادم المحدد
        scanLoaded: true,         // فحص الرسائل المحمّلة عند فتح الروم أو البحث في الخادم المحدد
        localAlways: false,       // مقفل على false: الاعتماد على نماذج الذكاء الاصطناعي فقط
        skipOwn: true,            // تجاهل رسائلي (إلا إذا أُضيف معرّفي ضمن الإدارة)
        toast: true,              // تنبيه منبثق
        inChatNotice: true,       // تنبيه محلي داخل الروم المفتوح
        findings: [],
        scannedIds: [],           // آخر 5000 معرّف رسالة مفحوصة (تخفيف الاحتفاظ بالبيانات)
        adminNames: {},           // أسماء معرّفات الإدارة المكتشفة
        searchProgress: {
            guildId: "",
            admins: {},           // { uid: { nextOffset, reachedEnd, fetched, total, updatedAt } }
            fetchedTotal: 0,
            queuedTotal: 0,
            updatedAt: 0
        },
        memberScope: "admins",    // أضيق خيار افتراضي: "admins" (الإدارة فقط) | "all" (كل رسائل الأعضاء)
        memberCrawl: {
            guildId: "",
            channels: {},         // { channelId: { before, done, fetched, skipped } }
            fetchedTotal: 0,
            queuedTotal: 0,
            updatedAt: 0
        }
    };

    var PROVIDERS = {
        local: {
            label: "محلي (مقفل 🔒)",
            sourceName: "محلي",
            locked: true
        },
        omniroute: {
            label: "OmniRoute (محلي / متوافق OpenAI)",
            sourceName: "OmniRoute",
            urlProp: "omnirouteUrl",
            keyProp: "omnirouteKey",
            modelProp: "omnirouteModel",
            keyOptional: true,
            defaultBearer: "",
            keyPlaceholder: "مفتاح OmniRoute (اختياري)",
            keyHint: "يعمل عبر خادم OmniRoute المحلي على جهازك (http://127.0.0.1:20128/v1) مع النماذج التي تحددها.",
            urlPresets: ["http://127.0.0.1:20128/v1", "http://localhost:20128/v1"],
            presets: [
                "gemini-4-hydrogen-medium",
                "gemini-web/gemini-3.1-pro",
                "gemini-web/gemini-3.7-flash",
                "gemini-web/gemini-3.1-flash-lite",
                "auto/best-vision",
                "antigravity/gemini-3-flash",
                "agy/gemini-3.8-flash-high",
                "agy/gemini-3.8-flash-medium",
                "agy/gemini-3.1-flash-lite",
                "auto"
            ]
        },
        coarena: {
            label: "CoArena (gemini-3-8-flash)",
            sourceName: "CoArena",
            urlProp: "coarenaUrl",
            keyProp: "coarenaKey",
            modelProp: "coarenaModel",
            sendXApiKey: true,
            keyPlaceholder: "coa_...",
            keyHint: "أدخل مفتاح CoArena على https://coarena.ai/api/v1 مع النماذج المتاحة مثل gemini-3-8-flash و gpt-6-luna و deepseek-v4-1-flash-1017.",
            urlPresets: ["https://coarena.ai/api/v1", "https://coarena.ai/api"],
            presets: [
                "gemini-3-8-flash",
                "gpt-6-luna",
                "deepseek-v4-1-flash-1017",
                "gemini-4-argon",
                "gpt-6-1-sol",
                "claude-haiku-5-5",
                "grok-4-7"
            ]
        },
        groq: {
            label: "Groq (جروك السريع)",
            sourceName: "Groq",
            endpoint: "https://api.groq.com/openai/v1/chat/completions",
            keyProp: "groqKey",
            modelProp: "groqModel",
            keyPlaceholder: "gsk_...",
            keyHint: "المفتاح من console.groq.com — يعمل على نماذج qwen/qwen3.8-27b و openai/gpt-oss-120b و openai/gpt-oss-20b.",
            presets: [
                "qwen/qwen3.8-27b",
                "openai/gpt-oss-120b",
                "openai/gpt-oss-20b"
            ]
        },
        gemini: {
            label: "جيميني (Gemini)",
            sourceName: "Gemini",
            keyProp: "geminiKey",
            modelProp: "geminiModel",
            keyPlaceholder: "AIza... أو AQ...",
            keyHint: "المفتاح من aistudio.google.com — يدعم نماذج Gemini و Gemma (مع معالجة توافق Gemma تلقائياً).",
            presets: ["gemma-4-26b-a4b-it", "gemma-4-31b-it", "gemini-3.8-flash", "gemini-2.5-flash"]
        },
        yepapi: {
            label: "YepAPI",
            sourceName: "YepAPI",
            endpoint: "https://api.yepapi.com/v1/ai/chat/completions",
            keyProp: "yepapiKey",
            modelProp: "yepapiModel",
            sendXApiKey: true,
            keyPlaceholder: "yep_sk_...",
            keyHint: "أدخل مفتاح YepAPI الخاص بك مع اختيار النماذج المطلوبة.",
            extraHeaders: {
                "X-App-Name": "Bahr Guard",
                "X-App-Website": "https://bahr.app"
            },
            presets: [
                "nvidia/nemotron-3-super-120b-a12b:free",
                "google/gemini-3.8-flash",
                "qwen/qwen3.7-flash",
                "deepseek/deepseek-v4-flash",
                "google/gemini-2.5-flash-lite",
                "google/gemini-2.5-flash",
                "openai/gpt-4o-mini",
                "meta-llama/llama-4-scout"
            ]
        },
        openrouter: {
            label: "OpenRouter (كل النماذج)",
            sourceName: "OpenRouter",
            endpoint: "https://openrouter.ai/api/v1/chat/completions",
            keyProp: "openrouterKey",
            modelProp: "openrouterModel",
            keyPlaceholder: "sk-or-v1-...",
            keyHint: "المفتاح من openrouter.ai/keys مع دعم التبديل التلقائي.",
            extraHeaders: {
                "HTTP-Referer": "https://bahr.app",
                "X-Title": "Bahr Guard"
            },
            presets: [
                "openrouter/free",
                "meta-llama/llama-3.3-70b-instruct:free",
                "google/gemini-2.5-flash",
                "openai/gpt-4o-mini",
                "x-ai/grok-3-mini",
                "deepseek/deepseek-chat-v3-0324:free"
            ]
        },
        grok: {
            label: "Grok (xAI)",
            sourceName: "Grok",
            endpoint: "https://api.x.ai/v1/chat/completions",
            keyProp: "grokKey",
            modelProp: "grokModel",
            keyPlaceholder: "xai-...",
            keyHint: "المفتاح من console.x.ai — يمكنك إضافة أكثر من مفتاح للتبديل التلقائي.",
            presets: ["grok-3-mini", "grok-3-mini-fast", "grok-3", "grok-2-latest"]
        },
        openai: {
            label: "OpenAI Moderation (مجاني)",
            sourceName: "OpenAI",
            keyProp: "openaiKey",
            keyPlaceholder: "sk-...",
            keyHint: "المفتاح من platform.openai.com/api-keys — واجهة Moderation مجانية. يمكنك إضافة أكثر من مفتاح (مفتاح في كل سطر).",
            maxBatch: 30
        },
        custom: {
            label: "مخصص (أي API)",
            sourceName: "مخصص",
            urlProp: "customUrl",
            keyProp: "customKey",
            modelProp: "customModel",
            keyOptional: true,
            keyPlaceholder: "مفاتيح API (اختياري للخوادم المحلية)...",
            keyHint: "يدعم أي مزوّد متوافق مع OpenAI مثل DeepSeek أو Together أو Mistral أو Cerebras أو Ollama المحلي.",
            presets: ["deepseek-chat", "mistral-small-latest", "llama3.1"]
        }
    };

    var PROVIDER_ORDER = ["local", "omniroute", "coarena", "groq", "gemini", "yepapi", "openrouter", "grok", "openai", "custom"];

    var cfg = JSON.parse(JSON.stringify(DEFAULTS));
    var storageRef = null;
    var MAX_FINDINGS = 2500;
    var REQUEST_GAP_MS = 50;
    var FORWARD_GAP_MS = 3500;
    var SEARCH_GAP_MS = 900;
    var SEARCH_JITTER_MS = 250;
    var CRAWL_GAP_MS = 150;
    var CRAWL_JITTER_MS = 80;
    var MAX_TEXT = 1500;
    var NOTICE_AUTHOR_ID = "1";
    var MAX_DIAG_LOGS = 25;
    var diagnosticLogs = [];

    function sanitizeErrorMessage(raw) {
        var s = String(raw || "");
        if (!s) return "";
        s = s
            .replace(/https?:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\/\d+\/[A-Za-z0-9._-]+/gi, "[Webhook]")
            .replace(/\b(?:yep_sk_|sk-or-v1-|sk-ar-v1-|sk-eden-live-|sk-orca-|sk-|coa_|gsk_|xai-|ak_|AIza)[A-Za-z0-9._-]{6,}/gi, "[API_KEY]")
            .replace(/\bAQ\.[A-Za-z0-9._-]{8,}/g, "[API_KEY]")
            .replace(/Bearer\s+[A-Za-z0-9._:-]{6,}/gi, "Bearer [REDACTED]")
            .replace(/([?&](?:key|token|api_key)=)[^&\s]+/gi, "$1[REDACTED]")
            .replace(/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g, "[EMAIL]")
            .replace(/«[^»]{1,120}»/g, "[نص]")
            .replace(/\s+/g, " ")
            .trim();
        if (s.length > 140) s = s.slice(0, 140) + "…";
        return s;
    }

    function addDiagLog(entry) {
        try {
            var now = new Date();
            var timeStr = ("0" + now.getHours()).slice(-2) + ":" + ("0" + now.getMinutes()).slice(-2) + ":" + ("0" + now.getSeconds()).slice(-2);
            var item = {
                time: timeStr,
                provider: String((entry && entry.provider) || "AI"),
                model: String((entry && entry.model) || ""),
                ms: Number((entry && entry.ms) || 0),
                count: Number((entry && entry.count) || 0),
                ok: !!(entry && entry.ok),
                detail: sanitizeErrorMessage((entry && entry.detail) || "")
            };
            diagnosticLogs.unshift(item);
            if (diagnosticLogs.length > MAX_DIAG_LOGS) diagnosticLogs.length = MAX_DIAG_LOGS;
        } catch (e) {}
    }

    var mods = {
        RestAPI: null,
        UserStore: null,
        GuildMemberStore: null,
        ChannelStore: null,
        GuildChannelStore: null,
        GuildStore: null,
        SelectedChannelStore: null,
        MessageStore: null,
        MessageActions: null,
        Dispatcher: null,
        Toast: null,
        Router: null,
        URLOpener: null,
        Clipboard: null
    };

    var nameCache = {};

    var state = {
        queued: 0,
        imageQueued: 0,
        imagesScanned: 0,
        imageWorkers: 0,
        scanned: 0,
        preFiltered: 0,
        hallucinationsBlocked: 0,
        unreviewedCount: 0,
        inFlightBatches: 0,
        flagged: 0,
        forwarded: 0,
        forwardQueued: 0,
        lastBatchSize: 0,
        activeRoute: "",
        keyRotations: 0,
        lastError: "",
        lastScanWarning: "",
        scopeBlockedReason: "",
        lastForwardError: "",
        busy: false
    };

    var serverSearch = {
        running: false,
        stopRequested: false,
        adminIndex: 0,
        adminTotal: 0,
        currentAdmin: "",
        fetchedMsgs: 0,
        queuedMsgs: 0,
        status: "",
        lastError: ""
    };

    // ===================== أدوات عامة (مع Throttle 400ms لحماية واجهة React Native) =====================
    var listeners = [];
    var emitThrottleTimer = null;
    var lastEmitTs = 0;
    var EMIT_THROTTLE_MS = 400;

    function flushEmitNow() {
        if (emitThrottleTimer) {
            clearTimeout(emitThrottleTimer);
            emitThrottleTimer = null;
        }
        lastEmitTs = Date.now();
        for (var i = 0; i < listeners.length; i++) {
            try { listeners[i](); } catch (e) {}
        }
    }

    function emitState(immediate) {
        if (immediate) {
            flushEmitNow();
            return;
        }
        var now = Date.now();
        var elapsed = now - lastEmitTs;
        if (elapsed >= EMIT_THROTTLE_MS && !emitThrottleTimer) {
            flushEmitNow();
            return;
        }
        if (!emitThrottleTimer) {
            var wait = Math.max(50, EMIT_THROTTLE_MS - Math.max(0, elapsed));
            emitThrottleTimer = setTimeout(function () {
                emitThrottleTimer = null;
                flushEmitNow();
            }, wait);
        }
    }

    function subscribeState(fn) {
        listeners.push(fn);
        return function () {
            var idx = listeners.indexOf(fn);
            if (idx !== -1) listeners.splice(idx, 1);
        };
    }

    function getReact() {
        return (typeof valenced !== "undefined" && valenced.react && (valenced.react.React || valenced.react)) || null;
    }
    function getRN() {
        return (typeof valenced !== "undefined" && valenced.react && valenced.react.ReactNative) || null;
    }
    function sleep(ms) {
        return new Promise(function (resolve) { setTimeout(resolve, ms); });
    }
    function searchSleep() {
        var jitter = Math.floor(Math.random() * (SEARCH_JITTER_MS + 1));
        return sleep(SEARCH_GAP_MS + jitter);
    }
    function crawlSleep() {
        var jitter = Math.floor(Math.random() * (CRAWL_JITTER_MS + 1));
        return sleep(CRAWL_GAP_MS + jitter);
    }

    function normalizeDigits(str) {
        if (typeof str !== "string") return "";
        var arabic = "٠١٢٣٤٥٦٧٨٩";
        var persian = "۰۱۲۳۴۵۶۷۸۹";
        var out = "";
        for (var i = 0; i < str.length; i++) {
            var ch = str.charAt(i);
            var idx = arabic.indexOf(ch);
            if (idx !== -1) out += String(idx);
            else {
                var pidx = persian.indexOf(ch);
                out += pidx !== -1 ? String(pidx) : ch;
            }
        }
        return out;
    }

    function extractSnowflakes(raw) {
        var norm = normalizeDigits(String(raw || ""));
        var matches = norm.match(/\d{15,22}/g) || [];
        var seen = {};
        var list = [];
        for (var i = 0; i < matches.length; i++) {
            if (!seen[matches[i]]) {
                seen[matches[i]] = true;
                list.push(matches[i]);
            }
        }
        return { list: list, map: seen, count: list.length };
    }

    function extractSingleIdOrWebhook(raw) {
        var t = normalizeDigits(String(raw || "")).trim();
        if (!t) return "";
        if (/^https?:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\//i.test(t)) return t;
        var m = t.match(/\d{15,22}/);
        return m ? m[0] : "";
    }

    function isWebhookUrl(v) {
        return /^https?:\/\/(?:ptb\.|canary\.)?discord(?:app)?\.com\/api\/webhooks\//i.test(String(v || "").trim());
    }

    function saveCfg(patch) {
        for (var k in patch) {
            if (Object.prototype.hasOwnProperty.call(patch, k)) cfg[k] = patch[k];
        }
        if (storageRef && typeof storageRef.set === "function") {
            try { storageRef.set(patch); } catch (e) {}
        }
        emitState(true);
    }

    function showToast(text) {
        try {
            if (mods.Toast && typeof mods.Toast.showToast === "function") {
                mods.Toast.showToast(String(text));
                return;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.ToastAndroid && typeof RN.ToastAndroid.show === "function") {
                RN.ToastAndroid.show(String(text), RN.ToastAndroid.LONG);
            }
        } catch (e) {}
    }

    function copyText(text) {
        try {
            if (mods.Clipboard && typeof mods.Clipboard.setString === "function") {
                mods.Clipboard.setString(text);
                return true;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.Clipboard && typeof RN.Clipboard.setString === "function") {
                RN.Clipboard.setString(text);
                return true;
            }
        } catch (e) {}
        return false;
    }

    function getMyUserId() {
        try {
            if (mods.UserStore && typeof mods.UserStore.getCurrentUser === "function") {
                var u = mods.UserStore.getCurrentUser();
                if (u && u.id) return String(u.id);
            }
        } catch (e) {}
        return null;
    }

    var nameSaveTimer = null;
    function scheduleSaveAdminNames() {
        if (nameSaveTimer) return;
        nameSaveTimer = setTimeout(function () {
            nameSaveTimer = null;
            try { saveCfg({ adminNames: Object.assign({}, cfg.adminNames || {}) }); } catch (e) {}
        }, 3000);
    }

    function cacheAuthorName(author) {
        if (!author || !author.id) return;
        var uid = String(author.id);
        var dn = author.globalName || author.global_name || author.username || "";
        var un = author.username || "";
        var label = (dn && un && dn !== un) ? (dn + " (@" + un + ")") : dn;
        if (!label) return;
        nameCache[uid] = label;
        try {
            var targets = extractSnowflakes(cfg.targetUserIds);
            if (targets.map[uid]) {
                if (!cfg.adminNames || typeof cfg.adminNames !== "object") cfg.adminNames = {};
                if (cfg.adminNames[uid] !== label) {
                    cfg.adminNames[uid] = label;
                    scheduleSaveAdminNames();
                }
            }
        } catch (e) {}
    }

    function resolveUserLabel(uid, guildId) {
        var id = String(uid || "");
        if (!id) return "";
        try {
            if (mods.UserStore && typeof mods.UserStore.getUser === "function") {
                var u = mods.UserStore.getUser(id);
                if (u) {
                    var dn = u.globalName || u.global_name || u.username || "";
                    var un = u.username || "";
                    var nick = "";
                    try {
                        if (guildId && mods.GuildMemberStore && typeof mods.GuildMemberStore.getNick === "function") {
                            nick = mods.GuildMemberStore.getNick(guildId, id) || "";
                        }
                    } catch (e) {}
                    var best = nick || dn;
                    if (best && un && best !== un) {
                        nameCache[id] = best + " (@" + un + ")";
                        return nameCache[id];
                    }
                    if (best) {
                        nameCache[id] = best;
                        return best;
                    }
                }
            }
        } catch (e) {}
        try {
            if (guildId && mods.GuildMemberStore && typeof mods.GuildMemberStore.getNick === "function") {
                var nk = mods.GuildMemberStore.getNick(guildId, id);
                if (nk) { nameCache[id] = nk; return nk; }
            }
        } catch (e) {}
        return nameCache[id] || "";
    }

    function getGuildName(guildId) {
        if (!guildId) return "";
        try {
            if (mods.GuildStore && typeof mods.GuildStore.getGuild === "function") {
                var g = mods.GuildStore.getGuild(String(guildId));
                if (g && g.name) return g.name;
            }
        } catch (e) {}
        return "";
    }

    function getCurrentChannelId() {
        try {
            if (mods.SelectedChannelStore && typeof mods.SelectedChannelStore.getChannelId === "function") {
                return mods.SelectedChannelStore.getChannelId() || "";
            }
        } catch (e) {}
        return "";
    }

    function getChannelInfo(channelId) {
        var info = { channelId: channelId || "", guildId: null, guildName: "", channelName: "", typeLabel: "قناة" };
        if (!channelId) return info;
        var ch = null;
        try {
            if (mods.ChannelStore && typeof mods.ChannelStore.getChannel === "function") ch = mods.ChannelStore.getChannel(channelId);
        } catch (e) {}
        if (!ch) { info.channelName = "قناة " + channelId; return info; }
        info.guildId = ch.guild_id || ch.guildId || null;
        if (ch.type === 1) {
            info.typeLabel = "خاص";
            var recName = "محادثة خاصة";
            try {
                var rIds = ch.recipients || ch.rawRecipients;
                if (Array.isArray(rIds) && rIds.length > 0) {
                    var first = rIds[0];
                    if (typeof first === "object" && first) recName = first.globalName || first.global_name || first.username || recName;
                    else { var lbl = resolveUserLabel(first, null); if (lbl) recName = lbl; }
                }
            } catch (e) {}
            info.channelName = recName;
        } else if (ch.type === 3) {
            info.typeLabel = "قروب";
            var gName = ch.name || "";
            if (!gName) {
                try {
                    var names = [];
                    var rList = ch.recipients || [];
                    for (var i = 0; i < rList.length && i < 3; i++) {
                        var rid = typeof rList[i] === "object" ? rList[i].id : String(rList[i]);
                        var rl = resolveUserLabel(rid, null);
                        if (rl) names.push(rl);
                    }
                    gName = names.length ? names.join("، ") : "قروب خاص";
                } catch (e) { gName = "قروب خاص"; }
            }
            info.channelName = gName;
        } else if (ch.type === 11 || ch.type === 12 || ch.type === 10) {
            info.typeLabel = "ثريد";
            info.channelName = ch.name ? ("🧵 " + ch.name) : channelId;
        } else {
            info.typeLabel = "سيرفر";
            info.channelName = ch.name ? ("#" + ch.name) : channelId;
        }
        if (info.guildId) info.guildName = getGuildName(info.guildId);
        return info;
    }

    function listPrivateChannels(maxItems) {
        var out = [];
        try {
            if (!mods.ChannelStore) return out;
            var raw = null;
            if (typeof mods.ChannelStore.getSortedPrivateChannels === "function") {
                raw = mods.ChannelStore.getSortedPrivateChannels();
            } else if (typeof mods.ChannelStore.getMutablePrivateChannels === "function") {
                var map = mods.ChannelStore.getMutablePrivateChannels();
                if (map && typeof map === "object") raw = Object.keys(map).map(function (k) { return map[k]; });
            }
            if (Array.isArray(raw)) {
                for (var i = 0; i < raw.length && out.length < (maxItems || 25); i++) {
                    var c = raw[i];
                    if (c && c.id && (c.type === 1 || c.type === 3)) out.push(getChannelInfo(c.id));
                }
            }
        } catch (e) {}
        return out;
    }

    function listGuildChannelIds(guildId) {
        var ids = [];
        var seen = {};
        function add(id) {
            if (!id) return;
            var s = String(id);
            if (!seen[s]) { seen[s] = true; ids.push(s); }
        }
        try {
            if (mods.ChannelStore && typeof mods.ChannelStore.getMutableGuildChannelsForGuild === "function") {
                var m = mods.ChannelStore.getMutableGuildChannelsForGuild(guildId);
                if (m && typeof m === "object") {
                    for (var k in m) if (Object.prototype.hasOwnProperty.call(m, k)) add(k);
                }
            }
        } catch (e) {}
        try {
            if (mods.GuildChannelStore && typeof mods.GuildChannelStore.getChannels === "function") {
                var gc = mods.GuildChannelStore.getChannels(guildId);
                if (gc) {
                    var lists = [gc.SELECTABLE, gc.VOCAL, gc.THREADS];
                    for (var i = 0; i < lists.length; i++) {
                        if (Array.isArray(lists[i])) {
                            for (var j = 0; j < lists[i].length; j++) {
                                var ch = lists[i][j] && lists[i][j].channel;
                                if (ch && ch.id) add(ch.id);
                            }
                        }
                    }
                }
            }
        } catch (e) {}
        return ids;
    }

    function messageLink(f) {
        return "https://discord.com/channels/" + (f.guildId || "@me") + "/" + f.channelId + "/" + f.messageId;
    }

    function jumpToMessage(f) {
        var path = "/channels/" + (f.guildId || "@me") + "/" + f.channelId + "/" + f.messageId;
        var url = "https://discord.com" + path;
        try {
            if (mods.Router && typeof mods.Router.transitionTo === "function") {
                mods.Router.transitionTo(path);
                return true;
            }
        } catch (e) {}
        try {
            if (mods.URLOpener && typeof mods.URLOpener.openURL === "function") {
                mods.URLOpener.openURL(url);
                return true;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.Linking && typeof RN.Linking.openURL === "function") {
                RN.Linking.openURL(url);
                return true;
            }
        } catch (e) {}
        return false;
    }

    function openExternal(url) {
        try {
            var RN = getRN();
            if (RN && RN.Linking) RN.Linking.openURL(url);
        } catch (e) {}
    }

    function normalizeChatEndpoint(url) {
        var u = String(url || "").trim().replace(/\/+$/, "");
        if (!u) return "";
        if (/\/chat\/completions$/i.test(u)) return u;
        if (/\/api$/i.test(u)) return u + "/v1/chat/completions";
        return u + "/chat/completions";
    }

    function normalizeModelsEndpoint(url) {
        var u = String(url || "").trim();
        if (!u) return "";
        u = u.replace(/\/chat\/completions\/?$/i, "").replace(/\/+$/, "");
        if (/\/models$/i.test(u)) return u;
        if (/\/api$/i.test(u)) return u + "/v1/models";
        return u + "/models";
    }

    function parseKeyList(raw) {
        if (typeof raw !== "string") return [];
        var parts = raw.split(/[\r\n,;\s]+/);
        var seen = {};
        var list = [];
        for (var i = 0; i < parts.length; i++) {
            var k = parts[i].trim();
            if (k && k.length >= 4 && !seen[k]) {
                seen[k] = true;
                list.push(k);
            }
        }
        return list;
    }

    function parseModelList(raw) {
        if (typeof raw !== "string") return [];
        var parts = raw.split(/[\r\n,;]+/);
        var seen = {};
        var list = [];
        for (var i = 0; i < parts.length; i++) {
            var m = parts[i].trim();
            if (m && !seen[m]) {
                seen[m] = true;
                list.push(m);
            }
        }
        return list;
    }

    function maskKey(k) {
        var s = String(k || "").trim();
        if (!s) return "(بدون مفتاح)";
        if (s.length <= 6) return "…" + s.slice(-2);
        return "…" + s.slice(-4);
    }

    function getProviderKeys(providerId) {
        var p = PROVIDERS[providerId];
        if (!p || !p.keyProp) return [];
        return parseKeyList(cfg[p.keyProp] || "");
    }

    function getProviderModels(providerId) {
        var p = PROVIDERS[providerId];
        if (!p || providerId === "local") return [];
        if (!p.modelProp) return ["omni-moderation-latest"];
        var list = parseModelList(cfg[p.modelProp] || "");
        if (list.length) return list;
        return (p.presets && p.presets.length) ? [p.presets[0]] : [];
    }

    function isProviderReady(providerId, forFailover) {
        var p = PROVIDERS[providerId];
        if (!p || providerId === "local" || p.locked) return false;
        if (providerId === "omniroute") {
            if (forFailover && !cfg.omnirouteInFailover) return false;
            return !!String(cfg.omnirouteUrl || "").trim() && getProviderModels("omniroute").length > 0;
        }
        if (providerId === "custom") {
            if (forFailover && (!cfg.customInFailover || getProviderKeys("custom").length === 0)) return false;
            return !!String(cfg.customUrl || "").trim() && getProviderModels("custom").length > 0;
        }
        if (getProviderKeys(providerId).length === 0) return false;
        if (p.modelProp && getProviderModels(providerId).length === 0) return false;
        return true;
    }

    function hasAnyAiProvider() {
        if (cfg.omnirouteOnly) return isProviderReady("omniroute", false);
        if (isProviderReady(cfg.provider, false)) return true;
        if (!cfg.autoFailoverProviders) return false;
        for (var i = 0; i < PROVIDER_ORDER.length; i++) {
            var pid = PROVIDER_ORDER[i];
            if (pid !== "local" && isProviderReady(pid, true)) return true;
        }
        return false;
    }

    // ===================== التصنيفات ومسارات الإبلاغ =====================
    var CATS = {
        "sexual/minors": {
            label: "استغلال جنسي للأطفال (CSAM)",
            severity: 100,
            banRisk: true,
            color: "#FF0033",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "سلامة الأطفال / مواد استغلال جنسي للأطفال"],
            extra: "⚠️ لا تفتح أو تحفظ أو تصوّر أو تشارك أي مرفق. بلّغ ديسكورد، وبلّغ أيضاً مركز NCMEC عبر report.cybertip.org. وبلّغ عن الخادم نفسه.",
            hideSnippet: true
        },
        "terrorism": {
            label: "إرهاب / تطرف عنيف / تجنيد",
            severity: 95,
            banRisk: true,
            color: "#B71C1C",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "معلومات مضللة ضارة أو تمجيد العنف", "التطرف العنيف أو الإرهاب"],
            extra: "🔥 مخالفة خطيرة موجبة لحظر الخادم: انسخ المعرّفات وروابط رسائل الإدارة وبلّغ أيضاً عن الخادم عبر dis.gd/request (فئة التطرف العنيف والإرهاب)."
        },
        "self-harm": {
            label: "إيذاء النفس / انتحار",
            severity: 90,
            banRisk: true,
            color: "#E67E22",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "إيذاء النفس أو الانتحار"],
            extra: "إن كان الشخص في خطر حقيقي فتواصل معه بلطف ووجّهه لخط مساعدة: findahelpline.com"
        },
        "violence": {
            label: "تهديد بالقتل / تحريض على العنف / دموية",
            severity: 85,
            banRisk: true,
            color: "#C0392B",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "معلومات مضللة ضارة أو تمجيد العنف", "تمجيد العنف أو التحريض عليه"]
        },
        "illicit": {
            label: "نشاط غير قانوني خطير / أسلحة / مخدرات / اختراق",
            severity: 75,
            banRisk: true,
            color: "#8E44AD",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "بيع سلع غير قانونية أو خاضعة للرقابة"]
        },
        "hate": {
            label: "خطاب كراهية عنيف / تحريض ضد فئة",
            severity: 65,
            banRisk: true,
            color: "#D35400",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "إساءة أو مضايقة", "خطاب كراهية"]
        },
        "sexual": {
            label: "محتوى جنسي صريح / غير توافقي",
            severity: 55,
            banRisk: true,
            color: "#E91E63",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "شيء آخر", "عري أو محتوى جنسي"]
        },
        "harassment": {
            label: "قذف / لعن / سب شديد جداً",
            severity: 72,
            banRisk: true,
            color: "#E74C3C",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "إساءة أو مضايقة"]
        },
        "scam": {
            label: "احتيال / تصيّد / سبام",
            severity: 60,
            banRisk: true,
            color: "#F1C40F",
            steps: ["اضغط مطولاً على الرسالة", "إبلاغ", "رسائل مزعجة (سبام)"],
            extra: "لا تضغط على الرابط ولا تدخل بيانات حسابك."
        },
        "blocked": {
            label: "محتوى رفض النموذج تحليله (مشبوه جداً)",
            severity: 88,
            banRisk: true,
            color: "#FF5555",
            steps: ["افتح الرسالة بحذر وراجعها بنفسك", "إن تأكدت: اضغط مطولاً ← إبلاغ ← اختر النوع المناسب"],
            extra: "حجب مزوّد الذكاء الاصطناعي الرد لأن النص يحوي محتوى محظوراً بشدة. لا تفتح المرفقات."
        }
    };

    var SERVER_BAN_CATS = ["sexual/minors", "terrorism", "violence", "illicit", "hate", "harassment", "sexual", "scam"];
    var ALL_AI_CATS = ["sexual/minors", "terrorism", "violence", "illicit", "hate", "harassment", "sexual", "scam"];

    var OPENAI_MAP = {
        "sexual/minors": "sexual/minors",
        "violence": "violence",
        "violence/graphic": "violence",
        "harassment/threatening": "violence",
        "hate/threatening": "violence",
        "illicit": "illicit",
        "illicit/violent": "illicit",
        "hate": "hate",
        "harassment": "harassment",
        "sexual": "sexual"
    };

    // ===================== الكشف المحلي =====================
    var OFFICIAL_DOMAINS = /^(?:[a-z0-9-]+\.)*(discord\.com|discord\.gg|discordapp\.com|discordapp\.net|discord\.media|discord\.new|discord\.gift|discordstatus\.com|steampowered\.com|steamcommunity\.com|tenor\.com|giphy\.com|youtube\.com|youtu\.be|google\.com)$/i;
    var LOOKALIKE = /(d[i1l!|][s5$][ckq][o0][r][dcl]|disc[o0]rd|dlscord|discrod|d1scord|nitr[o0]|st[e3]am|ste[a@]m)/i;
    var URL_RE = /https?:\/\/([^\s\/<>"']+)/gi;

    var RULES = [
        { cat: "sexual/minors", severe: true, score: 0.92, re: /(child\s*porn|\bcp\s*(link|vid|pack|sell|trade|for sale)|pedo\s*(link|pack|vid)|preteen\s*(nude|sex)|underage\s*(nude|sex|porn)|loli\s*(porn|nude|sex|hentai)|\bjailbait\b|اباحية\s*اطفال|إباحية\s*أطفال|سكس\s*(اطفال|أطفال|قاصر|قاصرات|صغار|ورعان|بزران)|صور\s*(اطفال|قاصرات|ورعان)\s*(عاري|عارية|سكس)|مقاطع\s*(ورعان|بزران|قاصرات))/i },
        { cat: "terrorism", severe: true, score: 0.94, re: /(باقية\s*وتتمدد|الدولة\s*(الاسلامية|الإسلامية)\s*(في\s*العراق\s*والشام|باقية|على\s*منهاج)|دولة\s*الخلافة\s*(باقية|تنتصر)|بيعة\s*(ل?داعش|ل?لبغدادي|ل?أبو\s*بكر|ل?تنظيم|ل?لدولة|ل?لجولاني|ل?لقاعدة|ل?لظواهري)|أبايع\s*(تنظيم|داعش|الخليفة|الدولة|البغدادي|القاعدة)|نبايع\s*(داعش|الدولة|البغدادي|القاعدة)|انضم(وا)?\s*(ل?داعش|ل?تنظيم|ل?لجهاد\s*المسلح|ل?لذئاب)|داعش\s*(تنتصر|باقية|على\s*حق|أبطال|ابطال|منصور|تمثلنا|يمثلون\s*الاسلام|يمثلون\s*الإسلام|تاج\s*راسك)|تنظيم\s*(القاعدة|الدولة)\s*(أبطال|ابطال|على\s*حق|نصر|باقي)|أسامة\s*بن\s*لادن\s*(بطل|شهيدنا|قدوتنا|رحمه\s*الله\s*على\s*عملية|امام\s*المجاهدين|إمام\s*المجاهدين)|(أبو\s*بكر\s*البغدادي|ابو\s*بكر\s*البغدادي|أبو\s*مصعب\s*الزرقاوي|ابو\s*مصعب\s*الزرقاوي|خطاب|الظواهري)\s*(تقبله\s*الله|شهيد\s*الأمة|بطل|قدوتنا|أمير\s*المؤمنين)|عملية\s*(استشهادية|انغماسية)\s*(مباركة|تقبل|نفذ|استهدف|فجر)?|انغماسي(ين|ة)?\s*(تقبل|بارك|مبارك|يفجر)|حزام\s*ناسف|سترة\s*ناسفة|تفخيخ\s*(سيارة|سيارات|عبوة|عبوات)|(صناعة|طريقة\s*صنع|تحضير|تركيب)\s*(قنبلة|قنابل|متفجرات|عبوة\s*ناسفة|الريسين|تي\s*ان\s*تي|\btnt\b|\bc4\b)|(اصدارات|إصدارات)\s*(ولاية|داعش|الفرقان|أعماق|اعماق|الحياة|السحاب)|وكالة\s*(أعماق|اعماق)|مؤسسة\s*(الفرقان|الاعتصام|أجناد|اجناد|السحاب|الملاحم)|نشر\s*(اصدار|إصدار)\s*(ذبح|نحر|داعش)|ذبح\s*(الكفار|المرتدين|الروافض|الطواغيت|الصليبيين|المشركين)|انحروا\s*(الكفار|المرتدين|الروافض|المشركين)|اقتلوا\s*(الكفار|المرتدين|المشركين|المدنيين|اليهود|النصارى|الشيعة|السنة)|فجروا\s*(المساجد|الكنائس|السفارات|المدارس|الحسينيات|المعابد)|الذئاب\s*المنفردة|تفجير\s*(مسجد|كنيسة|مدرسة|مول|سوق|سفارة|مطار|حسينية)|join\s*(isis|daesh|da3esh|isil|al[\s-]?qaeda)|pledge\s*(allegiance|bayah)\s*to\s*(isis|daesh|da3esh|isil|islamic\s*state|al[\s-]?qaeda)|(isis|daesh|da3esh|isil)\s*(nasheed|nasheeds|release|beheading|propaganda|amaq|edit|edits|was\s*right|are\s*heroes)|amaq\s*(news|agency)|baqiya(h)?\s*(wa\s*tatamaddad)?|how\s*to\s*(make|build|craft)\s*(a\s*)?(bomb|ied|explosive|pipe\s*bomb|suicide\s*vest|\btnt\b|\bc4\b|ricin)|(bomb|ied|explosive)\s*(recipe|manual|tutorial|instructions)|lone\s*wolf\s*attack|mass\s*shooting\s*(plan|manifesto|livestream)|(praise|glory\s*to|heil|based)\s*(isis|daesh|brenton\s*tarrant|anders\s*breivik|osama\s*bin\s*laden|al[\s-]?baghdadi|zarqawi)|suicide\s*(vest|belt|bombing\s*tutorial))/i },
        { cat: "violence", severe: true, score: 0.82, re: /(i\s*(will|'ll|am\s*going\s*to)\s*(kill|shoot|stab|murder|behead)\s*(you|u|him|her|them)|bomb\s*(the|a)\s*(school|mosque|church)|shoot\s*up\s*(the|a)\s*(school|mosque|church|mall)|سأقتلك|راح\s*اقتلك|بقتلك|والله\s*(لاقتلك|لأقتلك|لاذبحك|لأذبحك)|بذبحك|راح\s*اذبحك|سأذبحك|نحر\s*من\s*الوريد|فيديو\s*(ذبح|نحر|تقطيع|اعدام|إعدام))/i },
        { cat: "illicit", severe: true, score: 0.78, re: /((weed|cocaine|coke|meth|mdma|xanax|lsd|heroin|ecstasy)\s*(for\s*sale|dm\s*me|available|plug)|selling\s*(weed|coke|meth|drugs|guns|firearms|cc\b|fullz|botnet|ddos)|\bcc\s*dumps?\b|(حشيش|مخدرات|كبتاجون|كبتاغون|شبو|كريستال|ترامادول|سلاح|اسلحة|أسلحة|مسدس|كلاشنكوف|رشاش|ذخيرة)\s*(للبيع|متوفر|متوفرة|توصيل)|بيع\s*(حشيش|مخدرات|كبتاجون|سلاح|أسلحة|فيزا\s*مسروقة|بطاقات\s*مسروقة))/i },
        { cat: "sexual", severe: false, score: 0.65, re: /(\bporn(hub)?\b|\bxvideos\b|\bxnxx\b|onlyfans\s*(leak|leaks|free)|\bnudes?\s*(leak|pack|for\s*sale|dm)|\bnsfw\s*(link|leak)|سكس|نيك|افلام\s*اباحية|أفلام\s*إباحية|مقاطع\s*اباحية|صور\s*عارية|محارم)/i },
        { cat: "scam", severe: false, score: 0.7, re: /(free\s*nitro|nitro\s*(for\s*)?free|claim\s*(your\s*)?(nitro|gift|reward)|steam\s*gift|\$\d+\s*steam|airdrop|crypto\s*giveaway|نيترو\s*مجان|نيترو\s*ببلاش|هدية\s*ستيم|اربح\s*نيترو)/i },
        { cat: "hate", severe: false, score: 0.65, re: /(\bn[i1]gg(er|a)s?\b|\bfaggots?\b|\bkikes?\b|gas\s*the\s*jews|يا\s*(عبد|عبيد)\b|يا\s*زنجي|الله\s*يلعن\s*(دينك|دين\s*ابوك|دين\s*أبوك))/i },
        { cat: "harassment", severe: true, score: 0.85, re: /(يا\s*(منيوك|قحبة|شرموط|شرموطة|عاهر|عاهرة|ديوث|لوطي|ابن\s*الحرام|ولد\s*القحبة)|ابن\s*(القحبة|الشرموطة|الزانية|الحرام)|كس\s*(امك|أمك|اختك|أختك)|يلعن\s*(امك|أمك|ابوك|أبوك|ربك|دينك|شرفك)|الله\s*يلعنك|لعنة\s*الله\s*عليك|يا\s*زاني|يا\s*زانية)/i }
    ];

    var DOX_CONTEXT = /(رقمه|رقمها|رقم\s*(جواله|جوالها|تلفونه|هاتفه|هاتفها)|عنوانه|عنوانها|ساكن|ساكنة|يسكن|تسكن|بيته|بيتها|\bdox(x)?(ed|ing)?\b|home\s*address|his\s*address|her\s*address|lives\s*at|ip\s*:?)/i;
    var PHONE_RE = /(\+?\d[\d\s\-]{8,}\d)/;
    var IP_RE = /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/;

    function localDetect(text) {
        var hits = [];
        if (!text) return hits;
        var severeOnly = cfg.auditMode === "server_ban";
        for (var i = 0; i < RULES.length; i++) {
            if (severeOnly && !RULES[i].severe) continue;
            if (RULES[i].re.test(text)) hits.push({ cat: RULES[i].cat, score: RULES[i].score, reason: "تطابق مباشر (كشف محلي)" });
        }
        if (!severeOnly) {
            var m;
            URL_RE.lastIndex = 0;
            while ((m = URL_RE.exec(text)) !== null) {
                var host = String(m[1] || "").toLowerCase().split(":")[0];
                if (!OFFICIAL_DOMAINS.test(host) && LOOKALIKE.test(host)) {
                    hits.push({ cat: "scam", score: 0.9, reason: "رابط مقلّد: " + host });
                    break;
                }
            }
        }
        if ((PHONE_RE.test(text) || IP_RE.test(text)) && DOX_CONTEXT.test(text)) {
            hits.push({ cat: "doxxing", score: 0.75, reason: "نشر رقم/عنوان شخصي" });
        }
        return hits;
    }

    // ===================== الفرز الذكي المسبق + مانع الإنذارات المتناقضة + مزوّدات الذكاء الاصطناعي =====================
    var SUSPICIOUS_HINT_RE = /(داعش|دول[ةه]|خلاف[ةه]|بغداد|قاعد[ةه]|لادن|زرقاو|جولان|بايع|بيع[ةه]|استشهاد|انغماس|حزام|ناسف|تفجير|فجر|ذبح|نحر|اعماق|أعماق|فرقان|اصدار|إصدار|ولاي[ةه]|سيناء|طاغوت|طواغيت|مرتد|كافر|كفار|رافض|روافض|صليب|يهود|نصار|شيع|مجوس|انتحر|انتحار|بنتحر|اقتل|أقتل|قتل|نقتل|تقتل|موت|اموت|اذبح|أذبح|دم|سلاح|اسلح|أسلح|كلاشنكوف|مسدس|رشاش|ذخير|قنبل|قنابل|متفجر|عبو[ةه]|لغم|صواعق|بارود|ريسين|حشيش|مخدر|كبتاجون|كبتاغون|شبو|كريستال|ترامادول|هيروين|كوكايين|سكس|اباح|إباح|نيك|قاصر|اطفال|أطفال|ورعان|بزران|صغار|عاري|عاريه|محارم|اغتصاب|تحرش|قحب|شرموط|منيوك|ديوث|لوط|عاهر|زنجي|عبد|عبيد|خنزير|كلب|حمار|يلعن|لعن|نيترو|ستيم|هكر|اختراق|فيزا|بطاق|مسروق|رقمه|رقمها|جواله|عنوانه|عنوانها|ساكن|بيته|جهاد|مجاهد|كتائب|سرايا|جند|غزو[ةه]|عملي[ةه]|شهيد|انصار|أنصار|مهاجر|isis|daesh|da3esh|isil|qaeda|taliban|boko|shabaab|amaq|furqan|nasheed|bayah|caliphate|baqiya|baghdadi|zarqawi|laden|jihad|mujahid|martyr|bomb|ied|tnt|c4|ricin|anthrax|explosive|detonat|grenade|vest|suicide|kms|kys|self[\s-]?harm|cut\s*myself|hang\s*myself|overdose|kill|murder|slaughter|massacre|shoot|shooting|stab|behead|decapitat|execute|execution|gore|torture|rape|molest|attack|terror|extremis|militia|nazi|hitler|heil|tarrant|breivik|klan|kkk|supremac|exterminat|genocide|subhuman|nigg|faggot|kike|chink|tranny|retar|whore|slut|bitch|fuck\s*you|motherfuck|porn|nude|nsfw|onlyfans|xnxx|xvideos|hentai|loli|shota|pedo|cp\b|csam|child|minor|underage|preteen|jailbait|groom|weed|coke|cocaine|meth|mdma|xanax|fentanyl|heroin|lsd|ecstasy|drug|dealer|plug|gun|firearm|rifle|pistol|ammo|glock|ak47|ar15|nitro|steam|airdrop|giveaway|phish|scam|dox|swat|address|phone|ip\b|hack|ddos|botnet|malware|ransom|stealer|fullz|cvv|dump|carding)/i;

    var BENIGN_SHORT_RE = /^(?:ه+|هاها+|هههه+|لول+|lol+|lmao+|rofl|ok+|okay|k+|yes|yep|yeah|yup|no|nope|nah|gg|wp|gj|nice|cool|awesome|great|good|bad|wow|omg|wtf|idk|ikr|imo|imho|tbh|ngl|fr|bet|alright|alright\s+bet|sure|fine|maybe|probably|wait|wait\s+really|really|seriously|bro|bruh|man|dude|guys|chat|hello|hi|hey|yo|sup|whats\s+up|what\s+s\s+up|how\s+are\s+you|good\s+morning|good\s+night|good\s+evening|gn|gm|see\s+you|see\s+you\s+later|see\s+ya|cya|bye|brb|be\s+right\s+back|afk|gtg|g2g|omw|on\s+my\s+way|back|im\s+back|i\s+m\s+back|hold\s+on|hold\s+on\s+a\s+sec|one\s+sec|wait\s+a\s+sec|let\s+me\s+check|let\s+me\s+see|sounds\s+good|sounds\s+good\s+to\s+me|makes\s+sense|fair\s+enough|got\s+it|i\s+see|understood|same|same\s+here|true|facts|real|for\s+real|no\s+way|no\s+way\s+bro|locked\s+in|i\s+ll\s+get\s+back\s+to\s+you(?:\s+on\s+that)?|get\s+back\s+to\s+you(?:\s+on\s+that)?|i\s+dont\s+know(?:\s+about\s+that)?|what\s+time\s+is\s+it|going\s+offline(?:\s+now)?|thanks|thank\s+you|thanks\s+man|thanks\s+bro|ty|tysm|np|no\s+problem|yw|you\s+re\s+welcome|تمام|تم|طيب|نعم|لا|اي|ايه|إيه|يب|صح|اكيد|أكيد|ممتاز|حلو|جميل|رائع|شكرا|شكراً|عفوا|العفو|امين|آمين|اميين|آميـن|يا\s*رب|يارب|ماشاء\s*الله|ما\s*شاء\s*الله|تبارك\s*الله|سبحان\s*الله|سبحان\s*الله\s*وبحمده|الحمد\s*لله|الحمدلله|استغفر\s*الله|أستغفر\s*الله|لا\s*اله\s*الا\s*الله|لا\s*إله\s*إلا\s*الله|الله\s*اكبر|الله\s*أكبر|لا\s*حول\s*ولا\s*قوة\s*الا\s*بالله|صلى\s*الله\s*عليه\s*وسلم|عليه\s*الصلاة\s*والسلام|اللهم\s*صل\s*وسلم\s*على\s*نبينا\s*محمد|جزاك\s*الله\s*خيرا?|جزاكم\s*الله\s*خيرا?|بارك\s*الله\s*فيك|بارك\s*الله\s*فيكم|وفيك\s*بارك|حياك\s*الله|حياكم\s*الله|الله\s*يحفظك|الله\s*يحفظكم|الله\s*يسعدك|الله\s*يبارك\s*فيك|الله\s*يرحمك|الله\s*يعافيك|يعطيك\s*العافية|بالتوفيق|موفق|موفقين|السلام\s*عليكم(?:\s*ورحمة\s*الله(?:\s*وبركاته)?)?|وعليكم\s*السلام(?:\s*ورحمة\s*الله(?:\s*وبركاته)?)?|صباح\s*الخير|صباح\s*النور|مساء\s*الخير|مساء\s*النور|اهلا|أهلا|أهلاً|هلا|هلا\s*والله|مرحبا|مرحبًا|كيف\s*الحال|كيفك|شخبارك|بخير|الحمد\s*لله\s*بخير|ان\s*شاء\s*الله|إن\s*شاء\s*الله|باذن\s*الله|بإذن\s*الله)$/i;

    // أسباب الهلوسة المتناقضة ذاتياً فقط (بدون رفض الأسباب غير العربية حتى لا تُحذف بلاغات النماذج المفتوحة أو OpenAI)
    var HALLUCINATED_REASON_RE = /does\s+not\s+(?:directly\s+)?violate|no\s+(?:direct\s+|clear\s+)?violation|not\s+a\s+(?:direct\s+|clear\s+)?violation|is\s+considered\s+vague|can\s+be\s+associated\s+with|could\s+be\s+associated\s+with|might\s+be\s+associated\s+with|may\s+be\s+associated\s+with|potentially\s+associated|vague\s+and\s+can\s+be|reference\s+to\s+lock\s+in|indirect\s+reference|vague\s+reference|without\s+explicit|no\s+explicit|not\s+explicitly|appears\s+harmless|seems\s+harmless|benign\s+message|normal\s+message|لا\s*تخالف(?:\s*بشكل\s*مباشر)?|لا\s*تحتوي\s*على\s*مخالفة|ليست\s*مخالفة|غامضة\s*ويمكن\s*ربطها|يمكن\s*ربطها\s*بـ|قد\s*ترتبط\s*بـ|إشارة\s*غير\s*مباشرة|لا\s*يوجد\s*انتهاك/i;

    function isHallucinatedOrWeakReason(rawReason) {
        var r = String(rawReason || "").trim();
        if (!r) return false;
        var base = r.split("— [اقتباس مؤكد:")[0].split("• [تأكيد مزدوج")[0].trim();
        if (base && HALLUCINATED_REASON_RE.test(base)) return true;
        return false;
    }

    function isFakeOrHallucinatedFinding(f) {
        if (!f || typeof f !== "object") return true;
        if (f.cat === "blocked") return false;
        if (isHallucinatedOrWeakReason(f.reason)) return true;
        if (f.snippet && isObviouslyBenignText(f.snippet)) return true;
        return false;
    }

    function stripReplyContextFromPromptText(s) {
        if (!s || typeof s !== "string") return "";
        return s.replace(/\n?\[سياق الرد:\s*"[\s\S]*?"\]\s*$/g, "").trim();
    }

    function isObviouslyBenignText(text) {
        if (!text || typeof text !== "string") return true;
        var t = stripReplyContextFromPromptText(text);
        if (!t) return true;
        if (t.length > 55) return false;
        if (/https?:\/\/|discord\.gg\/|t\.me\/|www\.|\.com\b|\.net\b|\.org\b/i.test(t)) return false;
        var stripped = t
            .replace(/<a?:[a-zA-Z0-9_]+:\d+>/g, " ")
            .replace(/[\u200B-\u200D\uFEFF\u0640]/g, "")
            .replace(/[\u064B-\u065F\u0670]/g, "")
            .trim();
        if (!stripped) return true;
        if (SUSPICIOUS_HINT_RE.test(stripped)) return false;
        var lettersOnly = stripped.replace(/[^a-zA-Z\u0600-\u06FF]/g, "");
        if (!lettersOnly) {
            var digits = stripped.replace(/\D/g, "");
            return digits.length <= 5;
        }
        if (lettersOnly.length <= 2 && stripped.length <= 6) return true;
        var cleanPhrase = stripped
            .replace(/[^\w\s\u0600-\u06FF]/g, " ")
            .replace(/\s+/g, " ")
            .trim();
        if (cleanPhrase && BENIGN_SHORT_RE.test(cleanPhrase)) return true;
        return false;
    }

    function normalizeForQuoteMatch(s) {
        return String(s || "")
            .toLowerCase()
            .replace(/[\u064B-\u065F\u0670\u0640\u200B-\u200D\uFEFF]/g, "")
            .replace(/[أإآٱ]/g, "ا")
            .replace(/ة/g, "ه")
            .replace(/ى/g, "ي")
            .replace(/ؤ/g, "و")
            .replace(/ئ/g, "ي")
            .replace(/[^\w\u0600-\u06FF]+/g, " ")
            .replace(/\s+/g, " ")
            .trim();
    }

    function doesTextMatchQuote(msgText, quoteText) {
        var mainMsg = stripReplyContextFromPromptText(msgText);
        var nm = normalizeForQuoteMatch(mainMsg);
        var nq = normalizeForQuoteMatch(quoteText);
        if (!nm || !nq || nq.length < 3) return false;
        if (nm.indexOf(nq) !== -1) return true;
        var tokens = nq.split(" ").filter(function (w) { return w.length >= 3; });
        if (tokens.length === 0) return nm.indexOf(nq) !== -1;
        var hitCount = 0;
        for (var i = 0; i < tokens.length; i++) {
            if (nm.indexOf(tokens[i]) !== -1) hitCount++;
        }
        return (hitCount / tokens.length) >= 0.65;
    }

    function verifyAndResolveFlagIndex(texts, reportedIdx, quote) {
        var count = Array.isArray(texts) ? texts.length : 0;
        if (!(reportedIdx >= 0 && reportedIdx < count)) return null;
        if (!Array.isArray(texts) || texts.length === 0 || typeof texts[reportedIdx] !== "string") {
            return { index: reportedIdx, quoteVerified: false, corrected: false };
        }
        // حماية ضد الهلوسة على التحيات/الإيموجي البديهية فقط (دون فرض SUSPICIOUS_HINT_RE على الرسائل القصيرة)
        if (isObviouslyBenignText(texts[reportedIdx])) {
            if (quote && String(quote).trim().length >= 4) {
                for (var j = 0; j < count; j++) {
                    if (j !== reportedIdx && !isObviouslyBenignText(texts[j]) && doesTextMatchQuote(texts[j], quote)) {
                        return { index: j, quoteVerified: true, corrected: true };
                    }
                }
            }
            return null;
        }
        var q = String(quote || "").trim();
        if (!q || q.length < 3) {
            return { index: reportedIdx, quoteVerified: false, corrected: false };
        }
        if (doesTextMatchQuote(texts[reportedIdx], q)) {
            return { index: reportedIdx, quoteVerified: true, corrected: false };
        }
        // إذا لم يطابق النص الأساسي للرسالة رقم reportedIdx، نبحث في بقية رسائل الدفعة لتصحيح انزلاق الرقم
        var nq = normalizeForQuoteMatch(q);
        if (nq.length >= 4) {
            for (var m = 0; m < count; m++) {
                if (m === reportedIdx || isObviouslyBenignText(texts[m])) continue;
                var nm = normalizeForQuoteMatch(stripReplyContextFromPromptText(texts[m]));
                if (nm && (nm.indexOf(nq) !== -1 || doesTextMatchQuote(texts[m], q))) {
                    return { index: m, quoteVerified: true, corrected: true };
                }
            }
        }
        if (cfg.strictQuoteVerify && nq.length >= 6) {
            return null;
        }
        return { index: reportedIdx, quoteVerified: false, corrected: false };
    }

    var CLASSIFY_SERVER_BAN_SYSTEM =
        "Role: Automated Discord message classifier. Fast, direct check only. Minimize token usage.\n\n" +
        "Filter categories:\n" +
        "- Violent extremism & terrorism promotion (ISIS, Al-Qaeda, explosives)\n" +
        "- CSAM & child sexual exploitation\n" +
        "- Real-world violence threats & gore\n" +
        "- Illicit trade: weapons, drugs, stolen cards, malware\n" +
        "- Severe profanity, curse words, explicit insults & harassment\n" +
        "- Hate speech & incitement against protected groups\n" +
        "- Explicit pornography\n" +
        "(Do NOT flag: self-harm, doxxing, benign chat, gaming slang, or refutations of extremism)\n\n" +
        "Output format rules:\n" +
        "- Return raw JSON ONLY. No markdown, no intro, no outro, no explanations.\n" +
        "- If no violations found, output strictly: []\n" +
        "- If violations exist, output ONLY message ID and a 2-word category label:\n" +
        "[{\"id\": \"123\", \"reason\": \"Severe harassment\"}]";

    var CLASSIFY_ALL_SYSTEM =
        "Role: Automated Discord message classifier. Fast, direct check only. Minimize token usage.\n\n" +
        "Filter categories:\n" +
        "- Inappropriate language: severe profanity, explicit insults, cursing, harassment\n" +
        "- Spam links: phishing, fraudulent links, fake nitro scams\n" +
        "- CSAM & child sexual exploitation\n" +
        "- Violent extremism & terrorism promotion (ISIS, Al-Qaeda)\n" +
        "- Real-world violence threats & gore\n" +
        "- Illicit trade: weapons, drugs, stolen credentials/cards\n" +
        "- Hate speech & harassment against protected groups\n" +
        "- Explicit pornography\n" +
        "(Do NOT flag: self-harm, doxxing, benign chat, ordinary slang, or refutations of extremism)\n\n" +
        "Output format rules:\n" +
        "- Return raw JSON ONLY. No markdown, no intro, no outro, no explanations.\n" +
        "- If no violations found, output strictly: []\n" +
        "- If violations exist, output ONLY message ID and a 2-word category label:\n" +
        "[{\"id\": \"123\", \"reason\": \"Spam link\"}]";

    function getActiveSystemPrompt() {
        return cfg.auditMode === "server_ban" ? CLASSIFY_SERVER_BAN_SYSTEM : CLASSIFY_ALL_SYSTEM;
    }

    function buildUserPrompt(texts) {
        var listing = texts.map(function (t, i) {
            var idVal = (typeof t === "object" && t && (t.messageId || t.id)) ? (t.messageId || t.id) : i;
            var textVal = (typeof t === "object" && t) ? (t.promptText || t.text) : t;
            return "[#" + i + "] (id: " + idVal + ") " + JSON.stringify(textVal);
        }).join("\n");
        return "Input messages:\n" + listing;
    }

    function tryExtractJson(text) {
        if (!text || typeof text !== "string") return null;
        try { return JSON.parse(text.trim()); } catch (e) {}
        for (var end = text.lastIndexOf("}"); end !== -1; end = text.lastIndexOf("}", end - 1)) {
            var depth = 0;
            var inStr = false;
            var esc = false;
            for (var pos = end; pos >= 0; pos--) {
                var ch = text.charAt(pos);
                if (esc) { esc = false; continue; }
                if (ch === "\\" && inStr) { esc = true; continue; }
                if (ch === "\"") { inStr = !inStr; continue; }
                if (inStr) continue;
                if (ch === "}") depth++;
                else if (ch === "{") {
                    depth--;
                    if (depth === 0) {
                        var candidate = text.slice(pos, end + 1);
                        try {
                            var obj = JSON.parse(candidate);
                            if (obj && (Array.isArray(obj.flags) || Array.isArray(obj.results))) return obj;
                        } catch (e2) {}
                        break;
                    }
                }
            }
        }
        var arrMatch = text.match(/\[[\s\S]*\]/);
        if (arrMatch) { try { return JSON.parse(arrMatch[0]); } catch (e3) {} }
        return null;
    }

    function getEffectiveMinScore(severeOnly, isTopPriority) {
        var th = Number(cfg.threshold);
        if (!(th >= 0.1 && th <= 0.99)) th = 0.5;
        if (severeOnly) {
            // احترام إعداد الحساسية الذي يختاره المستخدم: حساس جداً (0.3 -> 0.45)، متوازن (0.5 -> 0.65)، الواضح فقط (0.8 -> 0.82)
            var base = th <= 0.35 ? 0.45 : (th <= 0.55 ? 0.65 : 0.82);
            return isTopPriority ? Math.max(0.40, base - 0.05) : base;
        }
        return isTopPriority ? Math.min(th, 0.35) : th;
    }

    function parseAiFlags(rawText, textsOrCount, sourceLabel) {
        var texts = Array.isArray(textsOrCount) ? textsOrCount : [];
        var count = Array.isArray(textsOrCount) ? textsOrCount.length : (Number(textsOrCount) || 0);
        var out = [];
        for (var k = 0; k < count; k++) out.push([]);
        if (!rawText || typeof rawText !== "string" || !rawText.trim()) {
            var emptyErr = new Error("upstream: استجابة فارغة أو غير صالحة من " + sourceLabel + " (لم تُحسب الدفعة نظيفة)");
            emptyErr.parseFail = true;
            throw emptyErr;
        }

        var cleaned = rawText
            .replace(/<think>[\s\S]*?<\/think>/gi, "")
            .replace(/```(?:json)?/gi, "")
            .replace(/```/g, "")
            .trim();

        var parsed = tryExtractJson(cleaned);

        var validShape = Array.isArray(parsed) || (parsed && (Array.isArray(parsed.flags) || Array.isArray(parsed.results)));
        if (!validShape) {
            var pErr = new Error("upstream: استجابة غير مفهومة من " + sourceLabel + " (لم تُحسب الدفعة نظيفة)");
            pErr.parseFail = true;
            throw pErr;
        }

        var arr = Array.isArray(parsed)
            ? parsed
            : (parsed && Array.isArray(parsed.flags) ? parsed.flags : (parsed && Array.isArray(parsed.results) ? parsed.results : []));

        var severeOnly = cfg.auditMode === "server_ban";

        for (var a = 0; a < arr.length; a++) {
            var it = arr[a] || {};
            var rawIdStr = it.id !== undefined ? String(it.id).trim() : (it.i !== undefined ? String(it.i).trim() : "");
            var idx = -1;

            if (/^\d+$/.test(rawIdStr)) {
                var asNum = parseInt(rawIdStr, 10);
                if (asNum >= 0 && asNum < count) {
                    idx = asNum;
                }
            }

            if (idx === -1 && rawIdStr) {
                for (var ti = 0; ti < count; ti++) {
                    var item = texts[ti];
                    if (typeof item === "object" && item) {
                        if (String(item.id || item.messageId || "") === rawIdStr) {
                            idx = ti;
                            break;
                        }
                    } else if (typeof item === "string") {
                        if (item.indexOf("(id: " + rawIdStr + ")") !== -1 ||
                            item.indexOf('"id":"' + rawIdStr + '"') !== -1 ||
                            item.indexOf("id: " + rawIdStr) !== -1) {
                            idx = ti;
                            break;
                        }
                    }
                }
            }

            if (idx === -1 && rawIdStr) {
                var hashMatch = rawIdStr.match(/#(\d+)/);
                if (hashMatch) {
                    var hNum = parseInt(hashMatch[1], 10);
                    if (hNum >= 0 && hNum < count) idx = hNum;
                }
            }

            if (!(idx >= 0 && idx < count)) continue;

            var rawReason = it.reason ? String(it.reason).trim() : "";
            if (isHallucinatedOrWeakReason(rawReason)) {
                state.hallucinationsBlocked = (state.hallucinationsBlocked || 0) + 1;
                addDiagLog({ provider: sourceLabel, model: "", ms: 0, count: 1, ok: false, detail: "حجب سبب متناقض ذاتياً من النموذج (#" + idx + ")" });
                continue;
            }

            var quoteStr = it.quote ? String(it.quote).trim() : "";
            var resolved = null;
            if (quoteStr) {
                resolved = verifyAndResolveFlagIndex(texts, idx, quoteStr);
                if (!resolved) {
                    state.hallucinationsBlocked = (state.hallucinationsBlocked || 0) + 1;
                    addDiagLog({ provider: sourceLabel, model: "", ms: 0, count: 1, ok: false, detail: "حجب اقتباس غير مطابق في رسالة #" + idx });
                    continue;
                }
            } else {
                resolved = { index: idx, quoteVerified: false, corrected: false };
            }
            var targetIdx = resolved.index;

            var sc = Number(it.score);
            if (!(sc >= 0)) sc = 0.95;

            var cats = Array.isArray(it.cats) ? it.cats.slice() : (it.cat ? [it.cat] : []);
            if (cats.length === 0 && rawReason) {
                var rLow = rawReason.toLowerCase();
                if (/spam|scam|phish|link|nitro|احتيال|تصيد|سبام|روابط/i.test(rLow)) cats.push("scam");
                else if (/terror|extrem|isis|daesh|qaeda|ارهاب|إرهاب|داعش|خوارج/i.test(rLow)) cats.push("terrorism");
                else if (/minor|child|csam|groom|أطفال|اطفال|قاصر/i.test(rLow)) cats.push("sexual/minors");
                else if (/violen|threat|kill|gore|قتل|عنف|تهديد|ذبح/i.test(rLow)) cats.push("violence");
                else if (/illicit|drug|weapon|stolen|card|سلاح|مخدر|سرقة|اختراق/i.test(rLow)) cats.push("illicit");
                else if (/hate|racis|كراهية|عنصرية/i.test(rLow)) cats.push("hate");
                else if (/sex|porn|nude|إباح|اباح/i.test(rLow)) cats.push("sexual");
                else if (/harass|insult|profan|curse|language|قذف|سب|شتم|لعن|بذاءة|أعراض|اعراض/i.test(rLow)) cats.push("harassment");
                else cats.push(severeOnly ? "harassment" : "scam");
            }

            for (var c = 0; c < cats.length; c++) {
                var catId = String(cats[c] || "").trim().toLowerCase();
                if (catId === "self-harm" || catId === "doxxing") continue;
                var catObj = CATS[catId];
                if (!catObj) continue;
                if (severeOnly && !catObj.banRisk) continue;
                var isTopPriority = catId === "sexual/minors" || catId === "terrorism";
                var minLimit = getEffectiveMinScore(severeOnly, isTopPriority);
                if (sc < minLimit) continue;
                var rsn = rawReason || (sourceLabel + ": " + catObj.label);
                if (resolved.quoteVerified && quoteStr) {
                    rsn += " — [اقتباس مؤكد: «" + quoteStr.slice(0, 90) + "»]";
                }
                out[targetIdx].push({
                    cat: catId,
                    score: sc,
                    quote: quoteStr,
                    quoteVerified: !!resolved.quoteVerified,
                    indexCorrected: !!resolved.corrected,
                    reason: rsn
                });
            }
        }
        return out;
    }

    function makeHttpError(status, message, headersObj) {
        var err = new Error(message || ("HTTP " + status));
        err.status = status;
        try {
            if (headersObj && typeof headersObj.get === "function") {
                var ra = headersObj.get("retry-after");
                if (ra) {
                    var sec = parseFloat(ra);
                    if (!isNaN(sec) && sec > 0) err.retryAfterSec = sec;
                }
            }
        } catch (e) {}
        return err;
    }

    function fetchWithTimeout(url, options, timeoutMs) {
        var ms = timeoutMs || 22000;
        var ctrl = (typeof AbortController !== "undefined") ? new AbortController() : null;
        var opts = Object.assign({}, options || {});
        if (ctrl) opts.signal = ctrl.signal;
        return new Promise(function (resolve, reject) {
            var done = false;
            var timer = setTimeout(function () {
                if (done) return;
                done = true;
                try { if (ctrl) ctrl.abort(); } catch (e) {}
                reject(new Error("timeout after " + Math.round(ms / 1000) + "s"));
            }, ms);
            fetch(url, opts).then(function (r) {
                if (done) return;
                clearTimeout(timer);
                done = true;
                resolve(r);
            }, function (err) {
                if (done) return;
                clearTimeout(timer);
                done = true;
                reject(err);
            });
        });
    }

    function openaiModerate(texts, apiKeyOverride) {
        var key = String(apiKeyOverride !== undefined ? apiKeyOverride : (getProviderKeys("openai")[0] || "")).trim();
        if (!key) return Promise.reject(makeHttpError(401, "مفتاح OpenAI غير محفوظ"));
        if (texts.length > 30) {
            return openaiModerate(texts.slice(0, 30), key).then(function (first) {
                return openaiModerate(texts.slice(30), key).then(function (rest) {
                    return first.concat(rest);
                });
            });
        }
        return fetchWithTimeout("https://api.openai.com/v1/moderations", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + key
            },
            body: JSON.stringify({ model: "omni-moderation-latest", input: texts })
        }, 20000).then(function (r) {
            return r.text().then(function (raw) {
                var j = null;
                try { j = JSON.parse(raw); } catch (e) {}
                if (!r.ok) throw makeHttpError(r.status, (j && j.error && j.error.message) || ("HTTP " + r.status), r.headers);
                return j || {};
            });
        }).then(function (j) {
            var out = [];
            var results = (j && j.results) || [];
            var severeOnly = cfg.auditMode === "server_ban";
            for (var i = 0; i < texts.length; i++) {
                var res = results[i] || {};
                var scores = res.category_scores || {};
                var flags = res.categories || {};
                var hits = [];
                var seen = {};
                for (var k in OPENAI_MAP) {
                    if (!Object.prototype.hasOwnProperty.call(OPENAI_MAP, k)) continue;
                    var our = OPENAI_MAP[k];
                    if (severeOnly && !(CATS[our] && CATS[our].banRisk)) continue;
                    var s = Number(scores[k] || 0);
                    var limit = k === "sexual/minors" ? Math.min(cfg.threshold, 0.3) : (severeOnly ? Math.max(cfg.threshold, 0.7) : cfg.threshold);
                    if (flags[k] === true || s >= limit) {
                        var catLabel = (CATS[our] && CATS[our].label) || k;
                        if (!seen[our] || seen[our].score < s) {
                            seen[our] = { cat: our, score: s, reason: "رصد OpenAI: " + catLabel + " (" + Math.round(s * 100) + "%)" };
                        }
                    }
                }
                for (var c in seen) if (Object.prototype.hasOwnProperty.call(seen, c)) hits.push(seen[c]);
                out.push(hits);
            }
            return out;
        });
    }

    function geminiModerate(texts, apiKeyOverride, modelOverride) {
        var key = String(apiKeyOverride !== undefined ? apiKeyOverride : (getProviderKeys("gemini")[0] || "")).trim();
        var model = String(modelOverride !== undefined ? modelOverride : (getProviderModels("gemini")[0] || "gemma-4-26b-a4b-it")).trim();
        if (!key) return Promise.reject(makeHttpError(401, "مفتاح Gemini غير محفوظ"));
        var url = "https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(model) + ":generateContent";
        var isGemma = /^gemma/i.test(model);
        var sysText = getActiveSystemPrompt();
        var usrText = buildUserPrompt(texts);
        var reqBody = {
            contents: [{ role: "user", parts: [{ text: isGemma ? (sysText + "\n\n" + usrText) : usrText }] }],
            generationConfig: isGemma ? { temperature: 0 } : { temperature: 0, responseMimeType: "application/json" },
            safetySettings: [
                { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
                { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
                { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
                { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
            ]
        };
        if (!isGemma) {
            reqBody.systemInstruction = { parts: [{ text: sysText }] };
        }
        return fetchWithTimeout(url, {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-goog-api-key": key },
            body: JSON.stringify(reqBody)
        }, texts.length >= 100 ? 65000 : (texts.length >= 30 ? 35000 : 22000)).then(function (r) {
            return r.text().then(function (raw) {
                var j = null;
                try { j = JSON.parse(raw); } catch (e) {}
                if (!r.ok) throw makeHttpError(r.status, (j && j.error && j.error.message) || ("HTTP " + r.status), r.headers);
                return j || {};
            });
        }).then(function (j) {
            var blocked = (j && j.promptFeedback && j.promptFeedback.blockReason) ||
                (j && j.candidates && j.candidates[0] && (j.candidates[0].finishReason === "SAFETY" || j.candidates[0].finishReason === "PROHIBITED_CONTENT") && j.candidates[0].finishReason);
            if (blocked) {
                var err = new Error("BLOCKED");
                err.blocked = String(blocked);
                throw err;
            }
            var txt = "";
            try {
                var parts = j.candidates[0].content.parts || [];
                var nonThought = parts.filter(function (p) { return p && !p.thought && p.text; });
                txt = (nonThought.length ? nonThought : parts).map(function (p) { return p.text || ""; }).join("");
            } catch (e) {}
            return parseAiFlags(txt, texts, "Gemini (" + model + ")");
        });
    }

    function openaiCompatModerate(providerId, texts, apiKeyOverride, modelOverride) {
        var p = PROVIDERS[providerId];
        var endpoint = p.urlProp ? normalizeChatEndpoint(cfg[p.urlProp]) : p.endpoint;
        var apiKey = String(apiKeyOverride !== undefined ? apiKeyOverride : (getProviderKeys(providerId)[0] || "")).trim();
        var model = String(modelOverride !== undefined ? modelOverride : (getProviderModels(providerId)[0] || "")).trim();
        if (!endpoint) return Promise.reject(new Error("رابط الـ API فارغ"));
        if (!model) return Promise.reject(new Error("اسم النموذج فارغ"));
        if (!apiKey && !p.keyOptional) return Promise.reject(makeHttpError(401, "مفتاح الـ API غير محفوظ"));

        var headers = { "Content-Type": "application/json" };
        var bearer = apiKey || p.defaultBearer || "";
        if (bearer) headers["Authorization"] = "Bearer " + bearer;
        if (p.sendXApiKey && apiKey) headers["x-api-key"] = apiKey;
        if (p.extraHeaders) {
            for (var hk in p.extraHeaders) {
                if (Object.prototype.hasOwnProperty.call(p.extraHeaders, hk)) headers[hk] = p.extraHeaders[hk];
            }
        }

        var reqBody = {
            model: model,
            temperature: 0,
            messages: [
                { role: "system", content: getActiveSystemPrompt() },
                { role: "user", content: buildUserPrompt(texts) }
            ]
        };
        if (cfg.strictModelLock || cfg.reasoningEffort === "low" || model.indexOf("low") !== -1 || model.indexOf("hydrogen") !== -1) {
            reqBody.reasoning_effort = "low";
            reqBody.thinking = { type: "enabled", budget_tokens: 1024 };
        }

        return fetchWithTimeout(endpoint, {
            method: "POST",
            headers: headers,
            body: JSON.stringify(reqBody)
        }, texts.length >= 100 ? 65000 : (texts.length >= 30 ? 35000 : 22000)).then(function (r) {
            return r.text().then(function (raw) {
                var j = null;
                try { j = JSON.parse(raw); } catch (e) {}
                if (!r.ok || (j && j.ok === false)) {
                    var errCode = (j && j.error && j.error.code) ? ("[" + j.error.code + "] ") : "";
                    var msg = errCode + ((j && j.error && (j.error.message || (typeof j.error === "string" ? j.error : ""))) ||
                        (j && j.message) || ("HTTP " + r.status));
                    var httpErr = makeHttpError(r.status || 400, msg, r.headers);
                    var ra = (j && j.error && j.error.retry_after) || (j && j.retry_after);
                    if (ra) {
                        var raNum = parseFloat(ra);
                        if (!isNaN(raNum) && raNum > 0) httpErr.retryAfterSec = raNum;
                    }
                    throw httpErr;
                }
                if (!j) throw new Error("استجابة غير صالحة من الخادم");
                return j;
            });
        }).then(function (j) {
            var payload = (j && j.ok === true && j.data && typeof j.data === "object") ? j.data : j;
            var ch = payload && payload.choices && payload.choices[0];
            if (ch && ch.finish_reason === "content_filter") {
                var err = new Error("BLOCKED");
                err.blocked = "content_filter";
                throw err;
            }
            var txt = "";
            if (ch && ch.message) {
                if (typeof ch.message.content === "string") txt = ch.message.content;
                else if (Array.isArray(ch.message.content)) {
                    txt = ch.message.content.map(function (part) { return (part && part.text) || ""; }).join("");
                }
            } else if (payload && typeof payload.message === "string") {
                txt = payload.message;
            } else if (payload && payload.message && typeof payload.message.content === "string") {
                txt = payload.message.content;
            }
            if (!txt && ch && ch.message && ch.message.refusal) {
                var rErr = new Error("BLOCKED");
                rErr.blocked = "refusal";
                throw rErr;
            }
            return parseAiFlags(txt, texts, p.sourceName + " (" + model + ")");
        });
    }

    function fetchServerModels(baseUrl, apiKey, defaultBearer) {
        var url = normalizeModelsEndpoint(baseUrl);
        if (!url) return Promise.reject(new Error("رابط الخادم فارغ"));
        var headers = {};
        var bearer = String(apiKey || defaultBearer || "").trim();
        if (bearer) headers["Authorization"] = "Bearer " + bearer;
        if (apiKey) headers["x-api-key"] = String(apiKey).trim();
        return fetch(url, { method: "GET", headers: headers }).then(function (r) {
            return r.text().then(function (raw) {
                var j = null;
                try { j = JSON.parse(raw); } catch (e) {}
                if (!r.ok) throw makeHttpError(r.status, (j && j.error && j.error.message) || ("HTTP " + r.status), r.headers);
                var data = (j && Array.isArray(j.data)) ? j.data : (Array.isArray(j) ? j : []);
                var ids = [];
                for (var i = 0; i < data.length && ids.length < 15; i++) {
                    var id = data[i] && (data[i].id || data[i].name);
                    if (id && ids.indexOf(String(id)) === -1) ids.push(String(id));
                }
                return ids;
            });
        });
    }

    function runProviderModerate(providerId, texts, apiKeyOverride, modelOverride) {
        if (providerId === "openai") return openaiModerate(texts, apiKeyOverride);
        if (providerId === "gemini") return geminiModerate(texts, apiKeyOverride, modelOverride);
        return openaiCompatModerate(providerId, texts, apiKeyOverride, modelOverride);
    }

    // ===================== التبديل التلقائي بين المفاتيح والمزوّدات =====================
    var keyHealth = {};          // keyId -> { cooldownUntil, kind, reason, lastOk }
    var slotHealth = {};         // keyId + "::" + model -> { cooldownUntil, kind, reason }
    var providerKeyCursor = {};  // providerId -> next preferred key index
    var lastUsedProvider = "";
    var lastUsedKeyId = "";

    function makeKeyId(pid, key) {
        return pid + "::" + (key || "NOKEY");
    }

    function resetAllKeyCooldowns() {
        keyHealth = {};
        slotHealth = {};
        providerKeyCursor = {};
        state.lastError = "";
        emitState();
    }

    function getKeyBadgeInfo(pid, key) {
        var kid = makeKeyId(pid, key);
        var info = keyHealth[kid];
        var now = Date.now();
        if (!info) {
            return { text: "جاهز", color: "#949BA4", cooling: false };
        }
        if (info.cooldownUntil && info.cooldownUntil > now) {
            var sec = Math.ceil((info.cooldownUntil - now) / 1000);
            var minTxt = sec >= 90 ? (Math.ceil(sec / 60) + " د") : (sec + " ث");
            if (info.kind === "auth") return { text: "❌ مفتاح غير صالح (" + minTxt + ")", color: "#F23F43", cooling: true };
            if (info.kind === "quota") return { text: "⏳ انتهت الحصة (" + minTxt + ")", color: "#F0B232", cooling: true };
            if (info.kind === "net") return { text: "🔌 الخادم غير متصل (" + minTxt + ")", color: "#F0B232", cooling: true };
            return { text: "⏳ ضغط مؤقت (" + minTxt + ")", color: "#F0B232", cooling: true };
        }
        if (lastUsedKeyId === kid) return { text: "⚡ نشط ويعمل", color: "#23A55A", cooling: false };
        if (info.lastOk) return { text: "✅ يعمل", color: "#23A55A", cooling: false };
        return { text: "جاهز", color: "#949BA4", cooling: false };
    }

    var globalSlotOffset = 0;

    function classifyApiError(err) {
        var status = Number(err && err.status) || 0;
        var msg = String((err && err.message) || err || "");
        var low = msg.toLowerCase();

        if (err && err.parseFail) {
            return { rotate: true, scope: "slot", kind: "parse", cooldownMs: 20000 };
        }

        // مفتاح غير صالح / منتهي / غير مصرح (شامل INVALID_API_KEY و REVOKED_API_KEY من YepAPI)
        if (status === 401 || status === 403 || /invalid_api_key|revoked_api_key|invalid.*api.?key|incorrect.*api.?key|unauthorized|api.?key.*not.?valid|revoked|expired|authentication/.test(low)) {
            return { rotate: true, scope: "key", kind: "auth", cooldownMs: 60 * 60 * 1000 };
        }
        // نموذج مدفوع غير متاح على الخطة المجانية (مثل CoArena gemini-4-argon) -> تخطي النموذج فقط دون إيقاف المفتاح
        if (/not part of the free tier|free accounts can use|not available on your plan|requires.*tier/.test(low)) {
            return { rotate: true, scope: "slot", kind: "model", cooldownMs: 30 * 60 * 1000 };
        }
        // نفاد الرصيد أو الحصة اليومية (شامل NO_CREDITS من YepAPI و 402 / quota / credits)
        if (status === 402 || /no_credits|insufficient.*credit|out of credit|quota|resource_exhausted|exceeded.*quota|daily.*limit|rpd|tpd|spend.*limit|billing|balance|payment required|free.*limit|limit.*reached|requires a paid balance/.test(low)) {
            var qMs = (err && err.retryAfterSec) ? Math.max(120000, Math.min(3600000, err.retryAfterSec * 1000)) : (15 * 60 * 1000);
            return { rotate: true, scope: "key", kind: "quota", cooldownMs: qMs };
        }
        // قاطع الدائرة الخاص بمزود الخدمة في OmniRoute (circuit breaker open)
        if (/circuit_open|circuit.?breaker|قاطع الدائرة/.test(low)) {
            var cMs = (err && err.retryAfterSec) ? Math.max(30000, Math.min(600000, err.retryAfterSec * 1000)) : 120000;
            return { rotate: true, scope: "circuit", kind: "circuit", cooldownMs: cMs };
        }
        // النموذج غير متوفر أو مزدحم أو انتهت حصة النموذج وحده في OmniRoute / YepAPI
        if (status === 400 || status === 404 || status === 502 || status === 503 || status === 529 ||
            /upstream_error|upstream_timeout|request_timeout|overloaded|temporarily unavailable|no endpoints|model.*not found|not available in the active|ambiguous model|unable to determine provider|skipped by pre-dispatch|model_cooldown|cooling down|exhausted their quota|capacity|upstream/.test(low)) {
            return { rotate: true, scope: "slot", kind: "model", cooldownMs: 90000 };
        }
        // حد سرعة مؤقت (429 / RATE_LIMITED_UPSTREAM / RPM / TPM)
        if (status === 429 || /rate_limited_upstream|rate.?limit|too many requests|requests per min|tokens per min|rpm|tpm|try again/.test(low)) {
            var rMs = (err && err.retryAfterSec) ? Math.max(30000, Math.min(300000, err.retryAfterSec * 1000)) : 70000;
            return { rotate: true, scope: "key", kind: "rate", cooldownMs: rMs };
        }
        // خطأ اتصال / خادم محلي غير شغّال / انتهاء المهلة
        if (status === 0 && /network request failed|failed to fetch|econnrefused|connection refused|timeout|aborted/.test(low)) {
            return { rotate: true, scope: "slot", kind: "net", cooldownMs: 60000 };
        }
        return { rotate: false, scope: "slot", kind: "err", cooldownMs: 0 };
    }

    function buildCandidateSlots() {
        var order = [];
        if (cfg.omnirouteOnly) {
            if (isProviderReady("omniroute", false)) {
                order.push("omniroute");
            }
        } else {
            if (cfg.provider && cfg.provider !== "local" && isProviderReady(cfg.provider, false)) {
                order.push(cfg.provider);
            }
            if (cfg.autoFailoverProviders) {
                for (var i = 0; i < PROVIDER_ORDER.length; i++) {
                    var pid = PROVIDER_ORDER[i];
                    if (pid !== "local" && pid !== cfg.provider && isProviderReady(pid, true)) {
                        order.push(pid);
                    }
                }
            }
        }
        var perProvider = [];
        var maxLen = 0;
        for (var p = 0; p < order.length; p++) {
            var id = order[p];
            var pInfo = PROVIDERS[id];
            var keys = getProviderKeys(id);
            if (keys.length === 0 && pInfo.keyOptional) keys = [""];
            var models = getProviderModels(id);
            var startCursor = (providerKeyCursor[id] || 0) % Math.max(1, keys.length);
            var pSlots = [];
            for (var kOff = 0; kOff < keys.length; kOff++) {
                var kIdx = (startCursor + kOff) % keys.length;
                for (var mIdx = 0; mIdx < models.length; mIdx++) {
                    pSlots.push({
                        providerId: id,
                        sourceName: pInfo.sourceName,
                        keyIdx: kIdx,
                        key: keys[kIdx],
                        keyId: makeKeyId(id, keys[kIdx]),
                        model: models[mIdx],
                        slotId: makeKeyId(id, keys[kIdx]) + "::" + models[mIdx]
                    });
                }
            }
            if (pSlots.length > 0) {
                perProvider.push(pSlots);
                if (pSlots.length > maxLen) maxLen = pSlots.length;
            }
        }
        var slots = [];
        if (!cfg.tieredPipeline && cfg.roundRobinProviders) {
            // توزيع بالتناوب بين المزوّدات والنماذج عند إيقاف نظام الطبقتين فقط
            for (var round = 0; round < maxLen; round++) {
                for (var g = 0; g < perProvider.length; g++) {
                    if (round < perProvider[g].length) slots.push(perProvider[g][round]);
                }
            }
        } else {
            // نظام الطبقتين (Tiered Pipeline): المزوّد الأساسي أولاً للفرز مع Fallback تلقائي عند الفشل
            for (var g2 = 0; g2 < perProvider.length; g2++) {
                for (var s2 = 0; s2 < perProvider[g2].length; s2++) slots.push(perProvider[g2][s2]);
            }
        }
        if (cfg.strictModelLock) {
            slots = slots.filter(function (s) {
                var m = String((s && s.model) || "").toLowerCase();
                var isHydrogen = m.indexOf("gemini-4-hydrogen") !== -1 || m.indexOf("hydrogen") !== -1;
                var isForbidden = /claude|neon|carbon|flash|gpt|qwen|deepseek|llama|grok|nemotron|gemma/.test(m);
                return isHydrogen && !isForbidden;
            });
        }
        return slots;
    }

    function getVerifierStrengthRank(slot) {
        var m = String((slot && slot.model) || "").toLowerCase();
        var score = 50;
        if (/pro-high|2\.5-pro|claude-sonnet|claude-opus|gpt-4o|gpt-6/.test(m)) score = 110;
        else if (/gemini-3-flash|gemini-3\.8-flash-high|gemini-3\.8-flash-medium|gemini-3-8-flash|claude/.test(m)) score = 100;
        else if (/qwen3\.8-27b|gpt-oss-120b|deepseek-v4|gemini-3\.8-flash-low|nemotron.*120b|llama-3\.3-70b/.test(m)) score = 92;
        else if (/gemma-4-31b|gemma-4-26b|gemini-2\.5-flash|gpt-oss-20b|grok-3/.test(m)) score = 84;
        else if (/flash-lite/.test(m)) score = 74;
        if (slot && slot.keyId && keyHealth[slot.keyId] && keyHealth[slot.keyId].lastOk) score += 3;
        return score;
    }

    function getSlotCooldownUntil(slot) {
        var kh = keyHealth[slot.keyId];
        var sh = slotHealth[slot.slotId];
        var t1 = (kh && kh.cooldownUntil) || 0;
        var t2 = (sh && sh.cooldownUntil) || 0;
        return Math.max(t1, t2);
    }

    function moderateWithFailover(texts, excludeSlotId, forVerification, slotRotateOffset) {
        var allSlots = buildCandidateSlots();
        if (allSlots.length === 0) {
            return Promise.reject(new Error("لا يوجد مفتاح API جاهز لأي مزوّد"));
        }

        var now = Date.now();
        var ready = [];
        var soonestWaitMs = Infinity;
        for (var i = 0; i < allSlots.length; i++) {
            var until = getSlotCooldownUntil(allSlots[i]);
            if (until <= now) {
                ready.push(allSlots[i]);
            } else {
                var rem = until - now;
                if (rem < soonestWaitMs) soonestWaitMs = rem;
            }
        }

        if (ready.length === 0) {
            var waitErr = new Error("كل المفاتيح في استراحة مؤقتة");
            waitErr.allCooldown = true;
            waitErr.waitMs = Math.max(10000, Math.min(60000, isFinite(soonestWaitMs) ? soonestWaitMs : 25000));
            return Promise.reject(waitErr);
        }

        if (forVerification && cfg.tieredPipeline && ready.length > 1) {
            // الطبقة الثانية (التأكيد المزدوج): ترتيب النماذج المتاحة حسب القوة والاستقرار مع تفضيل نموذج مختلف عن الأول
            ready = ready.slice().sort(function (a, b) {
                var aDiff = (excludeSlotId && a.slotId === excludeSlotId) ? 0 : 1;
                var bDiff = (excludeSlotId && b.slotId === excludeSlotId) ? 0 : 1;
                if (aDiff !== bDiff) return bDiff - aDiff;
                return getVerifierStrengthRank(b) - getVerifierStrengthRank(a);
            });
        } else {
            if (!cfg.tieredPipeline && cfg.roundRobinProviders && ready.length > 1) {
                var rot = globalSlotOffset % ready.length;
                globalSlotOffset = (globalSlotOffset + 1) % ready.length;
                if (rot > 0) ready = ready.slice(rot).concat(ready.slice(0, rot));
            } else if (typeof slotRotateOffset === "number" && slotRotateOffset > 0 && ready.length > 1) {
                // في وضع الطبقتين نوزّع التوازي على أقوى النماذج المتاحة أولاً (ولا ننزل للنماذج الأقل إلا عند انتهاء الحصة أو الفشل)
                var topTierSpan = Math.min(ready.length, cfg.tieredPipeline ? 4 : ready.length);
                var pRot = slotRotateOffset % topTierSpan;
                if (pRot > 0) ready = ready.slice(pRot, topTierSpan).concat(ready.slice(0, pRot)).concat(ready.slice(topTierSpan));
            }
            if (excludeSlotId && ready.length > 1) {
                var diffSlots = [];
                var sameSlots = [];
                for (var es = 0; es < ready.length; es++) {
                    if (ready[es].slotId !== excludeSlotId) diffSlots.push(ready[es]);
                    else sameSlots.push(ready[es]);
                }
                if (diffSlots.length > 0) ready = diffSlots.concat(sameSlots);
            }
        }

        var idx = 0;
        var lastErr = null;

        function tryNext() {
            if (idx >= ready.length) {
                var now2 = Date.now();
                var minRem = Infinity;
                var anyCooling = false;
                for (var j = 0; j < allSlots.length; j++) {
                    var u2 = getSlotCooldownUntil(allSlots[j]);
                    if (u2 > now2) {
                        anyCooling = true;
                        if ((u2 - now2) < minRem) minRem = u2 - now2;
                    }
                }
                if (anyCooling) {
                    var ce = new Error((lastErr && lastErr.message) || "انتهت حصة كل المفاتيح مؤقتاً");
                    ce.allCooldown = true;
                    ce.waitMs = Math.max(10000, Math.min(60000, isFinite(minRem) ? minRem : 25000));
                    return Promise.reject(ce);
                }
                return Promise.reject(lastErr || new Error("فشل الاتصال بجميع المفاتيح"));
            }

            var slot = ready[idx++];
            var reqStart = Date.now();
            return runProviderModerate(slot.providerId, texts, slot.key, slot.model).then(function (results) {
                var elapsedMs = Date.now() - reqStart;
                var flagHits = 0;
                if (Array.isArray(results)) {
                    for (var ri = 0; ri < results.length; ri++) {
                        if (results[ri] && results[ri].length > 0) flagHits++;
                    }
                }
                addDiagLog({
                    provider: slot.sourceName,
                    model: slot.model || "auto",
                    ms: elapsedMs,
                    count: texts.length,
                    ok: true,
                    detail: (forVerification ? "[تأكيد مزدوج] " : "[فرز] ") + (flagHits ? ("رصد " + flagHits + " مخالفة") : "سليم")
                });
                keyHealth[slot.keyId] = { cooldownUntil: 0, kind: "ok", reason: "", lastOk: Date.now() };
                delete slotHealth[slot.slotId];
                providerKeyCursor[slot.providerId] = slot.keyIdx;
                lastUsedProvider = slot.providerId;
                lastUsedKeyId = slot.keyId;
                state.activeRoute = slot.sourceName + " (" + (slot.model || "auto") + " • " + (slot.key ? ("مفتاح #" + (slot.keyIdx + 1)) : "مجاني") + ")";
                emitState();
                return {
                    results: results,
                    sourceLabel: slot.sourceName + " (" + (slot.model || "auto") + ")",
                    providerId: slot.providerId,
                    keyIdx: slot.keyIdx,
                    model: slot.model,
                    slotId: slot.slotId
                };
            }).catch(function (err) {
                var failMs = Date.now() - reqStart;
                var safeErr = sanitizeErrorMessage((err && err.message) || err);
                addDiagLog({
                    provider: slot.sourceName,
                    model: slot.model || "auto",
                    ms: failMs,
                    count: texts.length,
                    ok: false,
                    detail: safeErr
                });
                if (err && err.blocked) throw err; // الحجب خاص بالنص نفسه وليس بالمفتاح

                // سياسة القفل الصارم وانعدام التبديل (Strict Model Lock & ZERO Fallback Policy)
                if (cfg.strictModelLock) {
                    var isRateLimit = (err && (err.status === 429 || /rate.*limit|quota|too many requests|429/i.test(err.message)));
                    var abortMsg = isRateLimit
                        ? "توقف الفحص: نموذج Gemini 4 Hydrogen (Low) وصل للحد الأقصى (Rate-limit)، وسياسة القفل الصارم تمنع استخدام أي نموذج بديل."
                        : ("توقف الفحص: تعذر الاتصال بنموذج Gemini 4 Hydrogen (Low) [" + safeErr + "]، وسياسة القفل الصارم تمنع التحويل لأي نموذج بديل.");
                    var abortErr = new Error(abortMsg);
                    abortErr.status = (err && err.status) || (isRateLimit ? 429 : 500);
                    abortErr.strictLockAbort = true;
                    state.lastError = abortMsg;
                    emitState();
                    throw abortErr;
                }

                lastErr = err;
                var cl = classifyApiError(err);
                if (slot.providerId === "omniroute" && cl.kind !== "auth") {
                    cl = Object.assign({}, cl, { scope: "slot" });
                }
                var nowFail = Date.now();
                if (cl.rotate) {
                    if (cl.scope === "key") {
                        keyHealth[slot.keyId] = {
                            cooldownUntil: nowFail + cl.cooldownMs,
                            kind: cl.kind,
                            reason: safeErr,
                            lastOk: (keyHealth[slot.keyId] && keyHealth[slot.keyId].lastOk) || 0
                        };
                        var pKeys = getProviderKeys(slot.providerId);
                        if (pKeys.length > 1) {
                            providerKeyCursor[slot.providerId] = (slot.keyIdx + 1) % pKeys.length;
                        }
                    } else if (cl.scope === "circuit") {
                        var mPref = (slot.model && slot.model.indexOf("/") !== -1) ? slot.model.split("/")[0] : "";
                        slotHealth[slot.slotId] = {
                            cooldownUntil: nowFail + cl.cooldownMs,
                            kind: cl.kind,
                            reason: safeErr
                        };
                        for (var allI = 0; allI < allSlots.length; allI++) {
                            var as = allSlots[allI];
                            if (as && as.model && mPref && as.model.indexOf(mPref + "/") === 0) {
                                slotHealth[as.slotId] = {
                                    cooldownUntil: nowFail + cl.cooldownMs,
                                    kind: cl.kind,
                                    reason: safeErr
                                };
                            }
                        }
                    } else {
                        slotHealth[slot.slotId] = {
                            cooldownUntil: nowFail + cl.cooldownMs,
                            kind: cl.kind,
                            reason: safeErr
                        };
                    }
                    state.keyRotations++;
                    state.lastError = slot.sourceName + " (" + (slot.model || "auto") + "): " + safeErr;
                    emitState();
                    if (cl.scope === "key") {
                        while (idx < ready.length && ready[idx].keyId === slot.keyId) idx++;
                    } else if (cl.scope === "circuit") {
                        var mPrefSkip = (slot.model && slot.model.indexOf("/") !== -1) ? slot.model.split("/")[0] : "";
                        while (idx < ready.length && mPrefSkip && ready[idx].model && ready[idx].model.indexOf(mPrefSkip + "/") === 0) idx++;
                    }
                    return tryNext();
                }
                throw err;
            });
        }
        return tryNext();
    }

    // ===================== البحث في الخادم المحدد عن رسائل الإدارة فقط =====================
    var FAST_SEARCH_KEYWORDS = [
        "داعش",
        "الدولة الاسلامية",
        "باقية وتتمدد",
        "البغدادي",
        "القاعدة",
        "بن لادن",
        "الزرقاوي",
        "أبايع",
        "بيعة",
        "استشهادية",
        "انغماسي",
        "حزام ناسف",
        "تفجير",
        "ذبح",
        "نحر",
        "أعماق",
        "الفرقان",
        "ISIS",
        "Daesh",
        "bomb",
        "الخلافة",
        "ولاية سيناء",
        "أنصار الدولة",
        "الذئاب المنفردة",
        "متفجرات",
        "قنبلة",
        "عبوة ناسفة",
        "اقتلوا",
        "الطواغيت",
        "jihad",
        "nasheed",
        "beheading",
        "explosive"
    ];

    function apiGet(url, query) {
        if (!mods.RestAPI || typeof mods.RestAPI.get !== "function") {
            return Promise.reject(new Error("وحدة RestAPI غير متوفرة حالياً"));
        }
        var req = { url: url };
        if (query) req.query = query;
        return Promise.resolve(mods.RestAPI.get(req)).then(function (res) {
            if (res && res.body !== undefined) return { status: res.status || 200, body: res.body };
            return { status: 200, body: res };
        });
    }

    function extractRetryMs(errOrRes) {
        try {
            if (errOrRes && errOrRes.body && typeof errOrRes.body.retry_after === "number") {
                return Math.ceil(errOrRes.body.retry_after * 1000) + 1000;
            }
            if (errOrRes && errOrRes.headers && errOrRes.headers["retry-after"]) {
                var s = parseFloat(errOrRes.headers["retry-after"]);
                if (!isNaN(s)) return Math.ceil(s * 1000) + 1000;
            }
        } catch (e) {}
        return 4500;
    }

    function isTransientSearchError(err) {
        var status = Number(err && err.status) || 0;
        var msg = String((err && (err.message || (err.body && err.body.message))) || err || "").toLowerCase();
        if (status === 401 || status === 403 || status === 404) return false;
        if (status === 429 || status === 202 || status === 0 || status >= 500) return true;
        return /terminated|network|offline|timeout|aborted|fetch|cors|unloaded|reset|socket|econn/.test(msg);
    }

    function searchAdminPage(guildId, authorId, offset, contentQuery, channelId) {
        function attempt(tries) {
            if (stopped || serverSearch.stopRequested) return Promise.resolve({ stopped: true });
            var q = {
                sort_by: "timestamp",
                sort_order: "desc",
                offset: offset || 0
            };
            if (authorId) {
                if (Array.isArray(authorId)) {
                    if (authorId.length === 1) q.author_id = authorId[0];
                    else if (authorId.length > 1) q.author_id = authorId;
                } else {
                    q.author_id = authorId;
                }
            }
            if (channelId) q.channel_id = channelId;
            if (contentQuery) q.content = contentQuery;
            return apiGet("/guilds/" + guildId + "/messages/search", q).then(function (res) {
                if (res && res.status === 202 && tries < 5) {
                    var wait = extractRetryMs(res);
                    serverSearch.status = "ديسكورد يجهّز فهرس البحث… انتظار " + Math.ceil(wait / 1000) + " ث";
                    emitState();
                    return sleep(wait).then(function () { return attempt(tries + 1); });
                }
                var body = (res && res.body) || {};
                var groups = Array.isArray(body.messages) ? body.messages : [];
                var hits = [];
                function matchesTargetAuthor(aId) {
                    if (!authorId) return true;
                    if (Array.isArray(authorId)) return authorId.indexOf(String(aId)) !== -1;
                    return String(aId) === String(authorId);
                }
                function matchesTargetChannel(cId) {
                    if (!channelId) return true;
                    return String(cId || "") === String(channelId);
                }
                for (var i = 0; i < groups.length; i++) {
                    var g = groups[i];
                    if (Array.isArray(g)) {
                        for (var j = 0; j < g.length; j++) {
                            var m = g[j];
                            if (m && m.hit && m.author && matchesTargetAuthor(m.author.id) && matchesTargetChannel(m.channel_id)) {
                                cacheAuthorName(m.author);
                                hits.push(m);
                            }
                        }
                    } else if (g && g.author && matchesTargetAuthor(g.author.id) && matchesTargetChannel(g.channel_id)) {
                        cacheAuthorName(g.author);
                        hits.push(g);
                    }
                }
                return {
                    messages: hits,
                    totalResults: Number(body.total_results || 0),
                    rawCount: groups.length
                };
            }).catch(function (err) {
                var status = err && err.status;
                if (status === 429 && tries < 5) {
                    var waitMs = extractRetryMs(err);
                    serverSearch.status = "حد مؤقت للبحث… انتظار " + Math.ceil(waitMs / 1000) + " ث";
                    emitState();
                    return sleep(waitMs).then(function () { return attempt(tries + 1); });
                }
                if (isTransientSearchError(err) && tries < 4) {
                    var netWait = [3000, 6000, 10000, 15000][tries] || 8000;
                    serverSearch.status = "🔄 انقطع اتصال البحث مؤقتاً — إعادة المحاولة (" + (tries + 1) + "/4) بعد " + Math.ceil(netWait / 1000) + " ث…";
                    emitState();
                    return sleep(netWait).then(function () { return attempt(tries + 1); });
                }
                throw err;
            });
        }
        return attempt(0);
    }

    function isAllMembersScope() {
        return cfg.memberScope === "all";
    }

    function getTargetChannelIdClean() {
        var ch = extractSingleIdOrWebhook(cfg.targetChannelId);
        return isWebhookUrl(ch) ? "" : ch;
    }

    function validateScanScope(expectedScope) {
        var guildId = extractSingleIdOrWebhook(cfg.targetGuildId);
        if (!guildId || isWebhookUrl(guildId)) {
            return {
                ok: false,
                reason: "الفحص متوقف: لم يُحدَّد معرّف الخادم المستهدف (Server ID). حدّد خادماً واحداً أولاً."
            };
        }
        if (cfg.memberScope !== "admins" && cfg.memberScope !== "all") {
            return {
                ok: false,
                reason: "الفحص متوقف: لم يُحدَّد نطاق الفحص (الإدارة المحددة أو كل الأعضاء)."
            };
        }
        if (expectedScope && cfg.memberScope !== expectedScope) {
            return {
                ok: false,
                reason: expectedScope === "all"
                    ? "الفحص متوقف: اختر نطاق «كل رسائل الأعضاء» صراحةً قبل بدء المسح الشامل للخادم."
                    : "الفحص متوقف: النطاق الحالي لا يطابق وضع البحث المطلوب."
            };
        }
        var targetCh = getTargetChannelIdClean();
        if (targetCh && mods.ChannelStore && typeof mods.ChannelStore.getChannel === "function") {
            try {
                var chObj = mods.ChannelStore.getChannel(targetCh);
                if (chObj && chObj.guild_id && String(chObj.guild_id) !== guildId) {
                    return {
                        ok: false,
                        reason: "الفحص متوقف: الغرفة المحددة (" + targetCh + ") لا تتبع الخادم المستهدف (" + guildId + ")."
                    };
                }
            } catch (e) {}
        }
        var admins = extractSnowflakes(cfg.targetUserIds);
        if (cfg.memberScope === "admins" && admins.count === 0) {
            return {
                ok: false,
                reason: "الفحص متوقف: النطاق الافتراضي «الإدارة المحددة فقط» — أضف معرّفاً واحداً على الأقل أو اختر «كل رسائل الأعضاء» صراحةً."
            };
        }
        return {
            ok: true,
            guildId: guildId,
            channelId: targetCh,
            scope: cfg.memberScope,
            admins: admins
        };
    }

    function cloneMapShallow(obj) {
        var out = {};
        if (!obj || typeof obj !== "object") return out;
        for (var k in obj) {
            if (Object.prototype.hasOwnProperty.call(obj, k) && obj[k] && typeof obj[k] === "object") {
                out[k] = Object.assign({}, obj[k]);
            }
        }
        return out;
    }

    function startFastKeywordSearch(customKeywordsText) {
        if (serverSearch.running) return;
        var scope = validateScanScope();
        if (!scope.ok) {
            state.scopeBlockedReason = scope.reason;
            serverSearch.status = "⛔ " + scope.reason;
            showToast(scope.reason);
            emitState(true);
            return;
        }
        state.scopeBlockedReason = "";
        var guildId = scope.guildId;
        var targetChannelId = scope.channelId;
        var allMembers = scope.scope === "all";
        var admins = scope.admins;
        if (!cfg.enabled) saveCfg({ enabled: true });

        var kwList = [];
        if (customKeywordsText && String(customKeywordsText).trim()) {
            var parts = String(customKeywordsText).split(/[\r\n,;،]+/);
            for (var p = 0; p < parts.length; p++) {
                var w = parts[p].trim();
                if (w && kwList.indexOf(w) === -1) kwList.push(w);
            }
        }
        if (kwList.length === 0) kwList = FAST_SEARCH_KEYWORDS.slice();

        var MAX_KW_PAGES = 20;
        var scopeLabel = (allMembers ? "كل الأعضاء" : ("الإدارة (" + admins.count + ")")) + (targetChannelId ? (" • غرفة محددة") : "");
        // في وضع الإدارة فقط نمرر author_id في استعلام البحث مباشرة (دفعة معرّفات أو فردي عند عدم دعم المصفوفة)
        var perAdminFallback = false;
        var adminCursor = 0;

        serverSearch.running = true;
        serverSearch.stopRequested = false;
        serverSearch.adminIndex = 0;
        serverSearch.adminTotal = kwList.length;
        serverSearch.currentAdmin = "";
        serverSearch.lastError = "";
        serverSearch.status = "⚡ بدء البحث السريع (" + kwList.length + " كلمة • " + scopeLabel + ")…";
        emitState(true);
        showToast("⚡ بدأ البحث السريع بالكلمات الخطيرة في رسائل " + scopeLabel + "…");

        var kIdx = 0;
        var matchedMsgs = 0;
        var totalHits = 0;
        var word = "";
        var kwPage = 0;

        function finish() {
            var wasStopped = serverSearch.stopRequested;
            serverSearch.running = false;
            serverSearch.stopRequested = false;
            if (typeof flushPumpNow === "function") flushPumpNow();
            if (wasStopped) {
                serverSearch.status = "⏸️ توقف البحث السريع عند الكلمة " + kIdx + "/" + kwList.length + " (أُرسل للفحص: " + matchedMsgs + " رسالة)";
            } else {
                serverSearch.status = "✅ اكتمل البحث السريع لـ " + kwList.length + " كلمة (نتائج الخادم: " + totalHits + " • أُرسل للذكاء الاصطناعي من " + scopeLabel + ": " + matchedMsgs + ")";
                showToast("✅ اكتمل البحث السريع! أُرسل للفحص: " + matchedMsgs + " رسالة");
            }
            emitState(true);
        }

        function nextKeyword() {
            if (stopped || serverSearch.stopRequested || kIdx >= kwList.length) return finish();
            word = kwList[kIdx++];
            kwPage = 0;
            adminCursor = 0;
            serverSearch.adminIndex = kIdx;
            serverSearch.currentAdmin = word;
            return nextKwPage();
        }

        function nextKwPage() {
            if (stopped || serverSearch.stopRequested) return finish();
            var targetAuthorParam = "";
            if (!allMembers) {
                targetAuthorParam = perAdminFallback ? admins.list[adminCursor] : admins.list.slice(0, 25);
            }
            var subLabel = (!allMembers && perAdminFallback) ? (" • إداري " + (adminCursor + 1) + "/" + admins.count) : "";
            serverSearch.status = "⚡ بحث سريع (" + kIdx + "/" + kwList.length + ") «" + word + "»" + subLabel + " صفحة " + (kwPage + 1) + "…";
            emitState();
            var offset = kwPage * 25;
            return searchAdminPage(guildId, targetAuthorParam, offset, word, targetChannelId).then(function (res) {
                if (!res || res.stopped) return finish();
                serverSearch.lastError = "";
                var msgs = res.messages || [];
                totalHits += msgs.length;
                var newlyAdded = 0;
                for (var i = 0; i < msgs.length; i++) {
                    var m = msgs[i];
                    var aId = m && m.author && m.author.id ? String(m.author.id) : "";
                    if (!aId) continue;
                    if (!allMembers && !admins.map[aId]) continue;
                    if (!m.guild_id) m.guild_id = guildId;
                    if (enqueueMessage(m, m.channel_id, false)) {
                        newlyAdded++;
                        matchedMsgs++;
                    }
                }
                serverSearch.status = "⚡ «" + word + "» (" + kIdx + "/" + kwList.length + ")" + subLabel + " صفحة " + (kwPage + 1) + " • نتائج: " + msgs.length + " • أُضيف للفحص: " + newlyAdded;
                emitState();
                kwPage++;
                var more = res.rawCount >= 25 && (offset + 25) < res.totalResults && kwPage < MAX_KW_PAGES;
                if (more) return searchSleep().then(nextKwPage);
                if (!allMembers && perAdminFallback && (adminCursor + 1) < admins.list.length) {
                    adminCursor++;
                    kwPage = 0;
                    return searchSleep().then(nextKwPage);
                }
                return searchSleep().then(nextKeyword);
            }).catch(function (err) {
                var status = Number(err && err.status) || 0;
                // إذا رفض الخادم مصفوفة author_id بـ 400، نتحول تلقائياً لتمرير author_id لكل إداري فردياً
                if (!allMembers && !perAdminFallback && status === 400 && admins.list.length > 1) {
                    perAdminFallback = true;
                    adminCursor = 0;
                    kwPage = 0;
                    return searchSleep().then(nextKwPage);
                }
                if (status === 401 || status === 403) {
                    serverSearch.lastError = "تم رفض الصلاحية من Discord (" + status + ")";
                    serverSearch.status = "❌ لا توجد صلاحية بحث في هذا الخادم (" + status + ")";
                    serverSearch.stopRequested = true;
                    emitState(true);
                    return finish();
                }
                serverSearch.lastError = sanitizeErrorMessage((err && (err.message || (err.body && err.body.message))) || err);
                emitState();
                if (isTransientSearchError(err)) {
                    serverSearch.stopRequested = true;
                }
                return searchSleep().then(nextKeyword);
            });
        }
        nextKeyword();
    }

    // ===================== فحص كل رسائل الأعضاء (زحف تاريخ كل القنوات النصية) =====================
    var CRAWLABLE_TYPES = { 0: 1, 5: 1, 10: 1, 11: 1, 12: 1 };
    var crawlSavePagesCounter = 0;

    function emptyCrawl(guildId) {
        return { guildId: guildId || "", channels: {}, fetchedTotal: 0, queuedTotal: 0, updatedAt: 0 };
    }

    function getCrawlForGuild(guildId) {
        var c = cfg.memberCrawl;
        if (c && typeof c === "object" && c.guildId === guildId && c.channels && typeof c.channels === "object") return c;
        return emptyCrawl(guildId);
    }

    function persistCrawl(crawl, forceNow) {
        try {
            crawlSavePagesCounter++;
            if (!forceNow && crawlSavePagesCounter < 5) return;
            crawlSavePagesCounter = 0;
            saveCfg({
                memberCrawl: {
                    guildId: crawl.guildId,
                    channels: cloneMapShallow(crawl.channels),
                    fetchedTotal: crawl.fetchedTotal || 0,
                    queuedTotal: crawl.queuedTotal || 0,
                    updatedAt: Date.now()
                }
            });
        } catch (e) {}
    }

    function listCrawlableChannels(guildId) {
        var targetCh = getTargetChannelIdClean();
        if (targetCh) return [targetCh];
        var ids = listGuildChannelIds(guildId);
        var out = [];
        for (var i = 0; i < ids.length; i++) {
            var ch = null;
            try { ch = mods.ChannelStore && mods.ChannelStore.getChannel ? mods.ChannelStore.getChannel(ids[i]) : null; } catch (e) {}
            var t = ch ? Number(ch.type) : 0;
            if (ch && !CRAWLABLE_TYPES[t]) continue;
            out.push(ids[i]);
        }
        return out;
    }

    function getCrawlSummary(guildId) {
        var crawl = getCrawlForGuild(guildId);
        var chIds = listCrawlableChannels(guildId);
        var done = 0;
        for (var i = 0; i < chIds.length; i++) {
            var cp = crawl.channels[chIds[i]];
            if (cp && cp.done) done++;
        }
        return {
            total: chIds.length,
            done: done,
            remaining: chIds.length - done,
            fetchedTotal: Number(crawl.fetchedTotal) || 0,
            queuedTotal: Number(crawl.queuedTotal) || 0,
            hasProgress: done > 0 || (Number(crawl.fetchedTotal) || 0) > 0,
            allDone: chIds.length > 0 && done === chIds.length
        };
    }

    function resetMemberCrawl() {
        var gid = extractSingleIdOrWebhook(cfg.targetGuildId);
        if (isWebhookUrl(gid)) gid = "";
        saveCfg({ memberCrawl: emptyCrawl(gid) });
    }

    function fetchChannelPage(channelId, before) {
        function attempt(tries) {
            if (stopped || serverSearch.stopRequested) return Promise.resolve({ stopped: true });
            var q = { limit: 100 };
            if (before) q.before = before;
            return apiGet("/channels/" + channelId + "/messages", q).then(function (res) {
                var body = res && res.body;
                return { messages: Array.isArray(body) ? body : [] };
            }).catch(function (err) {
                var status = err && err.status;
                if (status === 429 && tries < 6) {
                    var waitMs = extractRetryMs(err);
                    serverSearch.status = "حد مؤقت من ديسكورد… انتظار " + Math.ceil(waitMs / 1000) + " ث";
                    emitState();
                    return sleep(waitMs).then(function () { return attempt(tries + 1); });
                }
                if (isTransientSearchError(err) && tries < 4) {
                    var netWait = [3000, 6000, 10000, 15000][tries] || 8000;
                    serverSearch.status = "🔄 انقطع الاتصال مؤقتاً — إعادة المحاولة (" + (tries + 1) + "/4) بعد " + Math.ceil(netWait / 1000) + " ث…";
                    emitState();
                    return sleep(netWait).then(function () { return attempt(tries + 1); });
                }
                throw err;
            });
        }
        return attempt(0);
    }

    function startAllMembersCrawl(onePageOnly, targetLimit) {
        if (serverSearch.running) return;
        var scope = validateScanScope("all");
        if (!scope.ok) {
            state.scopeBlockedReason = scope.reason;
            serverSearch.status = "⛔ " + scope.reason;
            showToast(scope.reason);
            emitState(true);
            return;
        }
        state.scopeBlockedReason = "";
        var guildId = scope.guildId;
        if (!hasAnyAiProvider()) {
            showToast("لا يوجد مزوّد ذكاء اصطناعي جاهز");
            return;
        }
        if (!cfg.enabled) saveCfg({ enabled: true });

        var chIds = listCrawlableChannels(guildId);
        if (chIds.length === 0) {
            showToast("لم أجد قنوات نصية محمّلة لهذا الخادم — افتح الخادم مرة ثم أعد المحاولة");
            return;
        }
        var crawl = getCrawlForGuild(guildId);
        if (crawl !== cfg.memberCrawl) {
            cfg.memberCrawl = crawl;
            persistCrawl(crawl, true);
        }

        var targetCount = (typeof targetLimit === "number" && targetLimit > 0)
            ? targetLimit
            : (onePageOnly ? 5000 : Infinity);

        serverSearch.running = true;
        serverSearch.stopRequested = false;
        serverSearch.adminIndex = 0;
        serverSearch.adminTotal = chIds.length;
        serverSearch.currentAdmin = "";
        serverSearch.fetchedMsgs = crawl.fetchedTotal || 0;
        serverSearch.queuedMsgs = crawl.queuedTotal || 0;
        serverSearch.lastError = "";
        serverSearch.status = onePageOnly
            ? ("📥 جلب دفعة " + targetCount + " رسالة (" + (cfg.batchSize || 250) + " لكل نموذج بالتوازي)…")
            : ("🌐 بدء فحص كل رسائل الأعضاء في " + chIds.length + " قناة…");
        emitState(true);
        showToast(onePageOnly
            ? ("📥 جارٍ جلب حتى " + targetCount + " رسالة وتوزيعها على النماذج بالتوازي…")
            : "🌐 بدأ فحص كل رسائل الأعضاء (يتابع من حيث توقف)");

        var idx = 0;
        var abortedByNetwork = false;
        var sessionQueued = 0;

        function waitBacklog() {
            var maxBacklog = Math.max(6000, (Number(cfg.batchSize) || 250) * 25);
            if (stopped || serverSearch.stopRequested || queue.length < maxBacklog) return Promise.resolve();
            serverSearch.status = "⏳ انتظار الذكاء الاصطناعي (" + queue.length + " رسالة بالطابور) • القناة " + idx + "/" + chIds.length;
            emitState();
            return sleep(800).then(waitBacklog);
        }

        function finish() {
            var wasStopped = serverSearch.stopRequested;
            serverSearch.running = false;
            serverSearch.stopRequested = false;
            persistCrawl(crawl, true);
            if (typeof flushPumpNow === "function") flushPumpNow();
            if (cfg.scanImages && imageQueue.length > 0 && typeof pumpImages === "function") {
                pumpImages();
            }
            var sum = getCrawlSummary(guildId);
            if (abortedByNetwork) {
                serverSearch.status = "⏸️ انقطع الاتصال — حُفظ التقدم (" + sum.done + "/" + sum.total + " قناة) • اضغط متابعة لاحقاً";
            } else if (wasStopped) {
                serverSearch.status = "⏸️ تم الحفظ والتوقف (" + sum.done + "/" + sum.total + " قناة • المجلوب: " + sum.fetchedTotal + ")";
            } else if (onePageOnly) {
                serverSearch.status = "✅ تم جلب دفعة " + sessionQueued + " رسالة وأُرسلت للفحص (" + (cfg.batchSize || 250) + " رسالة/نموذج بالتوازي)";
                showToast("✅ جُلبت الدفعة وأُرسلت للنماذج (" + sessionQueued + " رسالة)");
            } else {
                serverSearch.status = "✅ اكتمل فحص كل رسائل الأعضاء (" + sum.done + "/" + sum.total + " قناة • المجلوب: " + sum.fetchedTotal + " • أُرسل للفحص الآن: " + sessionQueued + ")";
                showToast("✅ اكتمل جلب كل رسائل الأعضاء — الذكاء الاصطناعي يكمل الطابور");
            }
            emitState(true);
        }

        function nextChannel() {
            if (stopped || serverSearch.stopRequested || abortedByNetwork || idx >= chIds.length) return finish();
            var chId = chIds[idx++];
            var cp = crawl.channels[chId];
            if (!cp || typeof cp !== "object") {
                cp = { before: "", done: false, fetched: 0, skipped: false };
                crawl.channels[chId] = cp;
            }
            if (cp.done) return nextChannel();
            var info = getChannelInfo(chId);
            serverSearch.adminIndex = idx;
            serverSearch.currentAdmin = (info && info.channelName) || chId;

            function nextPage() {
                if (stopped || serverSearch.stopRequested || abortedByNetwork) return finish();
                return waitBacklog().then(function () {
                    if (stopped || serverSearch.stopRequested) return { stopped: true };
                    return fetchChannelPage(chId, cp.before);
                }).then(function (res) {
                    if (!res || res.stopped) return finish();
                    serverSearch.lastError = "";
                    var msgs = res.messages || [];
                    var added = 0;
                    for (var i = 0; i < msgs.length; i++) {
                        var m = msgs[i];
                        if (!m || !m.id) continue;
                        if (!m.guild_id) m.guild_id = guildId;
                        crawl.fetchedTotal++;
                        cp.fetched = (cp.fetched || 0) + 1;
                        if (enqueueMessage(m, chId, false, true)) {
                            added++;
                            sessionQueued++;
                            crawl.queuedTotal++;
                        }
                    }
                    serverSearch.fetchedMsgs = crawl.fetchedTotal;
                    serverSearch.queuedMsgs = crawl.queuedTotal;
                    if (msgs.length) cp.before = String(msgs[msgs.length - 1].id);
                    if (msgs.length < 100) cp.done = true;
                    persistCrawl(crawl, cp.done || onePageOnly);
                    var perModelLimit = Math.max(15, getBatchTargetLimit());
                    var parallelCnt = Math.max(1, Math.min(8, getMaxConcurrentBatches()));
                    var dispatchTarget = perModelLimit <= 100 ? (perModelLimit * parallelCnt) : perModelLimit;
                    
                    if (cfg.scanImages && imageQueue.length > 0 && typeof scheduleImagePump === "function") {
                        scheduleImagePump(imageQueue.length >= (Number(cfg.imageBatchSize) || 10));
                    }

                    var reachedTarget = onePageOnly && sessionQueued >= targetCount;

                    serverSearch.status = "🌐 قناة " + idx + "/" + chIds.length + " (#" + serverSearch.currentAdmin + ") • جُلب: " + cp.fetched + " • الدفعة الحالية: " + sessionQueued + (onePageOnly ? ("/" + targetCount) : "") + " • بالطابور: " + queue.length;
                    emitState();

                    if (queue.length >= dispatchTarget) {
                        pump(true);
                    }

                    if (reachedTarget) {
                        if (queue.length > 0) pump(true);
                        if (cfg.scanImages && imageQueue.length > 0 && typeof pumpImages === "function") {
                            pumpImages();
                        }
                        return finish();
                    }

                    if (cp.done) {
                        if (onePageOnly && (sessionQueued >= targetCount || idx >= chIds.length)) return finish();
                        return sleep(50).then(nextChannel);
                    }
                    return sleep(50).then(nextPage);
                }).catch(function (err) {
                    var status = err && err.status;
                    serverSearch.lastError = sanitizeErrorMessage((err && (err.message || (err.body && err.body.message))) || err);
                    emitState();
                    if (status === 403 || status === 404 || status === 401 || status === 400) {
                        cp.done = true;
                        cp.skipped = true;
                        persistCrawl(crawl, true);
                        return sleep(350).then(nextChannel);
                    }
                    if (isTransientSearchError(err)) {
                        abortedByNetwork = true;
                        return finish();
                    }
                    return crawlSleep().then(nextChannel);
                });
            }
            return nextPage();
        }
        nextChannel();
    }

    // اختبار حي لمحرك الذكاء الاصطناعي: رسائل مخالفة معروفة + رسائل سليمة
    function runDetectionSelfTest(onDone) {
        var samples = [
            "السلام عليكم ورحمة الله، متى الدرس؟",
            "الدولة الإسلامية باقية وتتمدد، البغدادي أمير المؤمنين تقبله الله",
            "داعش خوارج ضالون ونبرأ إلى الله منهم",
            "انشروا إصدارات ولاية سيناء الجديدة"
        ];
        moderateWithFailover(samples).then(function (out) {
            var r = (out && out.results) || [];
            var hitBad = (r[1] && r[1].length > 0) && (r[3] && r[3].length > 0);
            var falsePos = (r[0] && r[0].length > 0) || (r[2] && r[2].length > 0);
            var msg = (hitBad && !falsePos)
                ? ("✅ المحرك يعمل بدقة عبر " + out.sourceLabel + ": رصد الرسالتين المخالفتين وتجاهل السليمتين. إذا لم يُرصد شيء في الخادم فغالباً لا توجد مخالفات واضحة.")
                : ("⚠️ نتيجة غير مثالية عبر " + out.sourceLabel + ": رصد المخالف=" + (hitBad ? "نعم" : "لا") + " • إنذار خاطئ=" + (falsePos ? "نعم" : "لا"));
            onDone(msg);
        }).catch(function (err) {
            onDone("❌ فشل الاختبار: " + String((err && err.message) || err));
        });
    }

    function emptyProgress(guildId) {
        return {
            guildId: guildId || "",
            admins: {},
            fetchedTotal: 0,
            queuedTotal: 0,
            updatedAt: 0
        };
    }

    function getProgressForGuild(guildId) {
        var sp = cfg.searchProgress;
        if (sp && typeof sp === "object" && sp.guildId === guildId && sp.admins && typeof sp.admins === "object") {
            return sp;
        }
        return emptyProgress(guildId);
    }

    function getSearchSummary(guildId, adminList, maxMsgs) {
        var total = adminList.length;
        var maxM = Math.max(25, Number(maxMsgs) || Number(cfg.searchDepth) || 75);
        var prog = getProgressForGuild(guildId);
        var doneCount = 0;
        var startedCount = 0;
        var nextAdminId = "";
        var nextOffset = 0;
        for (var i = 0; i < total; i++) {
            var uid = adminList[i];
            var ap = prog.admins[uid];
            var isDone = !!(ap && (ap.reachedEnd || (Number(ap.nextOffset) || 0) >= maxM));
            if (isDone) {
                doneCount++;
            } else {
                if (!nextAdminId) {
                    nextAdminId = uid;
                    nextOffset = (ap && Number(ap.nextOffset)) || 0;
                }
                if (ap && (Number(ap.nextOffset) || 0) > 0) startedCount++;
            }
        }
        return {
            total: total,
            doneCount: doneCount,
            remainingCount: total - doneCount,
            startedCount: startedCount,
            hasProgress: doneCount > 0 || startedCount > 0,
            allDone: total > 0 && doneCount === total,
            nextAdminId: nextAdminId,
            nextOffset: nextOffset,
            fetchedTotal: Number(prog.fetchedTotal) || 0,
            queuedTotal: Number(prog.queuedTotal) || 0
        };
    }

    var searchSavePagesCounter = 0;

    function persistSearchProgress(prog, forceNow) {
        try {
            searchSavePagesCounter++;
            if (!forceNow && searchSavePagesCounter < 5) return;
            searchSavePagesCounter = 0;
            var copy = {
                guildId: prog.guildId,
                admins: cloneMapShallow(prog.admins),
                fetchedTotal: prog.fetchedTotal || 0,
                queuedTotal: prog.queuedTotal || 0,
                updatedAt: Date.now()
            };
            saveCfg({ searchProgress: copy });
        } catch (e) {}
    }

    function stopServerAdminSearch() {
        if (!serverSearch.running) return;
        serverSearch.stopRequested = true;
        serverSearch.status = "جارٍ الإيقاف وحفظ نقطة التوقف…";
        emitState(true);
    }

    function startServerAdminSearch(forceNewOnly, customDepth) {
        if (serverSearch.running) return;
        var scope = validateScanScope("admins");
        if (!scope.ok) {
            state.scopeBlockedReason = scope.reason;
            serverSearch.status = "⛔ " + scope.reason;
            showToast(scope.reason);
            emitState(true);
            return;
        }
        state.scopeBlockedReason = "";
        var guildId = scope.guildId;
        var admins = scope.admins;
        if (!cfg.enabled) saveCfg({ enabled: true });
        if (customDepth && Number(customDepth) >= 25 && Number(customDepth) !== Number(cfg.searchDepth)) {
            saveCfg({ searchDepth: Number(customDepth) });
        }

        var maxMsgsPerAdmin = Math.max(25, Number(customDepth) || Number(cfg.searchDepth) || 200);
        var maxPages = Math.max(1, Math.ceil(maxMsgsPerAdmin / 25));

        var prog = getProgressForGuild(guildId);
        if (prog !== cfg.searchProgress) {
            cfg.searchProgress = prog;
            persistSearchProgress(prog, true);
        }

        var summary = getSearchSummary(guildId, admins.list, maxMsgsPerAdmin);
        var checkNewOnly = !!forceNewOnly || summary.allDone;

        serverSearch.running = true;
        serverSearch.stopRequested = false;
        serverSearch.adminIndex = summary.doneCount;
        serverSearch.adminTotal = admins.count;
        serverSearch.currentAdmin = "";
        serverSearch.fetchedMsgs = prog.fetchedTotal || 0;
        serverSearch.queuedMsgs = prog.queuedTotal || 0;
        serverSearch.lastError = "";
        serverSearch.status = checkNewOnly
            ? ("فحص الرسائل الجديدة فقط لـ " + admins.count + " إداري…")
            : (summary.hasProgress
                ? ("▶️ متابعة البحث في كل رسائل الإدارة (المكتمل: " + summary.doneCount + "/" + admins.count + " • العمق: " + maxMsgsPerAdmin + "/إداري)…")
                : ("بدء البحث الشامل عن رسائل " + admins.count + " إداري (حتى " + maxMsgsPerAdmin + " رسالة لكل إداري)…"));
        emitState(true);
        showToast(checkNewOnly
            ? "🔎 فحص الرسائل الجديدة للإدارة فقط…"
            : (summary.hasProgress
                ? ("▶️ متابعة البحث الشامل (المتبقي " + summary.remainingCount + " إداري)")
                : ("🔎 بدأ البحث الشامل في الخادم عن كل رسائل " + admins.count + " إداري")));

        var idx = 0;
        var newCheckedCount = 0;
        var abortedByNetwork = false;
        var abortedByPermission = "";

        function waitIfAiBacklogged() {
            var maxBacklog = Math.max(200, (Number(cfg.batchSize) || 15) * 6);
            if (stopped || serverSearch.stopRequested || !hasAnyAiProvider() || queue.length < maxBacklog) {
                return Promise.resolve();
            }
            serverSearch.status = "⏳ انتظار الذكاء الاصطناعي لإنهاء الدفعة الحالية (" + queue.length + " رسالة)…";
            emitState();
            return sleep(1500).then(waitIfAiBacklogged);
        }

        function nextAdmin() {
            if (stopped || serverSearch.stopRequested || abortedByNetwork || abortedByPermission || idx >= admins.list.length) {
                var wasStopped = serverSearch.stopRequested;
                serverSearch.running = false;
                serverSearch.stopRequested = false;
                persistSearchProgress(prog, true);
                if (typeof flushPumpNow === "function") flushPumpNow();
                var endSum = getSearchSummary(guildId, admins.list, maxMsgsPerAdmin);
                if (abortedByPermission) {
                    serverSearch.status = abortedByPermission;
                    showToast(abortedByPermission);
                } else if (abortedByNetwork) {
                    serverSearch.status = "⏸️ انقطع اتصال الإنترنت — تم حفظ التقدم عند " + endSum.doneCount + "/" + admins.count + " إداري، اضغط متابعة عند عودة الشبكة";
                    showToast("⏸️ انقطع الشبكة — تم حفظ نقطة التوقف للإكمال لاحقاً");
                } else if (wasStopped) {
                    serverSearch.status = "⏸️ تم الحفظ والتوقف عند " + endSum.doneCount + "/" + admins.count + " إداري — اضغط متابعة للإكمال من نفس النقطة";
                    showToast("⏸️ تم حفظ التقدم — يمكنك المتابعة لاحقاً");
                } else if (checkNewOnly) {
                    serverSearch.status = "✅ اكتمل فحص أحدث الرسائل لـ " + admins.count + " إداري (جديد للفحص: " + newCheckedCount + ")";
                    showToast("✅ اكتمل فحص أحدث الرسائل (" + newCheckedCount + " رسالة جديدة)");
                } else if (endSum.allDone) {
                    serverSearch.status = "✅ اكتمل البحث لكل الإدارة (" + endSum.doneCount + "/" + admins.count + ") • إجمالي المجلوب: " + prog.fetchedTotal;
                    showToast("✅ اكتمل البحث لكل الإدارة!");
                } else {
                    serverSearch.status = "⏸️ توقف مؤقت عند " + endSum.doneCount + "/" + admins.count + " إداري (المتبقي: " + endSum.remainingCount + ") • المجلوب: " + prog.fetchedTotal;
                }
                emitState(true);
                return;
            }

            var uid = admins.list[idx];
            idx++;
            var ap = prog.admins[uid];
            if (!ap || typeof ap !== "object") {
                ap = { nextOffset: 0, reachedEnd: false, fetched: 0, total: 0, updatedAt: 0 };
                prog.admins[uid] = ap;
            }

            // تخطي فوري للإداريين المكتملين عند وضع المتابعة
            if (!checkNewOnly && (ap.reachedEnd || (Number(ap.nextOffset) || 0) >= maxMsgsPerAdmin)) {
                nextAdmin();
                return;
            }

            serverSearch.adminIndex = idx;
            serverSearch.currentAdmin = resolveUserLabel(uid, guildId) || uid;
            var startPage = checkNewOnly ? 0 : Math.floor((Number(ap.nextOffset) || 0) / 25);
            var endPage = checkNewOnly ? 1 : maxPages;
            serverSearch.status = (checkNewOnly ? "فحص الجديد " : "بحث ") + idx + "/" + admins.count + ": " + serverSearch.currentAdmin + (startPage > 0 ? (" (من رسالة " + (startPage * 25) + ")") : "");
            emitState();

            var page = startPage;
            function nextPage() {
                if (stopped || serverSearch.stopRequested || abortedByNetwork || abortedByPermission || page >= endPage) {
                    if (!checkNewOnly && !stopped && !serverSearch.stopRequested && !abortedByNetwork && !abortedByPermission) {
                        persistSearchProgress(prog, true);
                    }
                    return searchSleep().then(nextAdmin);
                }
                var offset = page * 25;
                return waitIfAiBacklogged().then(function () {
                    if (stopped || serverSearch.stopRequested || abortedByNetwork || abortedByPermission) return { stopped: true };
                    return searchAdminPage(guildId, uid, offset, "", scope.channelId);
                }).then(function (res) {
                    if (!res || res.stopped) return nextAdmin();
                    serverSearch.lastError = "";
                    var msgs = res.messages || [];
                    var newlyQueued = 0;
                    for (var i = 0; i < msgs.length; i++) {
                        prog.fetchedTotal++;
                        ap.fetched = (ap.fetched || 0) + 1;
                        serverSearch.fetchedMsgs = prog.fetchedTotal;
                        var m = msgs[i];
                        if (!m.guild_id) m.guild_id = guildId;
                        if (enqueueMessage(m, m.channel_id, false)) {
                            prog.queuedTotal++;
                            serverSearch.queuedMsgs = prog.queuedTotal;
                            newlyQueued++;
                            newCheckedCount++;
                        }
                    }
                    ap.total = res.totalResults || ap.total || 0;
                    ap.updatedAt = Date.now();
                    if (!checkNewOnly) {
                        ap.nextOffset = offset + 25;
                        if (res.rawCount < 25 || (offset + 25) >= res.totalResults) {
                            ap.reachedEnd = true;
                        }
                        persistSearchProgress(prog, ap.reachedEnd);
                    }
                    serverSearch.currentAdmin = resolveUserLabel(uid, guildId) || uid;
                    serverSearch.status = (checkNewOnly ? "جديد " : "إداري ") + idx + "/" + admins.count + " (" + serverSearch.currentAdmin + ") • أُضيف: " + newlyQueued + " • الإجمالي: " + prog.fetchedTotal;
                    emitState();
                    page++;
                    if (checkNewOnly || res.rawCount < 25 || (offset + 25) >= res.totalResults) {
                        return searchSleep().then(nextAdmin);
                    }
                    return searchSleep().then(nextPage);
                }).catch(function (err) {
                    var status = err && err.status;
                    serverSearch.lastError = sanitizeErrorMessage((err && (err.message || (err.body && err.body.message))) || err);
                    emitState();
                    if (status === 403 || status === 401 || status === 404) {
                        abortedByPermission = "❌ لا توجد صلاحية بحث في هذا الخادم (" + status + ")";
                        return nextAdmin();
                    }
                    if (isTransientSearchError(err)) {
                        abortedByNetwork = true;
                        return nextAdmin();
                    }
                    return searchSleep().then(nextAdmin);
                });
            }
            nextPage();
        }
        nextAdmin();
    }

    function scanServerCachedChannels(guildId) {
        var scope = validateScanScope();
        if (!scope.ok || scope.guildId !== String(guildId || "")) {
            if (!scope.ok) state.scopeBlockedReason = scope.reason;
            emitState(true);
            return { channels: 0, scanned: 0, blockedReason: scope.ok ? "المعرّف لا يطابق الخادم المستهدف" : scope.reason };
        }
        state.scopeBlockedReason = "";
        var chIds = scope.channelId ? [scope.channelId] : listGuildChannelIds(guildId);
        var total = 0;
        for (var i = 0; i < chIds.length; i++) {
            total += scanChannel(chIds[i], false);
        }
        return { channels: chIds.length, scanned: total };
    }

    // ===================== إرسال التقارير للمجموعة المحددة =====================
    var forwardQueue = [];
    var forwardRunning = false;
    var forwardedSet = {};

    function formatGroupReport(f) {
        var cat = CATS[f.cat] || { label: f.cat, steps: [], banRisk: false };
        var where = (f.guildName ? f.guildName + " / " : (f.typeLabel === "خاص" ? "خاص / " : "")) + (f.channelName || f.channelId);
        var authorLine = f.authorName + (f.authorUsername ? " (@" + f.authorUsername + ")" : "") + (f.authorId ? " | ID: `" + f.authorId + "`" : "");
        var lines = [
            cat.banRisk ? "🚨🔥 **رصد مخالفة خطيرة موجبة لحظر الخادم — حارس بحر**" : "🚨 **رصد مخالفة — حارس بحر**",
            "• **نوع المخالفة:** " + cat.label + " (" + Math.round((f.score || 0) * 100) + "%)",
            "• **سبب المنع:** " + (f.reason || cat.label),
            "• **الكاتب" + (cfg.memberScope === "all" ? "" : " (الإدارة)") + ":** " + authorLine,
            "• **المكان:** " + where,
            "• **رابط الرسالة:** " + messageLink(f),
            "• **الإبلاغ المناسب:** " + cat.steps.join(" ← ")
        ];
        if (f.cat === "sexual/minors") {
            lines.push("⚠️ **تحذير سلامة الأطفال:** لا تفتح أو تحفظ أو تصوّر أو تشارك أي مرفق؛ بلّغ ديسكورد و `https://report.cybertip.org` مباشرة.");
        } else if (f.hasAttach) {
            lines.push("• **ملاحظة:** الرسالة تحتوي مرفقاً (لم يُحلَّل).");
        }
        lines.push("-# Server: `" + (f.guildId || "DM") + "` • Channel: `" + f.channelId + "` • Msg: `" + f.messageId + "` • المحرك: " + (f.source || ""));
        var msg = lines.join("\n");
        if (msg.length > 1950) msg = msg.slice(0, 1945) + "…";
        return msg;
    }

    function postToDestination(target, content) {
        var dest = extractSingleIdOrWebhook(target);
        if (!dest) return Promise.reject(new Error("معرّف المجموعة/القناة غير محدد"));

        if (isWebhookUrl(dest)) {
            return fetch(dest, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ content: content })
            }).then(function (r) {
                if (!r.ok) {
                    var err = new Error("Webhook HTTP " + r.status);
                    err.status = r.status;
                    throw err;
                }
                return "sent";
            });
        }

        if (mods.RestAPI && typeof mods.RestAPI.post === "function") {
            return Promise.resolve(mods.RestAPI.post({
                url: "/channels/" + dest + "/messages",
                body: { content: content, tts: false }
            })).then(function () { return "sent"; });
        }
        if (mods.MessageActions && typeof mods.MessageActions.sendMessage === "function") {
            return Promise.resolve(mods.MessageActions.sendMessage(dest, {
                content: content,
                invalidEmojis: [],
                tts: false,
                validNonShortcutEmojis: []
            })).then(function () { return "sent"; });
        }
        return Promise.reject(new Error("وحدة الإرسال غير متاحة حالياً"));
    }

    function markFindingForwarded(messageId) {
        forwardedSet[messageId] = true;
        var list = cfg.findings || [];
        var changed = false;
        for (var i = 0; i < list.length; i++) {
            if (list[i].messageId === messageId && !list[i].forwarded) {
                list[i].forwarded = true;
                changed = true;
            }
        }
        if (changed) saveCfg({ findings: list.slice() });
    }

    function enqueueForward(f, forceResend) {
        var dest = extractSingleIdOrWebhook(cfg.reportChannelId);
        if (!dest || !f || !f.messageId) return false;
        if (!isWebhookUrl(dest) && f.channelId === dest) return false;
        if (!forceResend && (f.forwarded || forwardedSet[f.messageId])) return false;
        forwardedSet[f.messageId] = true;
        forwardQueue.push({ finding: f, tries: 0 });
        state.forwardQueued = forwardQueue.length;
        emitState();
        pumpForward();
        return true;
    }

    function pumpForward() {
        if (forwardRunning || stopped || forwardQueue.length === 0) return;
        forwardRunning = true;
        var step = function () {
            if (stopped || forwardQueue.length === 0) {
                forwardRunning = false;
                state.forwardQueued = forwardQueue.length;
                emitState();
                return;
            }
            var dest = extractSingleIdOrWebhook(cfg.reportChannelId);
            if (!dest) {
                forwardQueue.length = 0;
                forwardRunning = false;
                state.forwardQueued = 0;
                emitState();
                return;
            }
            var jobItem = forwardQueue.shift();
            state.forwardQueued = forwardQueue.length;
            var text = formatGroupReport(jobItem.finding);
            postToDestination(dest, text).then(function () {
                state.lastForwardError = "";
                state.forwarded++;
                markFindingForwarded(jobItem.finding.messageId);
                emitState();
                return sleep(FORWARD_GAP_MS);
            }).catch(function (err) {
                var status = err && err.status;
                var msg = sanitizeErrorMessage((err && (err.message || (err.body && err.body.message))) || err);
                state.lastForwardError = msg;
                if (status === 429 && jobItem.tries < 3) {
                    jobItem.tries++;
                    forwardQueue.unshift(jobItem);
                    var retrySec = (err && err.body && Number(err.body.retry_after)) || 6;
                    emitState();
                    return sleep(Math.max(4000, Math.ceil(retrySec * 1000) + 500));
                }
                delete forwardedSet[jobItem.finding.messageId];
                emitState();
                return sleep(FORWARD_GAP_MS);
            }).then(step, step);
        };
        step();
    }

    // ===================== الطابور (بدفعات 15-50 + تقسيم ثنائي + حفظ مخفف للمفحوص) =====================
    var MAX_PERSISTED_SCANNED = 5000;
    var seenIds = {};
    var seenOrder = [];
    var persistedScannedSet = {};
    var scannedSaveTimer = null;
    var queue = [];
    var running = false;
    var stopped = false;
    var nextChunkId = 1;

    function markSeen(id) {
        if (!id || seenIds[id]) return;
        seenIds[id] = 1;
        seenOrder.push(id);
        if (seenOrder.length > 8000) {
            var old = seenOrder.splice(0, 2000);
            for (var i = 0; i < old.length; i++) delete seenIds[old[i]];
        }
    }

    function scheduleSaveScannedIds() {
        if (scannedSaveTimer) return;
        scannedSaveTimer = setTimeout(function () {
            scannedSaveTimer = null;
            try {
                if (!Array.isArray(cfg.scannedIds)) cfg.scannedIds = [];
                if (cfg.scannedIds.length > MAX_PERSISTED_SCANNED) {
                    var dropped = cfg.scannedIds.splice(0, cfg.scannedIds.length - MAX_PERSISTED_SCANNED);
                    for (var i = 0; i < dropped.length; i++) delete persistedScannedSet[dropped[i]];
                }
                saveCfg({ scannedIds: cfg.scannedIds.slice() });
            } catch (e) {}
        }, 15000);
    }

    function markPersistedScanned(id) {
        if (!id || persistedScannedSet[id]) return;
        persistedScannedSet[id] = 1;
        markSeen(id);
        if (!Array.isArray(cfg.scannedIds)) cfg.scannedIds = [];
        cfg.scannedIds.push(String(id));
        scheduleSaveScannedIds();
    }

    function resetAllProgress(clearFindingsToo) {
        if (serverSearch.running) stopServerAdminSearch();
        seenIds = {};
        seenOrder = [];
        persistedScannedSet = {};
        crawlSavePagesCounter = 0;
        searchSavePagesCounter = 0;
        if (scannedSaveTimer) { clearTimeout(scannedSaveTimer); scannedSaveTimer = null; }
        if (imagePumpTimer) { clearTimeout(imagePumpTimer); imagePumpTimer = null; }
        imageQueue.length = 0;
        activeImageWorkers = 0;
        visionCooldowns = {};
        state.imageQueued = 0;
        state.imagesScanned = 0;
        state.imageWorkers = 0;
        state.scanned = 0;
        state.preFiltered = 0;
        state.hallucinationsBlocked = 0;
        state.unreviewedCount = 0;
        state.lastScanWarning = "";
        state.lastError = "";
        serverSearch.fetchedMsgs = 0;
        serverSearch.queuedMsgs = 0;
        serverSearch.status = "";
        serverSearch.lastError = "";
        var gid = extractSingleIdOrWebhook(cfg.targetGuildId);
        if (isWebhookUrl(gid)) gid = "";
        var patch = {
            scannedIds: [],
            searchProgress: emptyProgress(gid),
            memberCrawl: emptyCrawl(gid)
        };
        if (clearFindingsToo) {
            patch.findings = [];
            patch.adminNames = {};
            nameCache = {};
            forwardedSet = {};
            state.flagged = 0;
            state.forwarded = 0;
            diagnosticLogs.length = 0;
        } else {
            for (var i = 0; i < (cfg.findings || []).length; i++) {
                markSeen(cfg.findings[i].messageId);
            }
        }
        saveCfg(patch);
        emitState(true);
    }

    function appendEmbedTexts(embeds, parts) {
        if (!Array.isArray(embeds)) return;
        for (var i = 0; i < embeds.length && i < 4; i++) {
            var e = embeds[i] || {};
            if (e.title || e.rawTitle) parts.push(String(e.title || e.rawTitle));
            if (e.description || e.rawDescription) parts.push(String(e.description || e.rawDescription));
            if (Array.isArray(e.fields)) {
                for (var f = 0; f < e.fields.length && f < 10; f++) {
                    var fld = e.fields[f] || {};
                    var fn = String(fld.name || fld.rawName || "").trim();
                    var fv = String(fld.value || fld.rawValue || "").trim();
                    if (fn || fv) parts.push((fn ? (fn + ": ") : "") + fv);
                }
            }
        }
    }

    function extractText(msg) {
        if (!msg || typeof msg !== "object") return "";
        var parts = [];
        if (typeof msg.content === "string" && msg.content) parts.push(msg.content);
        appendEmbedTexts(msg.embeds, parts);

        // دعم الرسائل المُعاد توجيهها في ديسكورد (message_snapshots / messageSnapshots)
        var snaps = msg.message_snapshots || msg.messageSnapshots;
        if (Array.isArray(snaps)) {
            for (var s = 0; s < snaps.length && s < 3; s++) {
                var sm = (snaps[s] && snaps[s].message) ? snaps[s].message : snaps[s];
                if (!sm || typeof sm !== "object") continue;
                if (typeof sm.content === "string" && sm.content) parts.push(sm.content);
                appendEmbedTexts(sm.embeds, parts);
            }
        }

        var t = parts.join("\n").trim();
        if (t.length > MAX_TEXT) t = t.slice(0, MAX_TEXT);
        return t;
    }

    function extractReplyContext(msg) {
        if (!msg || typeof msg !== "object") return "";
        var ref = msg.referenced_message || msg.referencedMessage;
        if (!ref || typeof ref !== "object") return "";
        var refText = extractText(ref);
        if (!refText) return "";
        refText = refText.replace(/\s+/g, " ").trim();
        if (refText.length > 260) refText = refText.slice(0, 260) + "…";
        return refText;
    }

    function authorOf(msg) {
        var a = msg.author || {};
        if (a && a.id) cacheAuthorName(a);
        return {
            id: String(a.id || ""),
            name: a.globalName || a.global_name || a.username || "مجهول",
            username: a.username || "",
            bot: !!a.bot
        };
    }

    function enqueueMessage(msg, channelId, force, deferPump) {
        try {
            if (stopped || !cfg.enabled || !msg || !msg.id) return false;
            if (msg._bahrGuard) return false;

            var scope = validateScanScope();
            if (!scope.ok) {
                if (state.scopeBlockedReason !== scope.reason) {
                    state.scopeBlockedReason = scope.reason;
                    emitState();
                }
                return false;
            }
            if (state.scopeBlockedReason) state.scopeBlockedReason = "";

            var chId = String(channelId || msg.channel_id || msg.channelId || "");
            if (scope.channelId && chId !== scope.channelId) return false;
            var reportDest = extractSingleIdOrWebhook(cfg.reportChannelId);
            if (reportDest && !isWebhookUrl(reportDest) && chId && chId === reportDest) {
                return false;
            }

            var msgGuild = String(msg.guild_id || msg.guildId || "");
            if (!msgGuild && chId) {
                var ci = getChannelInfo(chId);
                msgGuild = String(ci.guildId || "");
            }
            if (!msgGuild || msgGuild !== scope.guildId) return false;

            var a = authorOf(msg);
            if (a.id === NOTICE_AUTHOR_ID) return false;

            var isTargetAdmin = !!(a.id && scope.admins.map[a.id]);
            if (scope.scope === "admins" && !isTargetAdmin) {
                return false;
            }

            if (cfg.skipOwn && !isTargetAdmin && a.id && a.id === getMyUserId()) return false;

            var id = String(msg.id);
            if (!force && (seenIds[id] || persistedScannedSet[id])) return false;
            markSeen(id);

            var text = extractText(msg);
            var hasAttach = Array.isArray(msg.attachments) && msg.attachments.length > 0;
            var imageUrls = cfg.scanImages ? extractImageUrls(msg) : [];
            if (!text && imageUrls.length === 0) return false;

            var aiReady = hasAnyAiProvider();
            if (!aiReady) {
                state.lastError = "⚠️ لا يوجد مزوّد ذكاء اصطناعي جاهز — الفحص المحلي مقفل";
                delete seenIds[id];
                return false;
            }

            var enqueuedAny = false;
            if (imageUrls.length > 0) {
                enqueueImageItems(msg, chId, msgGuild, a, imageUrls, id, deferPump);
                enqueuedAny = true;
            }

            if (!text) return enqueuedAny;

            var replyCtx = extractReplyContext(msg);
            if (cfg.smartPreFilter && !force && !replyCtx && isObviouslyBenignText(text)) {
                state.scanned++;
                state.preFiltered = (state.preFiltered || 0) + 1;
                markPersistedScanned(id);
                emitState();
                return enqueuedAny;
            }

            var promptText = replyCtx
                ? (text + "\n[سياق الرد: \"" + replyCtx.replace(/"/g, "'") + "\"]")
                : text;

            var item = {
                messageId: id,
                channelId: chId,
                guildId: msgGuild,
                author: a,
                text: text,
                promptText: promptText,
                hasAttach: hasAttach,
                ts: msg.timestamp ? String(msg.timestamp) : new Date().toISOString()
            };

            queue.push(item);
            state.queued = queue.length;
            if (!deferPump) {
                emitState();
                schedulePump();
            }
            return true;
        } catch (e) {
            return false;
        }
    }

    var imageQueue = [];
    var imagePumpTimer = null;
    var activeImageWorkers = 0;
    var imageWorkerSeq = 0;
    var visionCooldowns = {};

    function isLikelyImageUrl(url, contentType, filename) {
        var ct = String(contentType || "").toLowerCase();
        if (ct.indexOf("image/") === 0) return true;
        var s = String(filename || url || "").toLowerCase().split("?")[0];
        return /\.(png|jpe?g|webp|gif|bmp|avif)$/i.test(s);
    }

    function extractImageUrls(msg) {
        var out = [];
        var seen = {};
        function pushUrl(u, ct, fn) {
            var s = String(u || "").trim();
            if (!s || !/^https?:\/\//i.test(s)) return;
            if (!isLikelyImageUrl(s, ct, fn)) return;
            if (seen[s]) return;
            seen[s] = true;
            out.push(s);
        }
        try {
            if (Array.isArray(msg.attachments)) {
                for (var i = 0; i < msg.attachments.length; i++) {
                    var att = msg.attachments[i];
                    if (!att) continue;
                    pushUrl(att.url || att.proxy_url, att.content_type || att.contentType, att.filename);
                }
            }
            if (Array.isArray(msg.embeds)) {
                for (var j = 0; j < msg.embeds.length; j++) {
                    var emb = msg.embeds[j];
                    if (!emb) continue;
                    if (emb.image && emb.image.url) pushUrl(emb.image.url, "image/png", "");
                    if (emb.thumbnail && emb.thumbnail.url) pushUrl(emb.thumbnail.url, "image/png", "");
                    if (emb.type === "image" && emb.url) pushUrl(emb.url, "image/png", "");
                }
            }
        } catch (e) {}
        return out;
    }

    var VISION_SYSTEM_PROMPT = [
        "أنت نظام فحص بصري لمحتوى صور ديسكورد لمساعدة مشرف بشري.",
        "افحص الصور المرقّمة بالترتيب (من 0 إلى N-1).",
        "ارصد فقط المخالفات الجسيمة الواضحة في الصور ضمن الفئات التالية:",
        "- sexual/minors: أي استغلال أو إساءة لقاصرين.",
        "- terrorism: شعارات أو ترويج لتنظيمات إرهابية أو عنف متطرف.",
        "- violence: عنف دموي شديد أو تعذيب أو قتل حقيقي.",
        "- illicit: مخدرات صريحة أو أسلحة غير مشروعة بغرض الترويج.",
        "- hate: رموز كراهية صريحة أو تحريض عنصري/ديني.",
        "- sexual: إباحية صريحة أو عري كامل.",
        "- harassment: قذف أو إهانة أو سب فاحش واضح في نص داخل الصورة.",
        "تنبيه مهم: تجاهل تماماً أي محتوى يتعلق بالانتحار أو إيذاء النفس (self-harm) أو التشهير والمعلومات الشخصية (doxxing) ولا تبلغ عنهما إطلاقاً.",
        "أرجع JSON فقط بدون أي نص إضافي:",
        "{\"flags\":[{\"i\":0,\"cats\":[\"sexual\"],\"score\":0.92,\"reason\":\"وصف مختصر بالعربية\"}]}",
        "وإذا كانت كل الصور سليمة أرجع: {\"flags\":[]}"
    ].join("\n");

    function parseVisionFlags(rawText, count, sourceLabel) {
        var txt = String(rawText || "").trim();
        txt = txt.replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
        var obj = null;
        try { obj = JSON.parse(txt); } catch (e) {
            var m = txt.match(/\{[\s\S]*\}/);
            if (m) {
                try { obj = JSON.parse(m[0]); } catch (e2) {}
            }
        }
        if (!obj || !Array.isArray(obj.flags)) {
            var err = new Error("تعذّر قراءة استجابة نموذج الصور (" + sourceLabel + ")");
            err.parseFail = true;
            throw err;
        }
        var out = [];
        for (var k = 0; k < obj.flags.length; k++) {
            var fl = obj.flags[k];
            if (!fl) continue;
            var idx = Number(fl.i);
            if (!(idx >= 0 && idx < count)) continue;
            var rawCats = Array.isArray(fl.cats) ? fl.cats : [];
            var cats = [];
            for (var c = 0; c < rawCats.length; c++) {
                var catName = String(rawCats[c] || "").trim().toLowerCase();
                if (catName === "self-harm" || catName === "doxxing") continue;
                if (CATS[catName] && cats.indexOf(catName) === -1) cats.push(catName);
            }
            if (cats.length === 0) continue;
            var sc = Number(fl.score);
            if (!(sc > 0 && sc <= 1)) sc = 0.88;
            out.push({
                i: idx,
                cats: cats,
                score: sc,
                reason: String(fl.reason || "صورة مخالفة").slice(0, 120)
            });
        }
        return out;
    }

    function getVisionProviderCandidates() {
        if (cfg.omnirouteOnly) {
            return isProviderReady("omniroute", false) ? ["omniroute"] : [];
        }
        var order = [cfg.provider, "omniroute", "gemini", "openrouter", "yepapi", "coarena", "groq", "openai", "grok", "custom"];
        var seen = {};
        var list = [];
        for (var i = 0; i < order.length; i++) {
            var pid = order[i];
            if (!pid || seen[pid] || pid === "local") continue;
            seen[pid] = true;
            var p = PROVIDERS[pid];
            if (!p || (!p.urlProp && !p.endpoint && pid !== "gemini")) continue;
            if (!isProviderReady(pid, pid !== cfg.provider)) continue;
            list.push(pid);
        }
        return list;
    }

    function getVisionModelsList() {
        var raw = String(cfg.visionModel || DEFAULTS.visionModel || "");
        var parts = raw.split(/[\n,;]+/);
        var out = [];
        for (var i = 0; i < parts.length; i++) {
            var m = String(parts[i] || "").trim();
            if (m && out.indexOf(m) === -1) out.push(m);
        }
        if (out.length === 0) out.push("antigravity/gemini-3-flash");
        return out;
    }

    function getProviderVisionModels(pid, rotatedOmniModels) {
        if (pid === "omniroute") return rotatedOmniModels;
        if (pid === "gemini") return ["gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash", "gemma-4-31b-it"];
        if (pid === "openrouter") return ["google/gemini-2.5-flash", "openai/gpt-4o-mini", "openai/gpt-4o", "anthropic/claude-3.5-sonnet"];
        if (pid === "yepapi") return ["google/gemini-3.8-flash", "google/gemini-2.5-flash", "openai/gpt-4o-mini", "meta-llama/llama-4-scout"];
        if (pid === "groq") return ["meta-llama/llama-4-scout-17b-16e-instruct", "llava-v1.5-7b-4096-preview"];
        if (pid === "coarena") return ["gemini-3-8-flash", "claude-sonnet-4-6", "gpt-4o"];
        if (pid === "openai") return ["gpt-4o-mini", "gpt-4o"];
        if (pid === "grok") return ["grok-2-vision-1212"];
        return rotatedOmniModels;
    }

    var B64_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    function bytesToBase64(u8) {
        var out = [];
        var len = u8.length;
        for (var i = 0; i < len; i += 3) {
            var b0 = u8[i];
            var b1 = (i + 1 < len) ? u8[i + 1] : 0;
            var b2 = (i + 2 < len) ? u8[i + 2] : 0;
            var n = (b0 << 16) | (b1 << 8) | b2;
            out.push(
                B64_CHARS[(n >>> 18) & 63] +
                B64_CHARS[(n >>> 12) & 63] +
                ((i + 1 < len) ? B64_CHARS[(n >>> 6) & 63] : "=") +
                ((i + 2 < len) ? B64_CHARS[n & 63] : "=")
            );
        }
        return out.join("");
    }

    function normalizeImageMime(ct, url) {
        var raw = String(ct || "").toLowerCase().split(";")[0].trim();
        if (raw === "image/jpg") raw = "image/jpeg";
        if (raw === "image/png" || raw === "image/jpeg" || raw === "image/webp") return raw;
        var cleanUrl = String(url || "").toLowerCase().split("?")[0];
        if (/\.png$/i.test(cleanUrl)) return "image/png";
        if (/\.webp$/i.test(cleanUrl)) return "image/webp";
        if (/\.(jpe?g)$/i.test(cleanUrl)) return "image/jpeg";
        return "";
    }

    function toCompactDiscordImageUrl(url) {
        var s = String(url || "").trim();
        if (/^https:\/\/cdn\.discordapp\.com\/attachments\//i.test(s)) {
            var mediaUrl = s.replace(/^https:\/\/cdn\.discordapp\.com\//i, "https://media.discordapp.net/");
            var sep = mediaUrl.indexOf("?") === -1 ? "?" : "&";
            return mediaUrl + sep + "format=webp&width=512&height=512";
        }
        return s;
    }

    function tryFetchImageOnce(targetUrl, fallbackMimeUrl) {
        return fetchWithTimeout(targetUrl, { method: "GET" }, 10000).then(function (r) {
            if (!r || !r.ok) return null;
            var ct = (r.headers && typeof r.headers.get === "function") ? r.headers.get("content-type") : "";
            var mime = normalizeImageMime(ct, fallbackMimeUrl || targetUrl);
            if (!mime) return null;
            if (typeof r.arrayBuffer === "function") {
                return r.arrayBuffer().then(function (buf) {
                    if (!buf || buf.byteLength === 0 || buf.byteLength > 1200 * 1024) return null;
                    var b64 = bytesToBase64(new Uint8Array(buf));
                    return { mime: mime, b64: b64, dataUri: "data:" + mime + ";base64," + b64 };
                });
            }
            return null;
        }).catch(function () {
            return null;
        });
    }

    function fetchImageAsDataUri(url) {
        var compactUrl = toCompactDiscordImageUrl(url);
        return tryFetchImageOnce(compactUrl, url).then(function (res) {
            if (res) return res;
            if (compactUrl !== url) return tryFetchImageOnce(url, url);
            return null;
        });
    }

    function visionModerate(imageItems, workerOffset) {
        if (!Array.isArray(imageItems) || imageItems.length === 0) {
            return Promise.resolve({ flags: [], route: "none" });
        }
        var providers = getVisionProviderCandidates();
        if (providers.length === 0) {
            return Promise.reject(new Error("لا يوجد مزوّد متاح يدعم فحص الصور (Vision)"));
        }
        var models = getVisionModelsList();
        var topSpan = Math.min(models.length, 4);
        var wOff = (typeof workerOffset === "number" && topSpan > 1) ? (workerOffset % topSpan) : 0;
        var siblingPrimaries = models.slice(0, topSpan).filter(function (_, idx2) { return idx2 !== wOff; });
        var rotatedModels = (topSpan > 0)
            ? [models[wOff]].concat(models.slice(topSpan)).concat(siblingPrimaries)
            : models.slice();

        return Promise.all(imageItems.map(function (it, origIdx) {
            return fetchImageAsDataUri(it.imageUrl).then(function (imgObj) {
                return imgObj ? { origIdx: origIdx, mime: imgObj.mime, b64: imgObj.b64, dataUri: imgObj.dataUri } : null;
            });
        })).then(function (resolvedList) {
            var validPairs = [];
            for (var v = 0; v < resolvedList.length; v++) {
                if (resolvedList[v]) validPairs.push(resolvedList[v]);
            }
            if (validPairs.length === 0) {
                return { flags: [], route: "skipped-unsupported" };
            }

            var nowTs = Date.now();
            var readyAttempts = [];
            var cooledAttempts = [];
            for (var pi = 0; pi < providers.length; pi++) {
                var pid = providers[pi];
                var pModels = getProviderVisionModels(pid, rotatedModels);
                var keys = getProviderKeys(pid);
                if (keys.length === 0 && PROVIDERS[pid].keyOptional) keys = [""];
                for (var mi = 0; mi < pModels.length; mi++) {
                    var modelId = pModels[mi];
                    var cdKey = pid + ":" + modelId;
                    var isCooled = !!(visionCooldowns[cdKey] && visionCooldowns[cdKey] > nowTs);
                    for (var ki = 0; ki < keys.length; ki++) {
                        var attObj = { pid: pid, model: modelId, apiKey: keys[ki], cdKey: cdKey };
                        if (isCooled) cooledAttempts.push(attObj);
                        else readyAttempts.push(attObj);
                    }
                }
            }
            var attempts = readyAttempts.concat(cooledAttempts);

            var idx = 0;
            var lastErr = null;
            function sendSubBatchOpenAI(att, pairsSlice, offsetBase) {
                var pInfo = PROVIDERS[att.pid];
                var endpoint = "";
                if (pInfo.urlProp) {
                    var baseUrl = String(cfg[pInfo.urlProp] || DEFAULTS[pInfo.urlProp] || "").trim().replace(/\/+$/, "");
                    if (!baseUrl) return Promise.reject(new Error("missing url"));
                    endpoint = /\/chat\/completions$/i.test(baseUrl) ? baseUrl : (baseUrl + "/chat/completions");
                } else if (pInfo.endpoint) {
                    endpoint = pInfo.endpoint;
                } else {
                    return Promise.reject(new Error("no endpoint"));
                }
                var headers = { "Content-Type": "application/json" };
                if (pInfo.extraHeaders) {
                    for (var hk in pInfo.extraHeaders) {
                        if (Object.prototype.hasOwnProperty.call(pInfo.extraHeaders, hk)) {
                            headers[hk] = pInfo.extraHeaders[hk];
                        }
                    }
                }
                if (att.apiKey) {
                    headers["Authorization"] = "Bearer " + att.apiKey;
                    if (pInfo.sendXApiKey) headers["X-API-Key"] = att.apiKey;
                }
                var userContent = [{
                    type: "text",
                    text: "افحص الصور التالية بالترتيب (0 إلى " + (pairsSlice.length - 1) + ") وأرجع JSON فقط:"
                }];
                for (var i = 0; i < pairsSlice.length; i++) {
                    userContent.push({
                        type: "image_url",
                        image_url: { url: pairsSlice[i].dataUri }
                    });
                }
                var payload = {
                    model: att.model,
                    temperature: 0,
                    max_tokens: 900,
                    messages: [
                        { role: "system", content: VISION_SYSTEM_PROMPT },
                        { role: "user", content: userContent }
                    ]
                };
                return fetchWithTimeout(endpoint, {
                    method: "POST",
                    headers: headers,
                    body: JSON.stringify(payload)
                }, 22000).then(function (r) {
                    if (!r.ok) {
                        return r.text().catch(function () { return ""; }).then(function (t) {
                            var e = new Error("Vision HTTP " + r.status + ": " + String(t || "").slice(0, 120));
                            e.status = r.status;
                            throw e;
                        });
                    }
                    return r.json();
                }).then(function (json) {
                    var ch0 = json && json.choices && json.choices[0] && json.choices[0].message;
                    var txt = "";
                    if (ch0) {
                        if (typeof ch0.content === "string") txt = ch0.content;
                        else if (Array.isArray(ch0.content)) {
                            txt = ch0.content.map(function (p) { return (p && p.text) ? p.text : ""; }).join("\n");
                        }
                    }
                    var flags = parseVisionFlags(txt, pairsSlice.length, pInfo.sourceName + " / " + att.model);
                    for (var fi = 0; fi < flags.length; fi++) {
                        flags[fi].i = validPairs[offsetBase + flags[fi].i].origIdx;
                    }
                    return flags;
                });
            }

            function sendGeminiNative(att) {
                var cleanModel = String(att.model || "gemini-2.5-flash").replace(/^models\//, "");
                var endpoint = "https://generativelanguage.googleapis.com/v1beta/models/" + encodeURIComponent(cleanModel) + ":generateContent?key=" + encodeURIComponent(att.apiKey);
                var parts = [{ text: VISION_SYSTEM_PROMPT + "\n\nافحص الصور التالية بالترتيب (0 إلى " + (validPairs.length - 1) + ") وأرجع JSON فقط:" }];
                for (var i = 0; i < validPairs.length; i++) {
                    parts.push({ inline_data: { mime_type: validPairs[i].mime, data: validPairs[i].b64 } });
                }
                return fetchWithTimeout(endpoint, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        contents: [{ role: "user", parts: parts }],
                        generationConfig: { temperature: 0, maxOutputTokens: 900 }
                    })
                }, 22000).then(function (r) {
                    if (!r.ok) {
                        return r.text().catch(function () { return ""; }).then(function (t) {
                            var e = new Error("Gemini Vision HTTP " + r.status + ": " + String(t || "").slice(0, 120));
                            e.status = r.status;
                            throw e;
                        });
                    }
                    return r.json();
                }).then(function (json) {
                    var cParts = json && json.candidates && json.candidates[0] && json.candidates[0].content && json.candidates[0].content.parts;
                    var txt = Array.isArray(cParts) ? cParts.map(function (p) { return (p && p.text) ? p.text : ""; }).join("\n") : "";
                    var flags = parseVisionFlags(txt, validPairs.length, "Gemini / " + cleanModel);
                    for (var fi = 0; fi < flags.length; fi++) {
                        flags[fi].i = validPairs[flags[fi].i].origIdx;
                    }
                    return flags;
                });
            }

            function tryNext() {
                if (stopped) return Promise.reject(new Error("stopped"));
                if (idx >= attempts.length) {
                    return Promise.reject(lastErr || new Error("فشل فحص الصور من جميع النماذج المتاحة"));
                }
                var att = attempts[idx++];
                var pInfo = PROVIDERS[att.pid];
                var runPromise;
                if (att.pid === "gemini") {
                    runPromise = sendGeminiNative(att);
                } else if (att.pid === "groq" && validPairs.length > 5) {
                    var halfA = validPairs.slice(0, 5);
                    var halfB = validPairs.slice(5, 10);
                    runPromise = sendSubBatchOpenAI(att, halfA, 0).then(function (fA) {
                        return sendSubBatchOpenAI(att, halfB, 5).then(function (fB) {
                            return fA.concat(fB);
                        });
                    });
                } else {
                    runPromise = sendSubBatchOpenAI(att, validPairs, 0);
                }
                return runPromise.then(function (flags) {
                    if (visionCooldowns[att.cdKey]) delete visionCooldowns[att.cdKey];
                    return { flags: flags, route: pInfo.sourceName + " • " + att.model };
                }).catch(function (err) {
                    lastErr = err;
                    // تصنيف مدة الـ cooldown بحسب نوع الخطأ
                    var status = Number(err && err.status) || 0;
                    var msg = String((err && err.message) || "").toLowerCase();
                    var cdMs;
                    if (status === 404 || /does not exist|not found|no such model|model.*not.*exist|not.*available/.test(msg)) {
                        // النموذج غير موجود نهائياً — ضعه في الـ cooldown يوماً كاملاً
                        cdMs = 24 * 60 * 60 * 1000;
                    } else if (status === 429 || /rate.?limit|too many|quota|exceeded/.test(msg)) {
                        // حد معدل أو حصة — انتظر 5 دقائق
                        cdMs = 5 * 60 * 1000;
                    } else if (status === 401 || status === 403 || /unauthorized|invalid.?key|revoked/.test(msg)) {
                        // مفتاح غير صالح — ساعة
                        cdMs = 60 * 60 * 1000;
                    } else {
                        // خطأ مؤقت — انتظر 90 ثانية
                        cdMs = 90 * 1000;
                    }
                    visionCooldowns[att.cdKey] = Date.now() + cdMs;
                    return tryNext();
                });
            }
            return tryNext();
        });
    }

    function enqueueImageItems(msg, chId, msgGuild, author, imageUrls, msgId, deferPump) {
        if (!Array.isArray(imageUrls) || imageUrls.length === 0) return;
        var ts = msg.timestamp ? String(msg.timestamp) : new Date().toISOString();
        for (var i = 0; i < imageUrls.length; i++) {
            imageQueue.push({
                messageId: String(msgId || (msg && msg.id) || ""),
                channelId: chId,
                guildId: msgGuild,
                author: author,
                imageUrl: imageUrls[i],
                ts: ts
            });
        }
        state.imageQueued = imageQueue.length;
        if (!deferPump) {
            emitState();
            scheduleImagePump(false);
        }
    }

    function getMaxImageWorkers() {
        return Math.max(1, Math.min(4, Number(cfg.imageParallelBatches) || 4));
    }

    function scheduleImagePump(forceFlush) {
        if (stopped || !cfg.scanImages || imageQueue.length === 0) return;
        var batchTarget = Math.max(1, Math.min(20, Number(cfg.imageBatchSize) || 10));
        var maxWorkers = getMaxImageWorkers();
        if (activeImageWorkers >= maxWorkers) return;
        if (imageQueue.length >= batchTarget) {
            if (imagePumpTimer) { clearTimeout(imagePumpTimer); imagePumpTimer = null; }
            pumpImages();
            return;
        }
        if (activeImageWorkers > 0) return;
        if (imagePumpTimer) clearTimeout(imagePumpTimer);
        imagePumpTimer = setTimeout(function () {
            imagePumpTimer = null;
            if (imageQueue.length >= batchTarget || forceFlush || !serverSearch.running) {
                pumpImages();
            }
        }, forceFlush ? 100 : 4000);
    }

    function pumpImages() {
        if (stopped || imageQueue.length === 0) return Promise.resolve();
        var batchTarget = Math.max(1, Math.min(20, Number(cfg.imageBatchSize) || 10));
        var maxWorkers = getMaxImageWorkers();
        var promises = [];

        function spawnImageWorker() {
            if (stopped || imageQueue.length === 0 || activeImageWorkers >= maxWorkers) return;
            var batch = imageQueue.splice(0, batchTarget);
            state.imageQueued = imageQueue.length;
            var myOffset = imageWorkerSeq++;
            if (imageWorkerSeq > 1000) imageWorkerSeq = 0;
            activeImageWorkers++;
            state.imageWorkers = activeImageWorkers;
            emitState();

            var p = visionModerate(batch, myOffset).then(function (res) {
                state.imagesScanned = (state.imagesScanned || 0) + batch.length;
                var flags = (res && Array.isArray(res.flags)) ? res.flags : [];
                for (var fi = 0; fi < flags.length; fi++) {
                    var f = flags[fi];
                    if (!f || !(f.i >= 0 && f.i < batch.length)) continue;
                    var it = batch[f.i];
                    var hits = [];
                    for (var ci = 0; ci < (f.cats || []).length; ci++) {
                        hits.push({ cat: f.cats[ci], score: f.score, reason: f.reason });
                    }
                    if (hits.length > 0) {
                        recordFinding({
                            messageId: it.messageId,
                            channelId: it.channelId,
                            guildId: it.guildId,
                            author: it.author,
                            text: "[صورة مرصودة] " + it.imageUrl,
                            ts: it.ts
                        }, hits, "Vision (" + (res.route || "AI") + ")");
                    }
                }
                for (var bi = 0; bi < batch.length; bi++) {
                    if (batch[bi].messageId) markPersistedScanned(batch[bi].messageId);
                }
                activeImageWorkers = Math.max(0, activeImageWorkers - 1);
                state.imageWorkers = activeImageWorkers;
                emitState();
                if (imageQueue.length >= batchTarget || (imageQueue.length > 0 && !serverSearch.running)) {
                    scheduleImagePump(true);
                }
            }).catch(function (err) {
                activeImageWorkers = Math.max(0, activeImageWorkers - 1);
                state.imageWorkers = activeImageWorkers;
                // لا نعدّ الصور مفحوصة عند الفشل — نُعيدها إلى الطابور للإعادة (بحد أقصى 3 محاولات/دفعة)
                var canRetry = false;
                for (var ri = 0; ri < batch.length; ri++) {
                    var item = batch[ri];
                    item._visionRetries = (item._visionRetries || 0) + 1;
                    if (item._visionRetries <= 3 && !stopped) {
                        // نُعيد إلى نهاية الطابور حتى لا تحجب الطابور الحالي
                        imageQueue.push(item);
                        canRetry = true;
                    } else {
                        // تجاوزت حد المحاولات: تسجيل باعتبارها "تم معالجتها" وتجاوزها
                        state.imagesScanned = (state.imagesScanned || 0) + 1;
                        if (item.messageId) markPersistedScanned(item.messageId);
                    }
                }
                state.imageQueued = imageQueue.length;
                state.lastScanWarning = "⚠️ تعذر فحص دفعة صور — سيتم إعادة المحاولة على نموذج آخر: " + sanitizeErrorMessage(err);
                emitState();
                if (!stopped && imageQueue.length > 0) {
                    // انتظر قليلاً ثم حاول مع نموذج آخر (cooldown يمنع النموذج الفاشل)
                    var retryDelay = canRetry ? 2000 : 5000;
                    if (imagePumpTimer) clearTimeout(imagePumpTimer);
                    imagePumpTimer = setTimeout(function () {
                        imagePumpTimer = null;
                        scheduleImagePump(true);
                    }, retryDelay);
                }
            });
            promises.push(p);
        }

        while (!stopped && activeImageWorkers < maxWorkers && imageQueue.length > 0) {
            spawnImageWorker();
            if (imageQueue.length < batchTarget && serverSearch.running) break;
        }
        return Promise.all(promises);
    }

    var pumpTimer = null;
    var activeWorkers = 0;

    function getMaxConcurrentBatches() {
        if (!cfg.parallelBatches) return 1;
        var maxLimit = Math.max(1, Math.min(8, Number(cfg.maxParallelBatches) || 6));
        var slotsCount = buildCandidateSlots().length;
        if (slotsCount > 1) {
            return Math.max(1, Math.min(maxLimit, slotsCount));
        }
        if (cfg.omnirouteOnly || cfg.provider === "omniroute") {
            return maxLimit;
        }
        return 1;
    }

    function getBatchTargetLimit() {
        var activeProvider = lastUsedProvider && isProviderReady(lastUsedProvider, lastUsedProvider !== cfg.provider) ? lastUsedProvider : cfg.provider;
        var pInfo = PROVIDERS[activeProvider] || {};
        var limit = Math.max(1, Number(cfg.batchSize) || 70);
        if (pInfo.maxBatch && limit > pInfo.maxBatch) limit = pInfo.maxBatch;
        return limit;
    }

    function schedulePump() {
        if (stopped || queue.length === 0) return;
        var maxW = getMaxConcurrentBatches();
        if (activeWorkers >= maxW) return;
        var limit = getBatchTargetLimit();
        var parallelCnt = Math.max(1, Math.min(8, maxW));
        var multiTarget = (limit <= 100 && parallelCnt > 1) ? (limit * parallelCnt) : limit;
        if (queue.length >= multiTarget) {
            if (pumpTimer) { clearTimeout(pumpTimer); pumpTimer = null; }
            pump(true);
            return;
        }
        // أثناء الجلب التاريخي ننتظر اكتمال التجميعة (4 × 70 = 280) أو انتهاء الجلب
        if (serverSearch.running || activeWorkers > 0) return;
        if (pumpTimer) clearTimeout(pumpTimer);
        pumpTimer = setTimeout(function () {
            pumpTimer = null;
            if (!serverSearch.running && queue.length >= limit) {
                pump(true);
            } else if (!serverSearch.running && queue.length > 0) {
                var sc = validateScanScope();
                if (sc.ok && sc.scope === "all" && sc.channelId) {
                    startAllMembersCrawl(true);
                } else {
                    pump(true);
                }
            }
        }, 15000);
    }

    function flushPumpNow() {
        if (pumpTimer) { clearTimeout(pumpTimer); pumpTimer = null; }
        if (!stopped && queue.length > 0 && activeWorkers < getMaxConcurrentBatches()) pump(true);
        if (!stopped && cfg.scanImages && imageQueue.length > 0 && activeImageWorkers < getMaxImageWorkers() && typeof pumpImages === "function") {
            pumpImages();
        }
    }

    function popNextBatch(providerId) {
        if (queue.length === 0) return [];
        var pInfo = PROVIDERS[providerId] || {};
        var limit = Math.max(1, Number(cfg.batchSize) || 70);
        if (pInfo.maxBatch && limit > pInfo.maxBatch) limit = pInfo.maxBatch;

        if (queue[0]._chunkId) {
            var cid = queue[0]._chunkId;
            var count = 0;
            while (count < queue.length && queue[count]._chunkId === cid && count < limit) count++;
            return queue.splice(0, count);
        }
        var n = 0;
        while (n < queue.length && n < limit && !queue[n]._chunkId) n++;
        return queue.splice(0, Math.max(1, n));
    }

    function handleFlaggedItem(item, hits, sourceLabel, firstSlotId) {
        if (!hits || !hits.length) return Promise.resolve();
        var hasDirectLocalRuleHit = localDetect(item.text).length > 0;
        if (!cfg.doubleCheckBorderline || hasDirectLocalRuleHit || buildCandidateSlots().length <= 1) {
            recordFinding(item, hits, sourceLabel);
            return Promise.resolve();
        }
        var verifyInput = [item.promptText || item.text];
        function runSecondCheck(attemptNum) {
            return moderateWithFailover(verifyInput, firstSlotId, true).then(function (out2) {
                var res2 = (out2 && out2.results && out2.results[0]) || [];
                if (res2.length > 0) {
                    var secondLabel = (out2 && out2.sourceLabel) || "AI#2";
                    for (var h = 0; h < hits.length; h++) {
                        hits[h].reason = (hits[h].reason || "") + " • [تأكيد مزدوج: " + secondLabel + "]";
                    }
                    recordFinding(item, hits, sourceLabel + " + " + secondLabel);
                } else {
                    state.hallucinationsBlocked = (state.hallucinationsBlocked || 0) + 1;
                    addDiagLog({ provider: (out2 && out2.sourceLabel) || "AI#2", model: "", ms: 0, count: 1, ok: true, detail: "رفض البلاغ في التأكيد المزدوج (سليم)" });
                    emitState();
                }
            }).catch(function (err) {
                if (attemptNum < 1 && !stopped) {
                    return sleep(1500).then(function () { return runSecondCheck(attemptNum + 1); });
                }
                // عند تعذّر اتصال النموذج الثاني لا نحذف البلاغ ولا نحسبه هلوسة، بل نسجله للمراجعة اليدوية
                for (var h2 = 0; h2 < hits.length; h2++) {
                    hits[h2].reason = (hits[h2].reason || "") + " • [تأكيد مزدوج تعذّر - يحتاج مراجعة يدوية]";
                }
                addDiagLog({ provider: sourceLabel, model: "", ms: 0, count: 1, ok: false, detail: "تعذّر التأكيد المزدوج — سُجّل للمراجعة اليدوية (" + sanitizeErrorMessage((err && err.message) || err) + ")" });
                recordFinding(item, hits, sourceLabel + " [مراجعة يدوية]");
            });
        }
        return runSecondCheck(0);
    }

    var workerSeq = 0;

    function pump(forcePartial) {
        if (stopped || queue.length === 0) return;
        var maxW = getMaxConcurrentBatches();
        if (activeWorkers >= maxW) return;
        if (pumpTimer) { clearTimeout(pumpTimer); pumpTimer = null; }
        if (cfg.scanImages && imageQueue.length > 0 && typeof scheduleImagePump === "function") {
            scheduleImagePump(false);
        }

        function spawnWorker(allowPartialFirst) {
            if (stopped || queue.length === 0 || activeWorkers >= getMaxConcurrentBatches()) return;
            var targetLimit = getBatchTargetLimit();
            if (!allowPartialFirst && serverSearch.running && queue.length < targetLimit && !(queue[0] && queue[0]._chunkId)) {
                if (activeWorkers === 0) schedulePump();
                return;
            }
            var myWorkerOffset = workerSeq++;
            if (workerSeq > 1000) workerSeq = 0;
            activeWorkers++;
            running = activeWorkers > 0;
            state.inFlightBatches = activeWorkers;
            state.busy = true;
            emitState();

            var allowPartial = !!allowPartialFirst;
            var loop = function () {
                if (stopped || queue.length === 0 || !cfg.enabled || !hasAnyAiProvider()) {
                    activeWorkers = Math.max(0, activeWorkers - 1);
                    running = activeWorkers > 0;
                    state.inFlightBatches = activeWorkers;
                    state.busy = activeWorkers > 0;
                    state.queued = queue.length;
                    emitState();
                    return;
                }
                var tLimit = getBatchTargetLimit();
                if (!allowPartial && serverSearch.running && queue.length < tLimit && !(queue[0] && queue[0]._chunkId)) {
                    activeWorkers = Math.max(0, activeWorkers - 1);
                    running = activeWorkers > 0;
                    state.inFlightBatches = activeWorkers;
                    state.busy = activeWorkers > 0;
                    emitState();
                    schedulePump();
                    return;
                }
                var wasPartialRun = allowPartial;
                allowPartial = false;

                var activeProvider = lastUsedProvider && isProviderReady(lastUsedProvider) ? lastUsedProvider : cfg.provider;
                var batch = popNextBatch(activeProvider);
                if (batch.length === 0) {
                    activeWorkers = Math.max(0, activeWorkers - 1);
                    running = activeWorkers > 0;
                    state.inFlightBatches = activeWorkers;
                    state.busy = activeWorkers > 0;
                    emitState();
                    return;
                }
                state.lastBatchSize = batch.length;
                state.queued = queue.length;
                var texts = batch.map(function (b) { return b.promptText || b.text; });

                // إطلاق العامل الموازي التالي على نموذج مختلف فور وجود رسائل متبقية (50 لكل نموذج عند الدفع المجمع)
                if ((queue.length >= tLimit || (wasPartialRun && queue.length > 0)) && activeWorkers < getMaxConcurrentBatches()) {
                    spawnWorker(wasPartialRun);
                }

                moderateWithFailover(texts, "", false, myWorkerOffset).then(function (out) {
                    state.lastError = "";
                    var results = (out && out.results) || [];
                    var sourceLabel = (out && out.sourceLabel) || "AI";
                    var slotId = (out && out.slotId) || "";
                    var checks = [];
                    for (var i = 0; i < batch.length; i++) {
                        state.scanned++;
                        markPersistedScanned(batch[i].messageId);
                        var hits = results[i] || [];
                        if (hits.length) {
                            checks.push(handleFlaggedItem(batch[i], hits, sourceLabel, slotId));
                        }
                    }
                    return checks.length ? Promise.all(checks) : null;
                }).catch(function (err) {
                    if (err && err.strictLockAbort) {
                        var droppedInAbort = 0;
                        for (var sq = batch.length - 1; sq >= 0; sq--) {
                            batch[sq]._retries = (batch[sq]._retries || 0) + 1;
                            if (batch[sq]._retries <= 2) {
                                queue.unshift(batch[sq]);
                            } else {
                                delete seenIds[batch[sq].messageId];
                                droppedInAbort++;
                            }
                        }
                        state.queued = queue.length;
                        state.lastError = sanitizeErrorMessage((err && err.message) || err);
                        if (droppedInAbort > 0) {
                            state.unreviewedCount = (state.unreviewedCount || 0) + droppedInAbort;
                            state.lastScanWarning = "⚠️ " + state.lastError;
                        }
                        if (serverSearch.running) {
                            serverSearch.running = false;
                            state.serverSearchRunning = false;
                            serverSearch.status = "⚠️ " + state.lastError;
                        }
                        emitState(true);
                        return;
                    }
                    if (err && err.blocked) {
                        if (batch.length > 1) {
                            var mid = Math.floor(batch.length / 2);
                            var leftId = nextChunkId++;
                            var rightId = nextChunkId++;
                            for (var r = batch.length - 1; r >= mid; r--) {
                                batch[r]._chunkId = rightId;
                                queue.unshift(batch[r]);
                            }
                            for (var l = mid - 1; l >= 0; l--) {
                                batch[l]._chunkId = leftId;
                                queue.unshift(batch[l]);
                            }
                        } else {
                            state.scanned++;
                            markPersistedScanned(batch[0].messageId);
                            recordFinding(batch[0], [{ cat: "blocked", score: 1, quoteVerified: true, reason: "نموذج الذكاء الاصطناعي حجب التحليل: " + sanitizeErrorMessage(err.blocked) }], state.activeRoute || "AI");
                        }
                    } else if (err && err.allCooldown) {
                        var waitMs = Math.max(10000, Math.min(60000, Number(err.waitMs) || 25000));
                        state.lastError = "⏳ انتهت حصة كل المفاتيح مؤقتاً — إعادة المحاولة بعد " + Math.ceil(waitMs / 1000) + " ث…";
                        for (var q = batch.length - 1; q >= 0; q--) {
                            queue.unshift(batch[q]);
                        }
                        state.queued = queue.length;
                        emitState();
                        return sleep(waitMs);
                    } else {
                        var safeErrMsg = sanitizeErrorMessage((err && err.message) || err);
                        state.lastError = safeErrMsg;
                        var requeued = false;
                        var droppedUnreviewed = 0;
                        for (var rq = batch.length - 1; rq >= 0; rq--) {
                            batch[rq]._retries = (batch[rq]._retries || 0) + 1;
                            if (batch[rq]._retries <= 2) {
                                queue.unshift(batch[rq]);
                                requeued = true;
                            } else {
                                delete seenIds[batch[rq].messageId];
                                droppedUnreviewed++;
                            }
                        }
                        if (droppedUnreviewed > 0) {
                            state.unreviewedCount = (state.unreviewedCount || 0) + droppedUnreviewed;
                            state.lastScanWarning = "⚠️ تعذّر فحص " + state.unreviewedCount + " رسالة (" + (safeErrMsg || "استجابة غير مفهومة/خطأ شبكة") + ") — لم تُحسب نظيفة وبقيت قابلة لإعادة الفحص.";
                            emitState(true);
                        }
                        if (requeued) return sleep(5000);
                    }
                }).then(function () {
                    emitState();
                    return sleep(REQUEST_GAP_MS);
                }).then(loop, loop);
            };
            loop();
        }

        spawnWorker(!!forcePartial);
    }

    // ===================== تسجيل النتائج =====================
    function pickPrimary(hits) {
        var best = null;
        for (var i = 0; i < hits.length; i++) {
            var c = CATS[hits[i].cat];
            if (!c) continue;
            if (!best || c.severity > CATS[best.cat].severity || (c.severity === CATS[best.cat].severity && hits[i].score > best.score)) best = hits[i];
        }
        return best;
    }

    function recordFinding(item, hits, source) {
        var primary = pickPrimary(hits);
        if (!primary) return;
        var list = cfg.findings || [];
        for (var i = 0; i < list.length; i++) {
            if (list[i].messageId === item.messageId) {
                if (CATS[primary.cat].severity > (CATS[list[i].cat] ? CATS[list[i].cat].severity : 0)) {
                    list[i].cat = primary.cat;
                    list[i].score = primary.score;
                    list[i].reason = primary.reason;
                    list[i].source = source;
                    saveCfg({ findings: list.slice() });
                }
                return;
            }
        }
        var info = getChannelInfo(item.channelId);
        var finalGuildId = info.guildId || item.guildId || null;
        var finalGuildName = info.guildName || (finalGuildId ? getGuildName(finalGuildId) : "");
        var cat = CATS[primary.cat];
        var snippet;
        if (cat.hideSnippet) {
            snippet = "[النص مخفي لحمايتك]";
        } else {
            var rawSnippet = item.text.replace(/\s+/g, " ").slice(0, 160);
            if (primary.cat === "doxxing") {
                rawSnippet = rawSnippet
                    .replace(/\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g, "[IP مخفي]")
                    .replace(/\+?\d[\d\s\-]{8,}\d/g, "[رقم مخفي]");
            }
            snippet = rawSnippet;
        }
        var f = {
            messageId: item.messageId,
            channelId: item.channelId,
            guildId: finalGuildId,
            guildName: finalGuildName,
            channelName: info.channelName,
            typeLabel: info.typeLabel,
            authorId: item.author.id,
            authorName: item.author.name,
            authorUsername: item.author.username,
            authorBot: item.author.bot,
            ts: item.ts,
            cat: primary.cat,
            allCats: hits.map(function (h) { return h.cat; }).filter(function (v, idx, arr) { return arr.indexOf(v) === idx; }),
            score: primary.score,
            reason: primary.reason,
            source: source,
            snippet: snippet,
            hasAttach: item.hasAttach,
            forwarded: false,
            foundAt: Date.now()
        };
        list = [f].concat(list).slice(0, MAX_FINDINGS);
        state.flagged++;
        saveCfg({ findings: list });

        var where = (finalGuildName ? finalGuildName + " / " : "") + info.channelName;
        if (cfg.toast) showToast("🛡️ حارس بحر: " + cat.label + " — " + where);
        if (cfg.inChatNotice && item.channelId && item.channelId === getCurrentChannelId()) {
            postLocalNotice(item.channelId, f);
        }
        if (cfg.autoForward && extractSingleIdOrWebhook(cfg.reportChannelId)) {
            enqueueForward(f, false);
        }
    }

    function postLocalNotice(channelId, f) {
        var cat = CATS[f.cat];
        var content =
            "🛡️ **حارس بحر** رصد رسالة مخالفة من **" + f.authorName + "**\n" +
            "النوع: **" + cat.label + "**\n" +
            "سبب المنع: " + (f.reason || cat.label) + "\n" +
            "طريقة الإبلاغ: " + cat.steps.join(" ← ") +
            (cat.extra ? "\n" + cat.extra : "") +
            "\n" + messageLink(f) +
            "\n-# (هذا التنبيه يظهر لك وحدك ولا يُرسل لأحد)";
        var msgObj = {
            id: String(Date.now()) + String(Math.floor(Math.random() * 1000)),
            type: 0,
            channel_id: channelId,
            content: content,
            timestamp: new Date().toISOString(),
            edited_timestamp: null,
            tts: false,
            mention_everyone: false,
            mentions: [],
            mention_roles: [],
            attachments: [],
            embeds: [],
            pinned: false,
            flags: 64,
            state: "SENT",
            _bahrGuard: true,
            author: {
                id: NOTICE_AUTHOR_ID,
                username: "حارس بحر",
                global_name: "حارس بحر 🛡️",
                discriminator: "0000",
                avatar: null,
                bot: true
            }
        };
        setTimeout(function () {
            try {
                if (mods.MessageActions && typeof mods.MessageActions.receiveMessage === "function") {
                    mods.MessageActions.receiveMessage(channelId, msgObj);
                    return;
                }
            } catch (e) {}
            try {
                if (mods.Dispatcher) {
                    mods.Dispatcher.dispatch({ type: "MESSAGE_CREATE", channelId: channelId, message: msgObj, optimistic: false, isPushNotification: false, _bahrGuard: true });
                }
            } catch (e) {}
        }, 300);
    }

    function scanChannel(channelId, force) {
        var n = 0;
        try {
            if (!mods.MessageStore || !channelId) return 0;
            var msgs = mods.MessageStore.getMessages(channelId);
            var arr = msgs && (msgs._array || (typeof msgs.toArray === "function" ? msgs.toArray() : null));
            if (!Array.isArray(arr)) return 0;
            for (var i = 0; i < arr.length; i++) {
                if (enqueueMessage(arr[i], channelId, force)) n++;
            }
        } catch (e) {}
        return n;
    }

    function enqueueMessageArray(rawList, fallbackChannelId) {
        if (!Array.isArray(rawList)) return;
        var added = 0;
        for (var i = 0; i < rawList.length; i++) {
            var entry = rawList[i];
            if (Array.isArray(entry)) {
                for (var j = 0; j < entry.length; j++) {
                    var sub = entry[j];
                    if (sub && sub.id && enqueueMessage(sub, fallbackChannelId || sub.channel_id || sub.channelId, false, true)) added++;
                }
            } else if (entry && entry.id) {
                if (enqueueMessage(entry, fallbackChannelId || entry.channel_id || entry.channelId, false, true)) added++;
            }
        }
        if (added > 0) {
            emitState();
            schedulePump();
            scheduleImagePump(false);
        }
    }

    // ===================== التشغيل =====================
    exports.default = plugin({
        jsonStorage: {
            load: true,
            default: JSON.parse(JSON.stringify(DEFAULTS))
        },
        start: function (ctx) {
            stopped = false;
            var cleanup = ctx.cleanup;
            var finders = valenced.modules.finders;
            var filters = finders.filters;
            var patcher = valenced.patcher;

            storageRef = ctx.jsonStorage || null;
            var autoResumedOnce = false;
            var applyLoaded = function (c) {
                if (!c || typeof c !== "object") return;
                for (var k in DEFAULTS) {
                    if (Object.prototype.hasOwnProperty.call(DEFAULTS, k) && c[k] !== undefined && typeof c[k] === typeof DEFAULTS[k]) {
                        cfg[k] = c[k];
                    }
                }
                if (!PROVIDERS[cfg.provider] || cfg.provider === "local" || (PROVIDERS[cfg.provider] && PROVIDERS[cfg.provider].locked)) {
                    cfg.provider = "omniroute";
                }
                cfg.localAlways = false;
                if (!cfg.omnirouteModel || String(cfg.omnirouteModel).trim() === "auto") {
                    cfg.omnirouteModel = DEFAULTS.omnirouteModel;
                }
                if (cfg.coarenaModel && cfg.coarenaModel.indexOf("gemini-4-argon") !== -1) {
                    cfg.coarenaModel = DEFAULTS.coarenaModel;
                }
                if (!cfg.groqModel || cfg.groqModel === "llama-3.3-70b-versatile" || cfg.groqModel.indexOf("allam-2-7b") !== -1) {
                    cfg.groqModel = DEFAULTS.groqModel;
                    try { saveCfg({ groqModel: DEFAULTS.groqModel }); } catch (e) {}
                }
                if (!cfg.geminiModel || cfg.geminiModel.indexOf("gemini-2.5-flash") !== -1) {
                    cfg.geminiModel = DEFAULTS.geminiModel;
                }
                if (cfg.auditMode !== "server_ban" && cfg.auditMode !== "all") cfg.auditMode = "server_ban";
                if (!cfg._v23BatchMigrated) {
                    cfg.batchSize = 70;
                    cfg._v23BatchMigrated = true;
                }
                if (!c._v25Split70Migrated) {
                    cfg.batchSize = 70;
                    cfg.parallelBatches = true;
                    cfg.doubleCheckBorderline = true;
                    cfg.omnirouteModel = DEFAULTS.omnirouteModel;
                    cfg._v25Split70Migrated = true;
                    try {
                        saveCfg({
                            batchSize: 70,
                            parallelBatches: true,
                            doubleCheckBorderline: true,
                            omnirouteModel: DEFAULTS.omnirouteModel,
                            _v25Split70Migrated: true
                        });
                    } catch (e) {}
                }
                if (!c._v25StrongVisionMigrated) {
                    cfg.omnirouteModel = DEFAULTS.omnirouteModel;
                    cfg.coarenaModel = DEFAULTS.coarenaModel;
                    cfg.geminiModel = DEFAULTS.geminiModel;
                    cfg.groqModel = DEFAULTS.groqModel;
                    cfg.openrouterModel = DEFAULTS.openrouterModel;
                    cfg.grokModel = DEFAULTS.grokModel;
                    if (typeof cfg.scanImages !== "boolean") cfg.scanImages = true;
                    if (!cfg.visionModel) cfg.visionModel = DEFAULTS.visionModel;
                    if (!(cfg.imageBatchSize >= 1 && cfg.imageBatchSize <= 20)) cfg.imageBatchSize = 10;
                    cfg._v25StrongVisionMigrated = true;
                    try {
                        saveCfg({
                            omnirouteModel: DEFAULTS.omnirouteModel,
                            coarenaModel: DEFAULTS.coarenaModel,
                            geminiModel: DEFAULTS.geminiModel,
                            groqModel: DEFAULTS.groqModel,
                            openrouterModel: DEFAULTS.openrouterModel,
                            grokModel: DEFAULTS.grokModel,
                            scanImages: cfg.scanImages,
                            visionModel: cfg.visionModel,
                            imageBatchSize: cfg.imageBatchSize,
                            _v25StrongVisionMigrated: true
                        });
                    } catch (e) {}
                }
                if (!c._v25ParallelVision40Migrated) {
                    cfg.omnirouteModel = DEFAULTS.omnirouteModel;
                    cfg.coarenaModel = DEFAULTS.coarenaModel;
                    cfg.yepapiModel = DEFAULTS.yepapiModel;
                    cfg.geminiModel = DEFAULTS.geminiModel;
                    cfg.groqModel = DEFAULTS.groqModel;
                    cfg.grokModel = DEFAULTS.grokModel;
                    cfg.openrouterModel = DEFAULTS.openrouterModel;
                    cfg.visionModel = DEFAULTS.visionModel;
                    cfg.imageBatchSize = 10;
                    cfg.imageParallelBatches = 4;
                    cfg._v25ParallelVision40Migrated = true;
                    try {
                        saveCfg({
                            omnirouteModel: DEFAULTS.omnirouteModel,
                            coarenaModel: DEFAULTS.coarenaModel,
                            yepapiModel: DEFAULTS.yepapiModel,
                            geminiModel: DEFAULTS.geminiModel,
                            groqModel: DEFAULTS.groqModel,
                            grokModel: DEFAULTS.grokModel,
                            openrouterModel: DEFAULTS.openrouterModel,
                            visionModel: DEFAULTS.visionModel,
                            imageBatchSize: 10,
                            imageParallelBatches: 4,
                            _v25ParallelVision40Migrated: true
                        });
                    } catch (e) {}
                }
                if (!c._v25GeminiWebMigrated) {
                    cfg.omnirouteModel = DEFAULTS.omnirouteModel;
                    cfg.visionModel = DEFAULTS.visionModel;
                    cfg._v25GeminiWebMigrated = true;
                    try {
                        saveCfg({
                            omnirouteModel: DEFAULTS.omnirouteModel,
                            visionModel: DEFAULTS.visionModel,
                            _v25GeminiWebMigrated: true
                        });
                    } catch (e) {}
                }
                if (!c._v26HydrogenLockMigrated) {
                    cfg.provider = "omniroute";
                    cfg.omnirouteModel = DEFAULTS.omnirouteModel;
                    cfg.omnirouteOnly = true;
                    cfg.autoFailoverProviders = false;
                    cfg.tieredPipeline = false;
                    cfg.strictModelLock = true;
                    cfg.batchSize = 100;
                    cfg.reasoningEffort = "low";
                    cfg._v26HydrogenLockMigrated = true;
                    try {
                        saveCfg({
                            provider: "omniroute",
                            omnirouteModel: DEFAULTS.omnirouteModel,
                            omnirouteOnly: true,
                            autoFailoverProviders: false,
                            tieredPipeline: false,
                            strictModelLock: true,
                            batchSize: 100,
                            reasoningEffort: "low",
                            _v26HydrogenLockMigrated: true
                        });
                    } catch (e) {}
                }
                if (!(cfg.batchSize >= 5 && cfg.batchSize <= 300)) cfg.batchSize = 100;
                if (!(cfg.searchDepth >= 25 && cfg.searchDepth <= 5000)) cfg.searchDepth = 200;
                if (!Array.isArray(cfg.findings)) cfg.findings = [];
                if (cfg.findings.length > MAX_FINDINGS) cfg.findings = cfg.findings.slice(0, MAX_FINDINGS);
                if (!Array.isArray(cfg.scannedIds)) cfg.scannedIds = [];
                if (cfg.scannedIds.length > MAX_PERSISTED_SCANNED) {
                    cfg.scannedIds = cfg.scannedIds.slice(-MAX_PERSISTED_SCANNED);
                }
                if (!cfg.adminNames || typeof cfg.adminNames !== "object" || Array.isArray(cfg.adminNames)) cfg.adminNames = {};
                if (!cfg.searchProgress || typeof cfg.searchProgress !== "object" || !cfg.searchProgress.admins || typeof cfg.searchProgress.admins !== "object") {
                    cfg.searchProgress = emptyProgress("");
                }
                if (cfg.memberScope !== "all" && cfg.memberScope !== "admins") cfg.memberScope = "admins";
                if (!cfg.memberCrawl || typeof cfg.memberCrawl !== "object" || !cfg.memberCrawl.channels || typeof cfg.memberCrawl.channels !== "object") {
                    cfg.memberCrawl = emptyCrawl("");
                }

                for (var nKey in cfg.adminNames) {
                    if (Object.prototype.hasOwnProperty.call(cfg.adminNames, nKey) && cfg.adminNames[nKey]) {
                        nameCache[nKey] = String(cfg.adminNames[nKey]);
                    }
                }
                for (var s = 0; s < cfg.scannedIds.length; s++) {
                    var sid = String(cfg.scannedIds[s] || "");
                    if (sid) {
                        persistedScannedSet[sid] = 1;
                        markSeen(sid);
                    }
                }
                for (var i = 0; i < cfg.findings.length; i++) {
                    markSeen(cfg.findings[i].messageId);
                    if (cfg.findings[i].forwarded) forwardedSet[cfg.findings[i].messageId] = true;
                }
                var initScope = validateScanScope();
                state.scopeBlockedReason = initScope.ok ? "" : initScope.reason;
                emitState();

                if (!autoResumedOnce && cfg.enabled && !serverSearch.running && initScope.ok) {
                    if (initScope.scope === "all" && initScope.channelId) {
                        autoResumedOnce = true;
                        setTimeout(function () {
                            if (!stopped && cfg.enabled && !serverSearch.running) {
                                startAllMembersCrawl(false);
                            }
                        }, 1200);
                    } else if (cfg.autoResumeSearch && initScope.scope === "admins" && initScope.admins.count > 0) {
                        var sum = getSearchSummary(initScope.guildId, initScope.admins.list, cfg.searchDepth);
                        if (sum.hasProgress && !sum.allDone) {
                            autoResumedOnce = true;
                            setTimeout(function () {
                                if (!stopped && cfg.enabled && !serverSearch.running) {
                                    startServerAdminSearch(false);
                                }
                            }, 5000);
                        }
                    }
                }
            };
            if (storageRef) {
                if (storageRef.cache) applyLoaded(storageRef.cache);
                if (typeof storageRef.get === "function") {
                    Promise.resolve(storageRef.get()).then(applyLoaded).catch(function () {});
                }
            }

            try {
                var d = valenced.discord;
                if (d) {
                    if (d.rest) mods.RestAPI = d.rest;
                    if (d.common && d.common.RestAPI && !mods.RestAPI) mods.RestAPI = d.common.RestAPI;
                    if (d.common && d.common.flux && d.common.flux.Dispatcher) mods.Dispatcher = d.common.flux.Dispatcher;
                    if (d.flux && d.flux.Stores) {
                        var S = d.flux.Stores;
                        if (S.UserStore) mods.UserStore = S.UserStore;
                        if (S.GuildMemberStore) mods.GuildMemberStore = S.GuildMemberStore;
                        if (S.ChannelStore) mods.ChannelStore = S.ChannelStore;
                        if (S.GuildChannelStore) mods.GuildChannelStore = S.GuildChannelStore;
                        if (S.GuildStore) mods.GuildStore = S.GuildStore;
                        if (S.SelectedChannelStore) mods.SelectedChannelStore = S.SelectedChannelStore;
                        if (S.MessageStore) mods.MessageStore = S.MessageStore;
                    }
                }
            } catch (e) {}

            try {
                cleanup(finders.getModules(filters.withProps("get", "post", "put", "del"), function (m) {
                    if (m && typeof m.post === "function" && typeof m.get === "function") {
                        if (!mods.RestAPI || typeof m.getAPIBaseURL === "function" || typeof m.patch === "function") {
                            mods.RestAPI = m;
                        }
                    }
                }));
            } catch (e) {}

            var take = function (key, props, check) {
                try {
                    cleanup(finders.getModules(filters.withProps.apply(null, props), function (m) {
                        if (!m) return;
                        if (check && !check(m)) return;
                        if (!mods[key]) mods[key] = m;
                    }));
                } catch (e) {}
            };
            take("UserStore", ["getCurrentUser", "getUser"]);
            take("GuildMemberStore", ["getMember", "getNick"]);
            take("ChannelStore", ["getChannel", "getDMFromUserId"]);
            take("GuildChannelStore", ["getChannels", "getDefaultChannel"]);
            take("GuildStore", ["getGuild", "getGuilds"]);
            take("SelectedChannelStore", ["getChannelId", "getVoiceChannelId"]);
            take("MessageStore", ["getMessage", "getMessages"]);
            take("Toast", ["showToast"]);
            take("MessageActions", ["sendMessage", "receiveMessage"]);
            take("Router", ["transitionTo"], function (m) { return typeof m.transitionTo === "function"; });
            take("URLOpener", ["openURL"], function (m) { return typeof m.openURL === "function"; });
            take("Clipboard", ["setString", "getString"]);

            var hooked = false;
            var hook = function (fd) {
                if (hooked || !fd || typeof fd.dispatch !== "function") return;
                hooked = true;
                mods.Dispatcher = fd;
                try {
                    cleanup(patcher.before(fd, "dispatch", function (args) {
                        try {
                            if (stopped || !cfg.enabled) return args;
                            var action = Array.isArray(args) ? args[0] : args;
                            if (!action || action._bahrGuard || action._arTranslated) return args;
                            if (action.type === "MESSAGE_CREATE" && action.message && cfg.scanNew && !action.optimistic) {
                                var m = action.message;
                                var cid = action.channelId || m.channel_id || m.channelId;
                                setTimeout(function () { enqueueMessage(m, cid, false); }, 0);
                            } else if (action.type === "MESSAGE_UPDATE" && action.message && cfg.scanNew) {
                                var mu = action.message;
                                var ucid = action.channelId || mu.channel_id || mu.channelId;
                                setTimeout(function () { enqueueMessage(mu, ucid, true); }, 0);
                            } else if (action.type === "LOAD_MESSAGES_SUCCESS" && Array.isArray(action.messages) && cfg.scanLoaded) {
                                var list = action.messages.slice();
                                var lcid = action.channelId;
                                setTimeout(function () { enqueueMessageArray(list, lcid); }, 0);
                            } else if ((action.type === "SEARCH_FINISH" || action.type === "SEARCH_MESSAGES_SUCCESS") && cfg.scanLoaded) {
                                var sm = action.messages || (action.data && action.data.messages);
                                if (Array.isArray(sm)) {
                                    var smCopy = sm.slice();
                                    setTimeout(function () { enqueueMessageArray(smCopy, ""); }, 0);
                                }
                            }
                        } catch (e) {}
                        return args;
                    }));
                } catch (e) {}
            };
            if (mods.Dispatcher) hook(mods.Dispatcher);
            try {
                cleanup(finders.getModules(filters.withProps("_interceptors", "dispatch"), function (m) { hook(m); }));
            } catch (e) {}

            cleanup(function () {
                stopped = true;
                serverSearch.stopRequested = true;
                if (scannedSaveTimer) {
                    clearTimeout(scannedSaveTimer);
                    scannedSaveTimer = null;
                    try { saveCfg({ scannedIds: (cfg.scannedIds || []).slice(-MAX_PERSISTED_SCANNED) }); } catch (e) {}
                }
                if (nameSaveTimer) {
                    clearTimeout(nameSaveTimer);
                    nameSaveTimer = null;
                }
                if (pumpTimer) {
                    clearTimeout(pumpTimer);
                    pumpTimer = null;
                }
                if (imagePumpTimer) {
                    clearTimeout(imagePumpTimer);
                    imagePumpTimer = null;
                }
                if (emitThrottleTimer) {
                    clearTimeout(emitThrottleTimer);
                    emitThrottleTimer = null;
                    emitPending = false;
                }
                queue.length = 0;
                imageQueue.length = 0;
                activeImageWorkers = 0;
                visionCooldowns = {};
                forwardQueue.length = 0;
                state.queued = 0;
                state.imageQueued = 0;
                state.imageWorkers = 0;
                state.forwardQueued = 0;
                state.busy = false;
            });
        },

        // ===================== واجهة الإعدادات =====================
        SettingsComponent: function (props) {
            var R = getReact();
            var RN = getRN();
            if (!R || !RN) return null;
            if (!storageRef && props && props.api && props.api.jsonStorage) {
                storageRef = props.api.jsonStorage;
            }
            var View = RN.View, Text = RN.Text, ScrollView = RN.ScrollView, TouchableOpacity = RN.TouchableOpacity, TextInput = RN.TextInput;
            var h = R.createElement;

            var tick = R.useState(0);
            R.useEffect(function () {
                return subscribeState(function () { tick[1](function (n) { return n + 1; }); });
            }, []);

            var filterState = R.useState("all");
            var filter = filterState[0], setFilter = filterState[1];
            var keyDraft = R.useState(null);
            var modelDraft = R.useState(null);
            var urlDraft = R.useState(null);
            var discoveredModels = R.useState([]);
            var adminsDraft = R.useState(null);
            var guildDraft = R.useState(null);
            var channelDraft = R.useState(null);
            var reportChDraft = R.useState(null);
            var customKwDraft = R.useState("");
            var selfTestMsg = R.useState("");
            var showGroups = R.useState(false);
            var showAdminList = R.useState(false);
            var showDiag = R.useState(false);
            var expanded = R.useState(null);
            var testState = R.useState("");
            var testStatus = testState[0], setTestStatus = testState[1];
            var fwdTestState = R.useState("");
            var fwdTestStatus = fwdTestState[0], setFwdTestStatus = fwdTestState[1];

            var card = { backgroundColor: "#2B2D31", borderRadius: 10, padding: 14, gap: 10 };
            var title = { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" };
            var small = { fontSize: 12, color: "#B5BAC1", textAlign: "right" };
            var inputStyle = { backgroundColor: "#111214", color: "#FFFFFF", padding: 10, borderRadius: 8, textAlign: "left" };
            function btn(bg, extra) {
                return Object.assign({ backgroundColor: bg, paddingVertical: 10, paddingHorizontal: 12, borderRadius: 8, alignItems: "center", justifyContent: "center" }, extra || {});
            }
            function button(label, bg, onPress, extra) {
                return h(TouchableOpacity, { onPress: onPress, style: btn(bg, extra) },
                    h(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 13, textAlign: "center" } }, label)
                );
            }
            function toggle(label, key, hint) {
                var on = !!cfg[key];
                return h(TouchableOpacity, {
                    key: key,
                    onPress: function () { var p = {}; p[key] = !on; saveCfg(p); },
                    style: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingVertical: 6 }
                },
                    h(View, { style: { flex: 1 } },
                        h(Text, { style: { color: "#FFFFFF", fontSize: 14, textAlign: "right" } }, label),
                        hint ? h(Text, { style: small }, hint) : null
                    ),
                    h(View, { style: { width: 46, height: 26, borderRadius: 13, backgroundColor: on ? "#23A55A" : "#4E5058", justifyContent: "center", padding: 3 } },
                        h(View, { style: { width: 20, height: 20, borderRadius: 10, backgroundColor: "#FFFFFF", alignSelf: on ? "flex-start" : "flex-end" } })
                    )
                );
            }
            function chip(label, active, onPress, key) {
                return h(TouchableOpacity, { key: key || label, onPress: onPress, style: btn(active ? "#5865F2" : "#1E1F22", { paddingVertical: 8, marginLeft: 6, marginBottom: 6 }) },
                    h(Text, { style: { color: "#FFFFFF", fontSize: 12, fontWeight: active ? "bold" : "normal", textAlign: "center" } }, label));
            }

            var pInfo = PROVIDERS[cfg.provider] || PROVIDERS.local;
            var currentKey = pInfo.keyProp ? (cfg[pInfo.keyProp] || "") : "";
            var currentModel = pInfo.modelProp ? (cfg[pInfo.modelProp] || "") : "";
            var currentUrl = pInfo.urlProp ? (cfg[pInfo.urlProp] || "") : "";
            var draftKey = keyDraft[0] !== null ? keyDraft[0] : "";
            var draftModel = modelDraft[0] !== null ? modelDraft[0] : currentModel;
            var draftUrl = urlDraft[0] !== null ? urlDraft[0] : currentUrl;
            var draftAdmins = adminsDraft[0] !== null ? adminsDraft[0] : (cfg.targetUserIds || "");
            var draftGuild = guildDraft[0] !== null ? guildDraft[0] : (cfg.targetGuildId || "");
            var draftChannel = channelDraft[0] !== null ? channelDraft[0] : (cfg.targetChannelId || "");
            var draftReportCh = reportChDraft[0] !== null ? reportChDraft[0] : (cfg.reportChannelId || "");

            var savedAdmins = extractSnowflakes(cfg.targetUserIds);
            var savedGuildId = extractSingleIdOrWebhook(cfg.targetGuildId);
            if (isWebhookUrl(savedGuildId)) savedGuildId = "";
            var savedGuildName = savedGuildId ? getGuildName(savedGuildId) : "";
            var savedChannelId = getTargetChannelIdClean();
            var savedChannelInfo = savedChannelId ? getChannelInfo(savedChannelId) : null;
            var savedReportDest = extractSingleIdOrWebhook(cfg.reportChannelId);
            var savedReportInfo = (savedReportDest && !isWebhookUrl(savedReportDest)) ? getChannelInfo(savedReportDest) : null;
            var privateChannels = showGroups[0] ? listPrivateChannels(25) : [];

            var findings = cfg.findings || [];
            var counts = {};
            var unforwardedCount = 0;
            for (var i = 0; i < findings.length; i++) {
                counts[findings[i].cat] = (counts[findings[i].cat] || 0) + 1;
                if (!findings[i].forwarded) unforwardedCount++;
            }
            var shown = filter === "all" ? findings : findings.filter(function (f) { return f.cat === filter; });

            var curCh = getCurrentChannelId();
            var curInfo = curCh ? getChannelInfo(curCh) : null;

            var depthOptions = [
                { label: "سريع (25/إداري)", v: 25 },
                { label: "متوسط (75/إداري)", v: 75 },
                { label: "عميق (200/إداري)", v: 200 },
                { label: "واسع (1000/إداري)", v: 1000 },
                { label: "شامل (5000/إداري)", v: 5000 }
            ];
            var batchOptions = [
                { label: "15 رسالة", v: 15 },
                { label: "50 رسالة", v: 50 },
                { label: "70 رسالة", v: 70 },
                { label: "100 رسالة (6×100 = 600 🔥)", v: 100 },
                { label: "250 رسالة (للطرازات الكبرى)", v: 250 }
            ];
            var thresholds = [
                { label: "حساس جداً (0.3)", v: 0.3 },
                { label: "متوازن (0.5)", v: 0.5 },
                { label: "الواضح فقط (0.8)", v: 0.8 }
            ];

            function switchProvider(pid) {
                saveCfg({ provider: pid });
                keyDraft[1](null);
                modelDraft[1](null);
                urlDraft[1](null);
                discoveredModels[1]([]);
                setTestStatus("");
            }

            var savedKeysList = pInfo.keyProp ? getProviderKeys(cfg.provider) : [];

            function addProviderSettings() {
                var patch = {};
                var addedCount = 0;
                if (pInfo.keyProp && keyDraft[0] !== null && String(keyDraft[0]).trim()) {
                    var incoming = parseKeyList(String(keyDraft[0]));
                    var existing = getProviderKeys(cfg.provider);
                    var seen = {};
                    var merged = [];
                    for (var i = 0; i < existing.length; i++) {
                        seen[existing[i]] = true;
                        merged.push(existing[i]);
                    }
                    for (var j = 0; j < incoming.length; j++) {
                        if (!seen[incoming[j]]) {
                            seen[incoming[j]] = true;
                            merged.push(incoming[j]);
                            addedCount++;
                        }
                    }
                    if (merged.length) patch[pInfo.keyProp] = merged.join("\n");
                }
                if (pInfo.modelProp && String(draftModel || "").trim()) {
                    patch[pInfo.modelProp] = String(draftModel).trim();
                }
                if (pInfo.urlProp && String(draftUrl || "").trim()) {
                    patch[pInfo.urlProp] = String(draftUrl).trim();
                }
                if (Object.keys(patch).length === 0) {
                    showToast("أدخل مفتاحاً أو إعدادات أولاً");
                    return;
                }
                saveCfg(patch);
                keyDraft[1](null);
                modelDraft[1](null);
                urlDraft[1](null);
                setTestStatus("");
                if (addedCount > 0) showToast("تمت إضافة " + addedCount + " مفتاح إلى " + pInfo.sourceName);
                else showToast("تم حفظ إعدادات " + pInfo.sourceName);
            }

            function removeProviderKey(keyToRemove) {
                if (!pInfo.keyProp) return;
                var next = getProviderKeys(cfg.provider).filter(function (k) { return k !== keyToRemove; });
                var patch = {};
                patch[pInfo.keyProp] = next.join("\n");
                delete keyHealth[makeKeyId(cfg.provider, keyToRemove)];
                saveCfg(patch);
                showToast("تم حذف المفتاح (" + maskKey(keyToRemove) + ")");
            }

            function checkLocalServerModels() {
                if (!pInfo.urlProp) return;
                var useUrl = String(draftUrl || currentUrl || "").trim();
                if (!useUrl) { setTestStatus("⚠️ أدخل رابط الخادم أولاً"); return; }
                var useKey = parseKeyList(String(draftKey || ""))[0] || savedKeysList[0] || "";
                setTestStatus("⏳ جارٍ فحص اتصال " + pInfo.sourceName + " على " + useUrl + "…");
                fetchServerModels(useUrl, useKey, pInfo.defaultBearer).then(function (ids) {
                    var patch = {};
                    if (useUrl !== currentUrl) patch[pInfo.urlProp] = useUrl;
                    if (Object.keys(patch).length) saveCfg(patch);
                    urlDraft[1](null);
                    discoveredModels[1](ids);
                    setTestStatus("✅ " + pInfo.sourceName + " متصل ويعمل! " + (ids.length ? ("النماذج المتاحة: " + ids.length) : "جاهز للعمل بدون API"));
                }).catch(function (err) {
                    if (cfg.provider === "omniroute") {
                        testSingleKey("", 1);
                        return;
                    }
                    setTestStatus("❌ تعذّر الاتصال بـ " + useUrl + " — تأكد من تشغيل " + pInfo.sourceName + " (" + String((err && err.message) || err) + ")");
                });
            }

            function testSingleKey(keyToTest, indexLabel) {
                var pid = cfg.provider;
                var prevUrl = pInfo.urlProp ? cfg[pInfo.urlProp] : "";
                var useModel = parseModelList(String(draftModel || currentModel || ""))[0] || (pInfo.presets && pInfo.presets[0]) || "";
                var useUrl = String(draftUrl || prevUrl || "").trim();
                if (pInfo.modelProp && !useModel) {
                    setTestStatus("⚠️ أدخل اسم النموذج أولاً");
                    return Promise.resolve(false);
                }
                if (pInfo.urlProp && !useUrl) {
                    setTestStatus("⚠️ أدخل رابط الـ API أولاً");
                    return Promise.resolve(false);
                }
                if (pInfo.urlProp) cfg[pInfo.urlProp] = useUrl;

                var label = keyToTest ? ("مفتاح #" + (indexLabel || 1) + " (" + maskKey(keyToTest) + ")") : "مجاني بدون API";
                setTestStatus("⏳ جارٍ اختبار " + pInfo.sourceName + " — " + label + " (" + useModel + ")…");
                var kid = makeKeyId(pid, keyToTest);

                return runProviderModerate(pid, ["السلام عليكم، هذه رسالة تجريبية عادية"], keyToTest, useModel).then(function () {
                    keyHealth[kid] = { cooldownUntil: 0, kind: "ok", reason: "", lastOk: Date.now() };
                    var patch = {};
                    if (pInfo.urlProp && useUrl !== prevUrl) patch[pInfo.urlProp] = useUrl;
                    if (pInfo.modelProp && draftModel && String(draftModel).trim() !== currentModel) patch[pInfo.modelProp] = String(draftModel).trim();
                    if (Object.keys(patch).length) saveCfg(patch);
                    setTestStatus("✅ نجح " + pInfo.sourceName + " (" + label + " • " + (useModel || "omni-moderation-latest") + ")");
                    emitState();
                    return true;
                }).catch(function (err) {
                    if (pInfo.urlProp) cfg[pInfo.urlProp] = prevUrl;
                    var cl = classifyApiError(err);
                    if (cl.rotate && cl.scope === "key") {
                        keyHealth[kid] = { cooldownUntil: Date.now() + cl.cooldownMs, kind: cl.kind, reason: String((err && err.message) || err), lastOk: 0 };
                    }
                    setTestStatus("❌ فشل " + label + ": " + String((err && err.message) || err));
                    emitState();
                    return false;
                });
            }

            function testAllProviderKeys() {
                var keys = getProviderKeys(cfg.provider);
                var pendingDraft = parseKeyList(String(draftKey || ""));
                if (pendingDraft.length > 0) {
                    addProviderSettings();
                    keys = getProviderKeys(cfg.provider);
                }
                if (keys.length === 0) {
                    if (pInfo.keyOptional) {
                        testSingleKey("", 1);
                    } else {
                        setTestStatus("⚠️ أضف مفتاحاً واحداً على الأقل أولاً");
                    }
                    return;
                }
                var okCount = 0;
                var idx = 0;
                function next() {
                    if (idx >= keys.length) {
                        setTestStatus("✅ اكتمل الاختبار: نجح " + okCount + " من " + keys.length + " مفتاح في " + pInfo.sourceName);
                        return;
                    }
                    var k = keys[idx];
                    idx++;
                    testSingleKey(k, idx).then(function (ok) {
                        if (ok) okCount++;
                        return sleep(400);
                    }).then(next);
                }
                next();
            }

            var totalAllKeys = 0;
            var readyProvidersCount = 0;
            for (var pi = 0; pi < PROVIDER_ORDER.length; pi++) {
                var pId = PROVIDER_ORDER[pi];
                if (pId === "local") continue;
                var pk = getProviderKeys(pId).length;
                totalAllKeys += pk;
                if (isProviderReady(pId, pId !== cfg.provider)) readyProvidersCount++;
            }

            var searchSum = (savedGuildId && savedAdmins.count > 0)
                ? getSearchSummary(savedGuildId, savedAdmins.list, cfg.searchDepth)
                : null;
            var fullSum = (savedGuildId && savedAdmins.count > 0)
                ? getSearchSummary(savedGuildId, savedAdmins.list, 2000)
                : null;
            var guildProg = savedGuildId ? getProgressForGuild(savedGuildId) : null;
            var savedScannedCount = Array.isArray(cfg.scannedIds) ? cfg.scannedIds.length : 0;
            var persistedForwarded = 0;
            for (var fi = 0; fi < findings.length; fi++) {
                if (findings[fi] && findings[fi].forwarded) persistedForwarded++;
            }
            var totalForwarded = Math.max(persistedForwarded, state.forwarded);
            var allScope = cfg.memberScope === "all";
            var crawlSum = savedGuildId ? getCrawlSummary(savedGuildId) : null;
            var scopeCheck = validateScanScope();
            var activeTypesList = [];
            if (cfg.scanNew) activeTypesList.push("الرسائل الجديدة/المعدّلة");
            if (cfg.scanLoaded) activeTypesList.push("الرسائل المحمّلة عند فتح الروم/البحث");
            activeTypesList.push("البحث التاريخي (عند تشغيله يدوياً)");

            return h(ScrollView, { style: { flex: 1, paddingHorizontal: 16, paddingBottom: 16, backgroundColor: "#1E1F22" } },
                h(View, { style: { gap: 14, paddingTop: 22, paddingBottom: 60 } },
                    h(Text, { style: { fontSize: 18, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } }, "🛡️ حارس بحر v2.5 — نظام الطبقتين (Tiered Pipeline)"),
                    h(Text, { style: small }, "أداة مساعدة للمراجعة البشرية: تفحص نصوص الخادم المحدد فقط بالذكاء الاصطناعي مع تأكيد الاقتباس الحرفي، ولا تصدر أي حظر أو عقوبة أو بلاغ رسمي لديسكورد تلقائياً."),

                    // 1) البحث في الخادم المحدد + الحالة + نقطة التوقف المحفوظة
                    h(View, { style: card },
                        toggle("تشغيل الحارس", "enabled"),
                        h(Text, { style: small },
                            "مفحوص محفوظ: " + savedScannedCount +
                            "  |  بالانتظار: " + state.queued +
                            "  |  مرصود: " + findings.length +
                            "  |  ملخصات مرسلة: " + totalForwarded +
                            "  |  صور مفحوصة: " + (state.imagesScanned || 0) +
                            (state.imageQueued ? ("  |  صور بالانتظار: " + state.imageQueued) : "") +
                            (state.imageWorkers ? ("  |  🖼️ فحص صور (" + state.imageWorkers + "×10 بالتوازي)…") : "") +
                            (state.preFiltered ? ("  |  فرز سريع: " + state.preFiltered) : "") +
                            (state.hallucinationsBlocked ? ("  |  🛡️ هلوسة محجوبة: " + state.hallucinationsBlocked) : "") +
                            (state.unreviewedCount ? ("  |  ⚠️ غير مفحوصة: " + state.unreviewedCount) : "") +
                            (state.lastBatchSize ? ("  |  دفعة: " + state.lastBatchSize) : "") +
                            (state.busy ? ("  |  ⏳ AI يفحص" + (state.inFlightBatches > 1 ? (" (" + state.inFlightBatches + " بالتوازي)…") : "…")) : "")
                        ),
                        state.activeRoute ? h(Text, { style: { fontSize: 12, color: "#23A55A", textAlign: "right" } },
                            "⚡ المسار النشط: " + state.activeRoute + " • لكل طلب: " + (cfg.batchSize || 100) + " رسالة" + (cfg.omnirouteOnly ? " (OmniRoute حصراً)" : "") + (!cfg.doubleCheckBorderline ? " • رصد مباشر بدون تدقيق" : "") + (state.keyRotations ? (" • تبديلات: " + state.keyRotations) : "")
                        ) : null,
                        h(Text, { style: { fontSize: 12, color: serverSearch.running ? "#23A55A" : "#949BA4", textAlign: "right" } },
                            serverSearch.running
                                ? ("🟢 " + (serverSearch.status || "الجلب المستمر من ديسكورد شغّال الآن…"))
                                : ("⚪ الجلب متوقف حالياً — اضغط الزر لبدء الجلب والتوزيع المتوازي (" + getMaxConcurrentBatches() + "×" + (cfg.batchSize || 100) + " = " + (getMaxConcurrentBatches() * (cfg.batchSize || 100)) + " رسالة)")),
                        scopeCheck.ok ? (serverSearch.running
                            ? button("⏹️ إيقاف الجلب المستمر وحفظ نقطة التوقف", "#DA373C", stopServerAdminSearch)
                            : button(
                                allScope
                                    ? ("🚀 ابدأ الجلب والتوزيع المتوازي (" + getMaxConcurrentBatches() + " حسابات × " + (cfg.batchSize || 100) + " رسالة" + (cfg.doubleCheckBorderline ? " + تدقيق مزدوج" : " — رصد مباشر") + ")")
                                    : "🔎 ابدأ جلب وفحص رسائل الإدارة",
                                "#248046",
                                function () {
                                    if (allScope) {
                                        if (crawlSum && crawlSum.allDone) resetMemberCrawl();
                                        startAllMembersCrawl(false);
                                    } else {
                                        startServerAdminSearch(false);
                                    }
                                }
                            )
                        ) : null,
                        !scopeCheck.ok ? h(View, { style: { backgroundColor: "#3B2F1E", borderRadius: 8, padding: 10, borderRightWidth: 3, borderRightColor: "#F0B232", gap: 4 } },
                            h(Text, { style: { color: "#F0B232", fontSize: 12, fontWeight: "bold", textAlign: "right" } }, "⛔ " + scopeCheck.reason)
                        ) : null,
                        state.lastScanWarning ? h(View, { style: { backgroundColor: "#3A2024", borderRadius: 8, padding: 10, borderRightWidth: 3, borderRightColor: "#F23F43", gap: 6 } },
                            h(Text, { style: { color: "#FCA5A5", fontSize: 12, fontWeight: "bold", textAlign: "right" } }, state.lastScanWarning),
                            button("مسح تنبيه المراجعة", "#4E5058", function () {
                                state.unreviewedCount = 0;
                                state.lastScanWarning = "";
                                emitState(true);
                            }, { paddingVertical: 6 })
                        ) : null,
                        h(View, { style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 10, gap: 8 } },
                            h(Text, { style: { color: savedGuildId ? "#23A55A" : "#F0B232", fontSize: 13, fontWeight: "bold", textAlign: "right" } },
                                savedGuildId
                                    ? ("✅ الخادم المستهدف: " + (savedGuildName ? (savedGuildName + " (" + savedGuildId + ")") : savedGuildId))
                                    : "⛔ لم يُحدَّد الخادم المستهدف بعد (الفحص متوقف)"),
                            savedChannelId ? h(Text, { style: { color: "#60A5FA", fontSize: 13, fontWeight: "bold", textAlign: "right" } },
                                "🎯 غرفة محددة فقط: " + ((savedChannelInfo && savedChannelInfo.channelName) ? (savedChannelInfo.channelName + " (" + savedChannelId + ")") : savedChannelId)) : null,
                            h(Text, { style: { color: (allScope || savedAdmins.count) ? "#23A55A" : "#F0B232", fontSize: 13, textAlign: "right" } },
                                allScope
                                    ? "🌐 الأعضاء المشمولون: كل أعضاء هذا الخادم المحدد فقط"
                                    : (savedAdmins.count
                                        ? ("👥 الأعضاء المشمولون: الإدارة المحددة فقط (" + savedAdmins.count + " معرّف بالـ ID)")
                                        : "⚠️ النطاق الافتراضي «الإدارة المحددة فقط» — أضف معرّفات الإدارة أدناه لبدء الفحص")),
                            h(Text, { style: small },
                                "ما سيُفحص حالياً: " + activeTypesList.join(" + ") + (scopeCheck.ok ? "" : " (متوقف حتى اكتمال تحديد الخادم والنطاق).")),
                            searchSum && searchSum.hasProgress ? h(Text, { style: { color: "#60A5FA", fontSize: 12, fontWeight: "bold", textAlign: "right" } },
                                searchSum.allDone
                                    ? ("📌 التقدم المحفوظ: ✅ اكتمل فحص (" + searchSum.doneCount + "/" + searchSum.total + ") لعمق " + cfg.searchDepth + " رسالة/إداري • المجلوب: " + searchSum.fetchedTotal)
                                    : ("📌 التقدم المحفوظ: اكتمل " + searchSum.doneCount + "/" + searchSum.total + " إداري • المتبقي: " + searchSum.remainingCount + " • المجلوب: " + searchSum.fetchedTotal + " (سيتابع من حيث توقف)")) : null,
                            h(Text, { style: small }, "نطاق الفحص:"),
                            h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                                chip("👥 الإدارة فقط (الافتراضي الأضيق)", !allScope, function () { if (!serverSearch.running) saveCfg({ memberScope: "admins", filterUsersOnly: true }); }, "sc_adm"),
                                chip("🌐 كل رسائل الأعضاء في هذا الخادم", allScope, function () { if (!serverSearch.running) saveCfg({ memberScope: "all" }); }, "sc_all")
                            ),
                            allScope ? h(Text, { style: small },
                                savedChannelId
                                    ? "🌐 وضع كل الأعضاء للغرفة المحددة: يجلب الرسائل بسرعة ويرسل 250 رسالة في كل طلب لنماذج التفكير العميق (حتى 6 نماذج بالتوازي)."
                                    : "🌐 وضع كل الأعضاء: يجلب تاريخ كل القنوات النصية المتاحة لحسابك في هذا الخادم فقط ويرسلها للذكاء الاصطناعي دون تجاوز أي صلاحيات.") : null,
                            allScope && crawlSum ? h(Text, { style: { color: "#60A5FA", fontSize: 12, fontWeight: "bold", textAlign: "right" } },
                                "📌 تقدم فحص الأعضاء: " + crawlSum.done + "/" + crawlSum.total + (savedChannelId ? " غرفة" : " قناة") + " • المجلوب: " + crawlSum.fetchedTotal + " • أُرسل للفحص: " + crawlSum.queuedTotal +
                                (crawlSum.allDone ? " • ✅ مكتمل" : (crawlSum.hasProgress ? " (سيتابع من حيث توقف)" : ""))) : null,
                            !allScope ? h(Text, { style: small }, "عمق البحث الشامل لكل إداري في الخادم:") : null,
                            !allScope ? h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                                depthOptions.map(function (d) {
                                    return chip(d.label, cfg.searchDepth === d.v, function () { saveCfg({ searchDepth: d.v }); }, "dep_" + d.v);
                                })
                            ) : null,
                            serverSearch.status ? h(Text, { style: { color: serverSearch.running ? "#23A55A" : "#DBDEE1", fontSize: 12, fontWeight: "bold", textAlign: "right" } }, serverSearch.status) : null,
                            serverSearch.lastError ? h(Text, { style: { color: "#F23F43", fontSize: 12, textAlign: "right" } }, "خطأ البحث: " + serverSearch.lastError) : null,
                            serverSearch.running
                                ? button("⏹️ إيقاف البحث وحفظ نقطة التوقف", "#DA373C", stopServerAdminSearch)
                                : h(View, { style: { gap: 6 } },
                                    allScope ? button(
                                        "📥 جلب 5000 رسالة الآن وفحصها وتوزيعها بالتوازي",
                                        savedGuildId ? "#5865F2" : "#4E5058",
                                        function () {
                                            if (!cfg.parallelBatches) {
                                                saveCfg({ parallelBatches: true });
                                            }
                                            if (crawlSum && crawlSum.allDone) resetMemberCrawl();
                                            startAllMembersCrawl(true, 5000);
                                        }
                                    ) : null,
                                    cfg.scanImages && imageQueue.length > 0 && !serverSearch.running ? button(
                                        "🖼️ فحص الصور بالانتظار الآن (" + imageQueue.length + " صورة)",
                                        "#5865F2",
                                        function () {
                                            pumpImages();
                                            showToast("بدأ فحص الصور بالانتظار (" + imageQueue.length + " صورة)");
                                        }
                                    ) : null,
                                    allScope ? button(
                                        crawlSum && crawlSum.hasProgress && !crawlSum.allDone
                                            ? ("▶️ متابعة فحص كل التاريخ (" + (savedChannelId ? "الغرفة المحددة" : ("المتبقي " + crawlSum.remaining + " قناة")) + ")")
                                            : (crawlSum && crawlSum.allDone
                                                ? "🔁 إعادة الفحص من البداية (100/طلب)"
                                                : (savedChannelId ? "🌐 فحص كل تاريخ هذه الغرفة (100/طلب)" : "🌐 فحص كل رسائل الأعضاء في كل القنوات")),
                                        savedGuildId ? "#248046" : "#4E5058",
                                        function () {
                                            if (crawlSum && crawlSum.allDone) resetMemberCrawl();
                                            startAllMembersCrawl(false);
                                        }
                                    ) : null,
                                    allScope && crawlSum && crawlSum.hasProgress ? button("🔄 تصفير تقدم فحص الأعضاء", "#3F4147", function () {
                                        resetMemberCrawl();
                                        showToast("تم تصفير تقدم فحص الأعضاء");
                                    }) : null,
                                    !allScope ? button(
                                        "🔎 بحث شامل عن كل رسائل الإدارة في الخادم (كل الرسائل القديمة والجديدة)",
                                        (savedGuildId && savedAdmins.count > 0) ? "#248046" : "#4E5058",
                                        function () {
                                            if (fullSum && fullSum.allDone) {
                                                for (var rUid in (guildProg && guildProg.admins ? guildProg.admins : {})) {
                                                    if (Object.prototype.hasOwnProperty.call(guildProg.admins, rUid)) {
                                                        guildProg.admins[rUid].nextOffset = 0;
                                                        guildProg.admins[rUid].reachedEnd = false;
                                                    }
                                                }
                                                if (guildProg) persistSearchProgress(guildProg);
                                            }
                                            startServerAdminSearch(false, Math.max(2000, Number(cfg.searchDepth) || 2000));
                                        }
                                    ) : null,
                                    !allScope ? button(
                                        "🆕 فحص أحدث رسائل الإدارة فقط الآن (بدون تصفير القديم)",
                                        (savedGuildId && savedAdmins.count > 0) ? "#5865F2" : "#4E5058",
                                        function () { startServerAdminSearch(true); }
                                    ) : null,
                                    button(
                                        "🚀 بحث سريع بالكلمات الخطيرة (" + (allScope ? "كل الأعضاء" : "الإدارة") + ")",
                                        (savedGuildId && (allScope || savedAdmins.count > 0)) ? "#D97706" : "#4E5058",
                                        function () { startFastKeywordSearch(""); }
                                    ),
                                    button("🧪 اختبار دقة الذكاء الاصطناعي (رسائل اصطناعية تجريبية)", "#4E5058", function () {
                                        selfTestMsg[1]("⏳ جارٍ الاختبار…");
                                        runDetectionSelfTest(function (m) { selfTestMsg[1](m); });
                                    }),
                                    selfTestMsg[0] ? h(Text, { style: { color: "#DBDEE1", fontSize: 12, textAlign: "right" } }, selfTestMsg[0]) : null
                                ),
                            !serverSearch.running && savedGuildId && (allScope || savedAdmins.count > 0) ? h(View, { style: { flexDirection: "row-reverse", gap: 6, alignItems: "center" } },
                                TextInput ? h(TextInput, {
                                    value: customKwDraft[0],
                                    onChangeText: function (t) { customKwDraft[1](t); },
                                    placeholder: "أو اكتب كلمات بحث مخصصة…",
                                    placeholderTextColor: "#72767D",
                                    style: Object.assign({}, inputStyle, { flex: 1, textAlign: "right", paddingVertical: 8 })
                                }) : null,
                                button("🔍 ابحث", "#5865F2", function () {
                                    if (!String(customKwDraft[0] || "").trim()) {
                                        showToast("اكتب كلمة أو أكثر للبحث عنها");
                                        return;
                                    }
                                    startFastKeywordSearch(customKwDraft[0]);
                                })
                            ) : null,
                            savedGuildId ? button("⚡ فحص القنوات المحمّلة حالياً في الخادم (فوري)", "#5865F2", function () {
                                var r = scanServerCachedChannels(savedGuildId);
                                if (r.blockedReason) { showToast(r.blockedReason); return; }
                                showToast(r.scanned ? ("جارٍ فحص " + r.scanned + " رسالة جديدة من " + r.channels + " قناة") : "لا توجد رسائل جديدة غير مفحوصة في القنوات المحمّلة حالياً");
                            }) : null
                        ),
                        state.lastError ? h(Text, { style: { fontSize: 12, color: "#F23F43", textAlign: "right" } }, "آخر خطأ AI: " + state.lastError) : null,
                        state.lastForwardError ? h(Text, { style: { fontSize: 12, color: "#F23F43", textAlign: "right" } }, "آخر خطأ إرسال للمجموعة: " + state.lastForwardError) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            curInfo ? button("🔍 فحص الروم المفتوح", "#4E5058", function () {
                                var n = scanChannel(curCh, false);
                                showToast(n ? ("جارٍ فحص " + n + " رسالة جديدة…") : (state.scopeBlockedReason || "كل الرسائل في هذا الروم مفحوصة بالفعل أو خارج النطاق المحدد"));
                            }, { flex: 1 }) : null,
                            button("🔄 تصفير السجل والتقدم وبدء من الصفر", "#3F4147", function () {
                                resetAllProgress(true);
                                showToast("تم تصفير النتائج ونقطة التوقف وذاكرة المفحوص بالكامل");
                            }, { flex: 1 })
                        )
                    ),

                    // 2) نطاق الرصد (مخالفات حظر الخادم فقط)
                    h(View, { style: card },
                        h(Text, { style: title }, "🔥 نطاق الرصد (نوع المخالفات)"),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            chip("🔥 مخالفات حظر الخادم فقط (الإرهاب والانتهاكات الخطيرة)", cfg.auditMode === "server_ban", function () { saveCfg({ auditMode: "server_ban" }); }, "m_ban"),
                            chip("📋 جميع المخالفات (شامل السب والسبام)", cfg.auditMode === "all", function () { saveCfg({ auditMode: "all" }); }, "m_all")
                        ),
                        h(Text, { style: small }, cfg.auditMode === "server_ban"
                            ? "يركّز حصراً على الانتهاكات الموجبة لحظر الخادم لدى Trust & Safety: دعم/تمجيد/تجنيد الإرهاب، استغلال الأطفال، التهديدات بالقتل والعنف الدموي، التشجيع على الانتحار، بيع السلاح والمخدرات والاختراق، وخطاب الكراهية العنيف — ويتجاهل السب العادي والمزاح."
                            : "يفحص كل المخالفات بما فيها السب والمضايقات والسبام وروابط الاحتيال.")
                    ),

                    // 3) معرّفات الإدارة المستهدفة + معرّف الخادم
                    h(View, { style: card },
                        h(Text, { style: title }, "👤 معرّفات الإدارة والخادم المستهدف"),
                        toggle("فحص رسائل الإدارة المحددة فقط", "filterUsersOnly", "لن يُفحص أي عضو خارج قائمة المعرّفات أدناه عندما يكون النطاق «الإدارة فقط»"),
                        cfg.memberScope === "admins" && savedAdmins.count === 0
                            ? h(Text, { style: { fontSize: 12, color: "#F0B232", textAlign: "right" } }, "⚠️ النطاق الحالي «الإدارة فقط» والفحص متوقف حتى تضيف معرّفاً (ID) واحداً على الأقل.")
                            : null,
                        h(Text, { style: small }, "معرّفات (IDs) الإدارة — كل معرّف في سطر أو بمسافة أو فاصلة:"),
                        TextInput ? h(TextInput, {
                            value: draftAdmins,
                            onChangeText: function (t) { adminsDraft[1](t); },
                            placeholder: "مثال:\n123456789012345678\n987654321098765432",
                            placeholderTextColor: "#72767D",
                            multiline: true,
                            autoCapitalize: "none",
                            autoCorrect: false,
                            style: Object.assign({}, inputStyle, { minHeight: 74, textAlignVertical: "top" })
                        }) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            button("حفظ معرّفات الإدارة", "#248046", function () {
                                var parsed = extractSnowflakes(draftAdmins);
                                var normalized = parsed.list.join("\n");
                                saveCfg({ targetUserIds: normalized, filterUsersOnly: true });
                                state.scopeBlockedReason = validateScanScope().ok ? "" : validateScanScope().reason;
                                adminsDraft[1](null);
                                showToast(parsed.count ? ("تم حفظ وتفعيل " + parsed.count + " معرّف للإدارة") : "تم مسح القائمة وإيقاف الفحص");
                            }, { flex: 1 }),
                            savedAdmins.count ? button("مسح", "#DA373C", function () {
                                saveCfg({ targetUserIds: "" });
                                adminsDraft[1](null);
                            }) : null
                        ),
                        savedAdmins.count ? h(View, { style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 10, gap: 6 } },
                            h(TouchableOpacity, { onPress: function () { showAdminList[1](!showAdminList[0]); } },
                                h(Text, { style: { color: "#23A55A", fontSize: 13, fontWeight: "bold", textAlign: "right" } },
                                    "✅ جميع المعرّفات (" + savedAdmins.count + ") مفعّلة ومراقَبة بالـ ID  " + (showAdminList[0] ? "▲" : "▼")),
                                h(Text, { style: small }, "ملاحظة: عدم ظهور اسم الحساب بجانب بعض المعرّفات يعني فقط أنه غير محمّل في الذاكرة مؤقتاً، لكن الفحص والبحث يعملان لكل المعرّفات بالـ ID بدون استثناء.")
                            ),
                            showAdminList[0] ? savedAdmins.list.map(function (uid) {
                                var lbl = resolveUserLabel(uid, savedGuildId);
                                var ap = guildProg && guildProg.admins ? guildProg.admins[uid] : null;
                                var maxM = Math.max(25, Number(cfg.searchDepth) || 75);
                                var st = "⬜ بالانتظار";
                                if (ap) {
                                    if (ap.reachedEnd || (Number(ap.nextOffset) || 0) >= maxM) st = "✅ اكتمل (" + (ap.fetched || 0) + ")";
                                    else if ((Number(ap.nextOffset) || 0) > 0) st = "⏳ وصل " + ap.nextOffset;
                                }
                                return h(Text, { key: uid, style: { color: "#DBDEE1", fontSize: 12, textAlign: "right" } },
                                    st + " • " + uid + " — " + (lbl || "مفعّل بالـ ID"));
                            }) : null
                        ) : null,

                        h(Text, { style: { color: "#FFFFFF", fontSize: 14, fontWeight: "bold", textAlign: "right", marginTop: 4 } }, "معرّف الخادم المستهدف (Server ID):"),
                        h(Text, { style: { fontSize: 12, color: savedGuildId ? "#23A55A" : "#F0B232", textAlign: "right" } },
                            savedGuildId ? ("✅ محفوظ: " + (savedGuildName ? savedGuildName + " — " : "") + savedGuildId) : "⛔ غير محدد (الفحص متوقف — حدّد خادماً للبدء)"),
                        TextInput ? h(TextInput, {
                            value: draftGuild,
                            onChangeText: function (t) { guildDraft[1](t); },
                            placeholder: "أدخل Server ID هنا...",
                            placeholderTextColor: "#72767D",
                            keyboardType: "numeric",
                            style: inputStyle
                        }) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            button("حفظ الخادم", "#248046", function () {
                                var gid = extractSingleIdOrWebhook(draftGuild);
                                var clean = isWebhookUrl(gid) ? "" : gid;
                                saveCfg({ targetGuildId: clean });
                                guildDraft[1](null);
                                showToast(clean ? ("تم حفظ الخادم: " + (getGuildName(clean) || clean)) : "تم إلغاء تحديد الخادم وإيقاف الفحص");
                            }, { flex: 1 }),
                            curInfo && curInfo.guildId ? button("استخدام الخادم الحالي", "#5865F2", function () {
                                saveCfg({ targetGuildId: curInfo.guildId });
                                guildDraft[1](null);
                                showToast("تم حفظ الخادم: " + (curInfo.guildName || curInfo.guildId));
                            }, { flex: 1 }) : null,
                            savedGuildId ? button("مسح", "#DA373C", function () { saveCfg({ targetGuildId: "" }); guildDraft[1](null); }) : null
                        ),

                        h(Text, { style: { color: "#FFFFFF", fontSize: 14, fontWeight: "bold", textAlign: "right", marginTop: 6 } }, "تحديد غرفة واحدة فقط داخل الخادم (اختياري — Channel ID):"),
                        h(Text, { style: { fontSize: 12, color: savedChannelId ? "#60A5FA" : "#B5BAC1", textAlign: "right" } },
                            savedChannelId
                                ? ("🎯 محصور في الغرفة: " + ((savedChannelInfo && savedChannelInfo.channelName) ? (savedChannelInfo.channelName + " — ") : "") + savedChannelId)
                                : "غير محددة (يشمل كل غرف الخادم المحدد وفق نطاق الأعضاء أعلاه)"),
                        TextInput ? h(TextInput, {
                            value: draftChannel,
                            onChangeText: function (t) { channelDraft[1](t); },
                            placeholder: "أدخل Channel ID لغرفة واحدة فقط (أو اتركه فارغاً)...",
                            placeholderTextColor: "#72767D",
                            keyboardType: "numeric",
                            style: inputStyle
                        }) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            button("حفظ الغرفة", "#248046", function () {
                                var cid = extractSingleIdOrWebhook(draftChannel);
                                var cleanCid = isWebhookUrl(cid) ? "" : cid;
                                saveCfg({ targetChannelId: cleanCid });
                                channelDraft[1](null);
                                showToast(cleanCid ? ("تم حصر الفحص في الغرفة: " + ((getChannelInfo(cleanCid) || {}).channelName || cleanCid)) : "تم إلغاء حصر الغرفة (يشمل كل غرف الخادم)");
                            }, { flex: 1 }),
                            curCh && curInfo && curInfo.guildId ? button("استخدام الغرفة المفتوحة", "#5865F2", function () {
                                var patch = { targetChannelId: curCh };
                                if (!savedGuildId) patch.targetGuildId = curInfo.guildId;
                                saveCfg(patch);
                                channelDraft[1](null);
                                if (!savedGuildId) guildDraft[1](null);
                                showToast("تم حصر الفحص في: " + (curInfo.channelName || curCh));
                            }, { flex: 1 }) : null,
                            savedChannelId ? button("مسح الغرفة", "#DA373C", function () {
                                saveCfg({ targetChannelId: "" });
                                channelDraft[1](null);
                                showToast("تم إلغاء تحديد الغرفة المحددة");
                            }) : null
                        )
                    ),

                    // 4) مجموعة/قناة استقبال ملخصات المراجعة (معطّل افتراضياً)
                    h(View, { style: card },
                        h(Text, { style: title }, "📤 وجهة ملخصات المراجعة (اختياري)"),
                        h(Text, { style: small }, "معطّل افتراضياً: عند تفعيله يُرسل ملخص الرصد إلى المجموعة/القناة/Webhook المحددة أدناه لغرض المراجعة البشرية فقط — وهذا ليس بلاغاً رسمياً إلى Discord Trust & Safety ولا يتخذ أي إجراء عقابي."),
                        toggle("إرسال ملخص الرصد تلقائياً للوجهة المحددة", "autoForward"),
                        cfg.autoForward ? h(View, { style: { backgroundColor: "#1E293B", borderRadius: 8, padding: 10, borderRightWidth: 3, borderRightColor: "#60A5FA", gap: 6 } },
                            h(Text, { style: { color: "#93C5FD", fontSize: 12, fontWeight: "bold", textAlign: "right" } },
                                "ℹ️ الإرسال التلقائي مفعّل — الوجهة: " + (savedReportDest
                                    ? (isWebhookUrl(savedReportDest) ? "Webhook مخصص" : ((savedReportInfo ? ((savedReportInfo.guildName ? savedReportInfo.guildName + " / " : "") + savedReportInfo.channelName) : savedReportDest)))
                                    : "غير محددة بعد")),
                            h(Text, { style: small }, "البيانات المُرسلة: نوع المخالفة، درجة الثقة، سبب التصنيف، اسم ومعرّف الكاتب، اسم القناة/الخادم، ورابط الرسالة (بدون مرفقات)."),
                            h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                                button("⏹️ إيقاف الإرسال التلقائي", "#4E5058", function () {
                                    saveCfg({ autoForward: false });
                                    showToast("تم إيقاف الإرسال التلقائي — النتائج تُحفظ محلياً فقط");
                                }, { flex: 1, paddingVertical: 8 }),
                                savedReportDest ? button("🗑️ مسح الوجهة", "#DA373C", function () {
                                    saveCfg({ reportChannelId: "", autoForward: false });
                                    reportChDraft[1](null);
                                    setFwdTestStatus("");
                                    showToast("تم مسح الوجهة وإيقاف الإرسال التلقائي");
                                }, { flex: 1, paddingVertical: 8 }) : null
                            )
                        ) : null,
                        h(Text, { style: { fontSize: 13, color: savedReportDest ? "#23A55A" : "#F0B232", textAlign: "right" } },
                            savedReportDest
                                ? (isWebhookUrl(savedReportDest)
                                    ? "✅ الوجهة المحفوظة: رابط Webhook مخصص"
                                    : "✅ الوجهة المحفوظة: [" + (savedReportInfo ? savedReportInfo.typeLabel : "قناة") + "] " + (savedReportInfo ? ((savedReportInfo.guildName ? savedReportInfo.guildName + " / " : "") + savedReportInfo.channelName) : savedReportDest))
                                : "⚠️ لم تُحدد وجهة لإرسال الملخصات بعد"),
                        TextInput ? h(TextInput, {
                            value: draftReportCh,
                            onChangeText: function (t) { reportChDraft[1](t); },
                            placeholder: "أدخل معرّف المجموعة (Group/Channel ID) أو رابط Webhook...",
                            placeholderTextColor: "#72767D",
                            autoCapitalize: "none",
                            autoCorrect: false,
                            style: inputStyle
                        }) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            button("حفظ المجموعة", "#248046", function () {
                                var dest = extractSingleIdOrWebhook(draftReportCh);
                                saveCfg({ reportChannelId: dest });
                                reportChDraft[1](null);
                                setFwdTestStatus("");
                                showToast(dest ? "تم حفظ وجهة التقارير" : "تم مسح وجهة التقارير");
                            }, { flex: 1 }),
                            button("اختبار الإرسال", "#5865F2", function () {
                                var dest = extractSingleIdOrWebhook(draftReportCh || cfg.reportChannelId);
                                if (!dest) { setFwdTestStatus("⚠️ أدخل معرّف المجموعة أولاً"); return; }
                                setFwdTestStatus("⏳ جارٍ إرسال رسالة تجريبية…");
                                postToDestination(dest, "🛡️ **حارس بحر:** تم ربط هذه المجموعة بنجاح لاستقبال ملخصات المراجعة البشرية.").then(function () {
                                    if (dest !== cfg.reportChannelId) saveCfg({ reportChannelId: dest });
                                    reportChDraft[1](null);
                                    setFwdTestStatus("✅ تم الإرسال للمجموعة بنجاح!");
                                }).catch(function (err) {
                                    setFwdTestStatus("❌ فشل الإرسال: " + sanitizeErrorMessage((err && (err.message || (err.body && err.body.message))) || err));
                                });
                            }, { flex: 1 }),
                            savedReportDest ? button("مسح", "#DA373C", function () { saveCfg({ reportChannelId: "", autoForward: false }); reportChDraft[1](null); setFwdTestStatus(""); }) : null
                        ),
                        fwdTestStatus ? h(Text, { style: { fontSize: 12, color: fwdTestStatus.indexOf("✅") === 0 ? "#23A55A" : "#F0B232", textAlign: "right" } }, fwdTestStatus) : null,
                        h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                            curInfo ? button("استخدام المحادثة المفتوحة الآن", "#4E5058", function () {
                                saveCfg({ reportChannelId: curCh });
                                reportChDraft[1](null);
                                showToast("تم اختيار: " + curInfo.channelName);
                            }, { flex: 1 }) : null,
                            button(showGroups[0] ? "إخفاء القروبات ▲" : "اختر من قروباتي ▼", "#4E5058", function () {
                                showGroups[1](!showGroups[0]);
                            }, { flex: 1 })
                        ),
                        showGroups[0] ? h(View, { style: { gap: 6 } },
                            privateChannels.length === 0
                                ? h(Text, { style: small }, "لم يتم العثور على قروبات أو محادثات خاصة محمّلة حالياً.")
                                : privateChannels.map(function (ch) {
                                    return h(TouchableOpacity, {
                                        key: ch.channelId,
                                        onPress: function () {
                                            saveCfg({ reportChannelId: ch.channelId });
                                            reportChDraft[1](null);
                                            showGroups[1](false);
                                            showToast("تم اختيار: " + ch.channelName);
                                        },
                                        style: btn(ch.channelId === savedReportDest ? "#248046" : "#1E1F22", { alignItems: "flex-end" })
                                    }, h(Text, { style: { color: "#FFFFFF", fontSize: 12 } }, "[" + ch.typeLabel + "] " + ch.channelName + " (" + ch.channelId + ")"));
                                })
                        ) : null
                    ),

                    // 5) المزوّد والنماذج وتعدد المفاتيح
                    h(View, { style: card },
                        h(Text, { style: title }, "🤖 محرك الفحص ومفاتيح الـ API (متعدد المفاتيح)"),
                        h(Text, { style: small },
                            "المجموع المحفوظ: " + totalAllKeys + " مفتاح عبر " + readyProvidersCount + " مزوّد جاهز" +
                            (state.activeRoute ? ("  •  النشط: " + state.activeRoute) : "")
                        ),
                        toggle(
                            "حصر الفحص على OmniRoute فقط (بدون أي مزوّد خارجي)",
                            "omnirouteOnly",
                            "يعتمد حصراً على خادم OmniRoute المحلي وحساباته ولا ينتقل لأي مزوّد خارجي إطلاقاً"
                        ),
                        toggle(
                            "الانتقال التلقائي لمزوّد آخر عند انتهاء الحصة",
                            "autoFailoverProviders",
                            "إذا انتهت حصة كل مفاتيح المزوّد الحالي ينتقل تلقائياً لأي مزوّد آخر فيه مفاتيح محفوظة"
                        ),
                        toggle(
                            "نظام الطبقتين (Tiered Pipeline — الفرز بالأساسي والتأكيد بالأقوى)",
                            "tieredPipeline",
                            "يستخدم المزوّد المختار للفرز السريع، وعند رصد شبهة يفضّل أقوى نموذج متاح ومستقر للتأكيد المزدوج مع تبديل تلقائي عند الفشل فقط"
                        ),
                        toggle(
                            "استخدام كل النماذج وكل الـ APIs بالتناوب (Round-Robin)",
                            "roundRobinProviders",
                            "يوزّع الدفعات على جميع نماذج الذكاء الاصطناعي (OmniRoute و CoArena و Groq و Gemini وغيرها) في كل فحص"
                        ),
                        toggle(
                            "فحص الصور بنماذج الرؤية (4 نماذج × 10 صور = 40 صورة بالتوازي)",
                            "scanImages",
                            "يشغّل 4 نماذج رؤية بالتوازي (10 صور لكل نموذج = 40 صورة/جولة) مع نماذج احتياطية تلقائية عند انتهاء الحصة أو الفشل"
                        ),
                        cfg.scanImages ? h(View, { style: { gap: 6, backgroundColor: "#1E1F22", borderRadius: 8, padding: 10 } },
                            h(Text, { style: { color: "#DBDEE1", fontSize: 13, fontWeight: "bold", textAlign: "right" } }, "🖼️ نماذج فحص الصور (4 بالتوازي × " + (cfg.imageBatchSize || 10) + " صور + احتياط):"),
                            h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                                ["gemini-web/gemini-3.1-pro", "gemini-web/gemini-3.7-flash", "auto/best-vision", "auto/pro-vision", "antigravity/gemini-3-flash", "agy/gemini-3.8-flash-high", "agy/gemini-3.8-flash-medium", "agy/gemini-3.1-flash-lite"].map(function (vm) {
                                    var curVm = String(cfg.visionModel || "");
                                    return chip(vm, curVm.indexOf(vm) !== -1, function () {
                                        saveCfg({ visionModel: vm });
                                        emitState();
                                        showToast("تم اختيار نموذج الصور: " + vm);
                                    }, "vm_" + vm);
                                })
                            ),
                            TextInput ? h(TextInput, {
                                value: String(cfg.visionModel || ""),
                                onChangeText: function (t) { saveCfg({ visionModel: t }); emitState(); },
                                placeholder: DEFAULTS.visionModel,
                                placeholderTextColor: "#72767D",
                                autoCapitalize: "none",
                                autoCorrect: false,
                                style: inputStyle
                            }) : null
                        ) : null,
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            PROVIDER_ORDER.map(function (pid) {
                                var isLoc = pid === "local" || !!(PROVIDERS[pid] && PROVIDERS[pid].locked);
                                var pCnt = isLoc ? 0 : getProviderKeys(pid).length;
                                var lbl = PROVIDERS[pid].label + (pCnt > 0 ? (" (" + pCnt + " 🔑)") : "");
                                return chip(lbl, !isLoc && cfg.provider === pid, function () {
                                    if (isLoc) {
                                        showToast("🔒 المحرك المحلي مقفل — يعتمد الحارس على الذكاء الاصطناعي فقط");
                                        return;
                                    }
                                    switchProvider(pid);
                                }, "prov_" + pid);
                            })
                        ),

                        cfg.provider !== "local" ? h(View, { style: { gap: 8 } },
                            h(Text, { style: small }, pInfo.keyHint || ""),

                            cfg.provider === "omniroute" ? toggle(
                                "تضمين OmniRoute في التبديل التلقائي مع المزوّدات الأخرى",
                                "omnirouteInFailover",
                                "عند التفعيل: إن كنت تستخدم مزوّداً آخر وانتهت حصته ينتقل تلقائياً لـ OmniRoute (والعكس)"
                            ) : null,

                            pInfo.urlProp ? h(View, { style: { gap: 6 } },
                                h(Text, { style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } },
                                    cfg.provider === "omniroute" ? "رابط خادم OmniRoute المحلي:" : "رابط الـ API (Base URL أو chat/completions):"),
                                pInfo.urlPresets ? h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                                    pInfo.urlPresets.map(function (uVal) {
                                        return chip("رابط: " + uVal, String(draftUrl).trim() === uVal, function () {
                                            var p = {}; p[pInfo.urlProp] = uVal; saveCfg(p); urlDraft[1](null); setTestStatus("");
                                        }, "url_" + uVal);
                                    })
                                ) : null,
                                TextInput ? h(TextInput, {
                                    value: draftUrl,
                                    onChangeText: function (t) { urlDraft[1](t); },
                                    placeholder: cfg.provider === "omniroute" ? "http://127.0.0.1:20128/v1" : "https://api.deepseek.com/v1/chat/completions",
                                    placeholderTextColor: "#72767D",
                                    autoCapitalize: "none",
                                    autoCorrect: false,
                                    style: inputStyle
                                }) : null,
                                button("🔍 فحص اتصال " + pInfo.sourceName + " وجلب النماذج", "#5865F2", checkLocalServerModels)
                            ) : null,

                            pInfo.modelProp ? (function () {
                                var combinedPresets = (pInfo.presets || []).slice();
                                var disc = discoveredModels[0] || [];
                                for (var di = 0; di < disc.length; di++) {
                                    if (combinedPresets.indexOf(disc[di]) === -1) combinedPresets.push(disc[di]);
                                }
                                return h(View, { style: { gap: 6 } },
                                    h(Text, { style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } }, "اسم النموذج (اختر جاهزاً أو اكتب نموذجاً أو عدة نماذج مفصولة بفاصلة للتبديل التلقائي):"),
                                    combinedPresets.length ? h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                                        combinedPresets.map(function (mName) {
                                            var activeModels = parseModelList(String(draftModel || ""));
                                            var isSel = activeModels.indexOf(mName) !== -1;
                                            return chip("نموذج: " + mName, isSel, function () {
                                                var curList = parseModelList(String(draftModel || ""));
                                                var nextList;
                                                if (curList.indexOf(mName) !== -1 && curList.length > 1) {
                                                    nextList = curList.filter(function (x) { return x !== mName; });
                                                } else if (curList.indexOf(mName) === -1) {
                                                    nextList = [mName].concat(curList);
                                                } else {
                                                    nextList = [mName];
                                                }
                                                var p = {}; p[pInfo.modelProp] = nextList.join(", "); saveCfg(p); modelDraft[1](null); setTestStatus("");
                                            }, "mod_" + mName);
                                        })
                                    ) : null,
                                    TextInput ? h(TextInput, {
                                        value: draftModel,
                                        onChangeText: function (t) { modelDraft[1](t); },
                                        placeholder: cfg.provider === "omniroute" ? "auto" : "مثال: openrouter/free, meta-llama/llama-3.3-70b-instruct:free",
                                        placeholderTextColor: "#72767D",
                                        autoCapitalize: "none",
                                        autoCorrect: false,
                                        style: inputStyle
                                    }) : null
                                );
                            })() : null,

                            // قائمة المفاتيح المحفوظة لهذا المزوّد
                            h(Text, { style: { fontSize: 13, fontWeight: "bold", color: (savedKeysList.length || pInfo.keyOptional) ? "#23A55A" : "#F0B232", textAlign: "right" } },
                                savedKeysList.length
                                    ? ("🔑 مفاتيح " + pInfo.sourceName + " المحفوظة (" + savedKeysList.length + ") — يتبدل بينها تلقائياً:")
                                    : (pInfo.keyOptional
                                        ? (cfg.provider === "omniroute" ? "✅ OmniRoute يعمل بدون مفتاح API (النموذج: auto)" : "ℹ️ المفتاح اختياري لهذا المزوّد")
                                        : "⚠️ لم يُحفظ أي مفتاح لـ " + pInfo.sourceName + " بعد")),

                            savedKeysList.length ? h(View, { style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 8, gap: 6 } },
                                savedKeysList.map(function (kVal, kIdx) {
                                    var badge = getKeyBadgeInfo(cfg.provider, kVal);
                                    return h(View, { key: kVal, style: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", gap: 6, paddingVertical: 4, borderBottomWidth: kIdx < savedKeysList.length - 1 ? 1 : 0, borderBottomColor: "#2B2D31" } },
                                        h(View, { style: { flex: 1 } },
                                            h(Text, { style: { color: "#FFFFFF", fontSize: 12, fontWeight: "bold", textAlign: "right" } },
                                                "مفتاح #" + (kIdx + 1) + "  (" + maskKey(kVal) + ")"),
                                            h(Text, { style: { color: badge.color, fontSize: 11, textAlign: "right" } }, badge.text)
                                        ),
                                        h(View, { style: { flexDirection: "row-reverse", gap: 6 } },
                                            button("اختبار", "#5865F2", function () { testSingleKey(kVal, kIdx + 1); }, { paddingVertical: 6, paddingHorizontal: 10 }),
                                            button("✖", "#DA373C", function () { removeProviderKey(kVal); }, { paddingVertical: 6, paddingHorizontal: 10 })
                                        )
                                    );
                                })
                            ) : null,

                            h(Text, { style: small },
                                cfg.provider === "omniroute"
                                    ? "مفتاح OmniRoute (اختياري تماماً — اتركه فارغاً إلا إذا فعّلت الحماية بمفتاح داخل لوحة OmniRoute):"
                                    : "إضافة مفتاح جديد أو عدة مفاتيح دفعة واحدة (كل مفتاح في سطر — لن يحذف المفاتيح القديمة):"),
                            TextInput ? h(TextInput, {
                                value: draftKey,
                                onChangeText: function (t) { keyDraft[1](t); },
                                placeholder: (pInfo.keyPlaceholder || "API Key...") + (cfg.provider === "omniroute" ? "" : "\n(يمكنك لصق عدة مفاتيح، كل مفتاح في سطر)"),
                                placeholderTextColor: "#72767D",
                                multiline: true,
                                autoCapitalize: "none",
                                autoCorrect: false,
                                style: Object.assign({}, inputStyle, { minHeight: cfg.provider === "omniroute" ? 44 : 62, textAlignVertical: "top" })
                            }) : null,
                            h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                                button(cfg.provider === "omniroute" ? "حفظ الإعدادات" : "+ إضافة / حفظ", "#248046", addProviderSettings, { flex: 1 }),
                                button(savedKeysList.length > 1 ? "اختبار الكل" : "اختبار الاتصال", "#5865F2", testAllProviderKeys, { flex: 1 })
                            ),
                            h(View, { style: { flexDirection: "row-reverse", gap: 8 } },
                                button("🔄 تصفير انتظار الحصة", "#4E5058", function () {
                                    resetAllKeyCooldowns();
                                    showToast("تم تصفير مؤقتات استراحة المفاتيح");
                                }, { flex: 1 }),
                                savedKeysList.length ? button("حذف كل مفاتيح " + pInfo.sourceName, "#DA373C", function () {
                                    var p = {}; p[pInfo.keyProp] = ""; saveCfg(p); setTestStatus("");
                                    showToast("تم حذف كل مفاتيح " + pInfo.sourceName);
                                }, { flex: 1 }) : null
                            ),
                            testStatus ? h(Text, { style: { fontSize: 12, color: testStatus.indexOf("✅") === 0 ? "#23A55A" : "#F0B232", textAlign: "right" } }, testStatus) : null,
                            h(TouchableOpacity, {
                                onPress: function () { showToast("🔒 المحرك المحلي مقفل نهائياً لمنع البلاغات الوهمية"); },
                                style: { flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", paddingVertical: 6, opacity: 0.7 }
                            },
                                h(View, { style: { flex: 1 } },
                                    h(Text, { style: { color: "#949BA4", fontSize: 14, textAlign: "right" } }, "🔒 الكشف المحلي (مقفل)"),
                                    h(Text, { style: small }, "معطّل ومقفل بناءً على طلبك — الفحص يتم حصراً عبر نماذج الذكاء الاصطناعي فقط")
                                ),
                                h(View, { style: { width: 46, height: 26, borderRadius: 13, backgroundColor: "#3F4147", justifyContent: "center", padding: 3 } },
                                    h(View, { style: { width: 20, height: 20, borderRadius: 10, backgroundColor: "#72767D", alignSelf: "flex-end" } })
                                )
                            )
                        ) : null,

                        h(Text, { style: title }, "حجم الدفعة (عدد الرسائل في الطلب الواحد)"),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            batchOptions.map(function (b) {
                                return chip(b.label, cfg.batchSize === b.v, function () { saveCfg({ batchSize: b.v }); }, "bs_" + b.v);
                            })
                        ),

                        h(Text, { style: title }, "الحساسية"),
                        h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            thresholds.map(function (t) {
                                return chip(t.label, Math.abs(cfg.threshold - t.v) < 0.01, function () { saveCfg({ threshold: t.v }); }, "th_" + t.v);
                            })
                        )
                    ),

                    // 6) خيارات الدقة والسرعة ومنع الهلوسة
                    h(View, { style: card },
                        h(Text, { style: title }, "⚡ آليات تسريع الفحص ومنع الهلوسة"),
                        toggle("منع الهلوسة بالاقتباس الحرفي (Quote Verify)", "strictQuoteVerify", "يلزم الذكاء الاصطناعي بالرد على المخالف فقط مع نسخ العبارة المخالفة حرفياً من الرسالة، ويصحح رقم الرسالة إن انزلق أو يحجب البلاغ الوهمي"),
                        toggle("التأكيد المزدوج عبر نموذجين (Double-Check)", "doubleCheckBorderline", "يعيد فحص أي رسالة مشتبه بها بنموذج ذكاء اصطناعي ثانٍ قبل تسجيلها (عطّله للرصد المباشر والفوري بدون تدقيق ومراجعة)"),
                        toggle("الفرز الذكي المسبق (تخطي التحيات والإيموجي)", "smartPreFilter", "يتخطى تلقائياً الرسائل القصيرة البديهية مثل (السلام عليكم، ههه، جزاك الله خيراً، إيموجي) لتسريع الفحص 3× وملء الدفعة (15 رسالة) بالرسائل الفعلية فقط"),
                        toggle("تشغيل دفعتين بالتوازي (2×15 في نفس اللحظة)", "parallelBatches", "يرسل دفعتين في وقت واحد إلى نموذجين مختلفين لمضاعفة سرعة البحث"),
                        toggle("متابعة البحث تلقائياً بعد إعادة تشغيل التطبيق", "autoResumeSearch", "إن أغلقت التطبيق قبل اكتمال فحص الإدارة يكمل تلقائياً من نفس النقطة بعد 5 ثوانٍ"),
                        toggle("فحص الرسائل الجديدة والمعدّلة", "scanNew"),
                        toggle("فحص الرسائل عند فتح روم أو البحث", "scanLoaded"),
                        toggle("تجاهل رسائلي", "skipOwn"),
                        toggle("تنبيه منبثق عند الرصد", "toast"),
                        toggle("تنبيه داخل الروم (يظهر لك وحدك)", "inChatNotice", "رسالة محلية تحت الرسالة المشبوهة فيها النوع والسبب وطريقة الإبلاغ")
                    ),

                    // 7) النتائج
                    h(View, { style: card },
                        h(View, { style: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" } },
                            h(Text, { style: title }, "🚩 الرسائل المرصودة (" + findings.length + ")"),
                            findings.length ? h(TouchableOpacity, { onPress: function () { saveCfg({ findings: [] }); } },
                                h(Text, { style: { color: "#F23F43", fontSize: 13 } }, "مسح الكل")) : null
                        ),
                        (function () {
                            var fakeOrUnconfirmed = findings.filter(function (x) {
                                if (!x) return true;
                                if (x.source === "محلي") return true;
                                if (isFakeOrHallucinatedFinding(x)) return true;
                                return false;
                            }).length;
                            if (!fakeOrUnconfirmed) return null;
                            return button("🧹 تنظيف الإنذارات المزيفة / القديمة (" + fakeOrUnconfirmed + ")", "#4E5058", function () {
                                var kept = findings.filter(function (x) {
                                    return x && x.source !== "محلي" && !isFakeOrHallucinatedFinding(x);
                                });
                                saveCfg({ findings: kept });
                                showToast("تم حذف " + fakeOrUnconfirmed + " إنذار مزيف والإبقاء على المخالفات المؤكدة");
                            });
                        })(),
                        savedReportDest && unforwardedCount > 0 ? button("📤 إرسال كل غير المرسل إلى المجموعة (" + unforwardedCount + ")", "#248046", function () {
                            var queuedN = 0;
                            for (var k = 0; k < findings.length; k++) {
                                if (!findings[k].forwarded && enqueueForward(findings[k], false)) queuedN++;
                            }
                            showToast(queuedN ? ("جارٍ إرسال " + queuedN + " بلاغ للمجموعة…") : "الكل مرسل بالفعل");
                        }) : null,
                        findings.length ? h(View, { style: { flexDirection: "row-reverse", flexWrap: "wrap" } },
                            [chip("الكل (" + findings.length + ")", filter === "all", function () { setFilter("all"); }, "all")].concat(
                                Object.keys(counts).map(function (k) {
                                    return chip((CATS[k] ? CATS[k].label : k) + " (" + counts[k] + ")", filter === k, function () { setFilter(k); }, k);
                                })
                            )
                        ) : h(Text, { style: small }, "لا توجد رسائل مرصودة حتى الآن."),

                        shown.slice(0, 80).map(function (f) {
                            var cat = CATS[f.cat] || { label: f.cat, color: "#999", steps: [] };
                            var isOpen = expanded[0] === f.messageId;
                            var where = (f.guildName ? f.guildName + " / " : (f.typeLabel === "خاص" ? "خاص / " : "")) + (f.channelName || f.channelId);
                            var when = "";
                            try { when = new Date(f.ts).toLocaleString(); } catch (e) { when = f.ts; }
                            return h(View, { key: f.messageId, style: { backgroundColor: "#1E1F22", borderRadius: 8, padding: 10, gap: 6, borderRightWidth: 4, borderRightColor: cat.color } },
                                h(TouchableOpacity, { onPress: function () { expanded[1](isOpen ? null : f.messageId); } },
                                    h(Text, { style: { color: cat.color, fontWeight: "bold", fontSize: 14, textAlign: "right" } }, cat.label + "  (" + Math.round((f.score || 0) * 100) + "%)" + (f.forwarded ? "  ✅ أُرسل" : "")),
                                    h(Text, { style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } }, "📍 " + where),
                                    h(Text, { style: small }, "👤 " + f.authorName + (f.authorUsername ? " (@" + f.authorUsername + ")" : "") + (f.authorBot ? " [بوت]" : "") + "  •  🕒 " + when),
                                    h(Text, { style: { color: "#E5E7EB", fontSize: 12, textAlign: "right" } }, "📌 سبب المنع: " + (f.reason || cat.label)),
                                    h(Text, { style: { color: "#949BA4", fontSize: 12, textAlign: "right", fontStyle: "italic" } }, "«" + f.snippet + "»" + (f.hasAttach ? "  📎 يحتوي مرفقاً (لم يُحلَّل)" : "")),
                                    h(Text, { style: { color: "#F0B232", fontSize: 12, textAlign: "right", marginTop: 2 } }, "⚖️ الإبلاغ: " + cat.steps.join(" ← ") + (isOpen ? "  ▲" : "  ▼"))
                                ),
                                isOpen ? h(View, { style: { gap: 6 } },
                                    h(Text, { style: { color: "#FFFFFF", fontSize: 13, fontWeight: "bold", textAlign: "right" } }, "خطوات الإبلاغ:"),
                                    cat.steps.map(function (s, idx) {
                                        return h(Text, { key: idx, style: { color: "#DBDEE1", fontSize: 13, textAlign: "right" } }, (idx + 1) + ") " + s);
                                    }),
                                    cat.extra ? h(Text, { style: { color: "#F0B232", fontSize: 12, textAlign: "right" } }, cat.extra) : null,
                                    f.guildId ? h(Text, { style: small }, "إذا كان الخادم ينشر هذا المحتوى: اضغط مطولاً على أيقونة الخادم ← إبلاغ عن الخادم، أو أرسل بلاغاً عبر dis.gd/request مع روابط الرسائل.") : null,
                                    h(Text, { style: { color: "#72767D", fontSize: 11, textAlign: "right" } }, "المصدر: " + f.source),
                                    h(Text, { style: { color: "#72767D", fontSize: 11, textAlign: "left" } }, "Server: " + (f.guildId || "DM") + "  Channel: " + f.channelId + "  Msg: " + f.messageId + "  User: " + f.authorId)
                                ) : null,
                                h(View, { style: { flexDirection: "row-reverse", gap: 6, flexWrap: "wrap" } },
                                    button("↪️ انتقال", "#5865F2", function () {
                                        if (!jumpToMessage(f)) showToast("تعذّر الانتقال — انسخ الرابط وافتحه");
                                    }),
                                    savedReportDest ? button(f.forwarded ? "📤 إعادة إرسال" : "📤 إرسال للمجموعة", "#248046", function () {
                                        enqueueForward(f, true);
                                        showToast("جارٍ الإرسال للمجموعة…");
                                    }) : null,
                                    button("📋 نسخ الرابط", "#4E5058", function () {
                                        showToast(copyText(messageLink(f)) ? "تم نسخ رابط الرسالة" : messageLink(f));
                                    }),
                                    button("📋 المعرّفات", "#4E5058", function () {
                                        var t = "Server ID: " + (f.guildId || "DM") + "\nChannel ID: " + f.channelId + "\nMessage ID: " + f.messageId + "\nUser ID: " + f.authorId + "\nLink: " + messageLink(f) + "\nType: " + cat.label + "\nReason: " + (f.reason || cat.label);
                                        showToast(copyText(t) ? "تم نسخ بيانات البلاغ" : "تعذّر النسخ");
                                    }),
                                    button("✖ تجاهل", "#3F4147", function () {
                                        saveCfg({ findings: (cfg.findings || []).filter(function (x) { return x.messageId !== f.messageId; }) });
                                    })
                                )
                            );
                        })
                    ),

                    // 8) سجل التشخيص الفوري (آخر 25 حدثاً في الذاكرة — بدون مفاتيح أو نصوص رسائل)
                    h(View, { style: card },
                        h(TouchableOpacity, {
                            onPress: function () { showDiag[1](!showDiag[0]); },
                            style: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }
                        },
                            h(Text, { style: title }, "🩺 سجل التشخيص الفوري (" + diagnosticLogs.length + "/25)"),
                            h(Text, { style: { color: "#60A5FA", fontSize: 13, fontWeight: "bold" } }, showDiag[0] ? "إخفاء ▲" : "عرض ▼")
                        ),
                        h(Text, { style: small }, "يعرض آخر 25 عملية فحص أو تأكيد أو خطأ في الذاكرة (المزوّد، النموذج، زمن الاستجابة، عدد الرسائل، والنتيجة بدون تسجيل أي مفاتيح أو نصوص شخصية)."),
                        showDiag[0] ? h(View, { style: { gap: 6 } },
                            diagnosticLogs.length > 0 ? button("🗑️ مسح سجل التشخيص", "#3F4147", function () {
                                diagnosticLogs.length = 0;
                                emitState(true);
                            }) : null,
                            diagnosticLogs.length === 0
                                ? h(Text, { style: small }, "لا توجد أحداث مسجّلة في هذه الجلسة بعد.")
                                : diagnosticLogs.map(function (d, idx) {
                                    var statusColor = d.ok ? "#23A55A" : "#F23F43";
                                    return h(View, {
                                        key: "diag_" + idx + "_" + d.time,
                                        style: { backgroundColor: "#1E1F22", borderRadius: 6, padding: 8, borderRightWidth: 3, borderRightColor: statusColor, gap: 2 }
                                    },
                                        h(Text, { style: { color: "#FFFFFF", fontSize: 12, fontWeight: "bold", textAlign: "right" } },
                                            "[" + d.time + "] " + d.provider + (d.model ? (" (" + d.model + ")") : "") +
                                            (d.ms ? (" • " + d.ms + "ms") : "") +
                                            (d.count ? (" • " + d.count + " رسائل") : "")
                                        ),
                                        h(Text, { style: { color: statusColor, fontSize: 12, textAlign: "right" } }, d.detail || (d.ok ? "تم بنجاح" : "تعذّر"))
                                    );
                                })
                        ) : null,
                        button("🗑️ مسح جميع البيانات المحفوظة (النتائج + سجل المفحوص + التقدم + التشخيص)", "#DA373C", function () {
                            resetAllProgress(true);
                            showToast("تم مسح جميع النتائج والبيانات المحفوظة بالكامل");
                        })
                    ),

                    // 9) روابط إبلاغ خارجية
                    h(View, { style: card },
                        h(Text, { style: title }, "جهات الإبلاغ"),
                        button("نموذج ثقة وأمان ديسكورد (dis.gd/request)", "#4E5058", function () { openExternal("https://dis.gd/request"); }),
                        button("NCMEC — الإبلاغ عن استغلال الأطفال", "#A12D2F", function () { openExternal("https://report.cybertip.org/"); }),
                        h(Text, { style: small }, "⚠️ عند الاشتباه باستغلال الأطفال: لا تحفظ ولا تصوّر ولا تعيد نشر أي شيء، فقط انسخ المعرّفات والروابط وبلّغ.")
                    )
                )
            );
        }
    });

    if (typeof globalThis !== "undefined" && typeof globalThis.__BAHR_TEST_HOOK__ === "function") {
        globalThis.__BAHR_TEST_HOOK__({
            DEFAULTS: DEFAULTS,
            cfg: cfg,
            state: state,
            serverSearch: serverSearch,
            diagnosticLogs: diagnosticLogs,
            persistedScannedSet: function () { return persistedScannedSet; },
            queue: queue,
            validateScanScope: validateScanScope,
            sanitizeErrorMessage: sanitizeErrorMessage,
            parseAiFlags: parseAiFlags,
            verifyAndResolveFlagIndex: verifyAndResolveFlagIndex,
            extractText: extractText,
            extractReplyContext: extractReplyContext,
            isObviouslyBenignText: isObviouslyBenignText,
            enqueueMessage: enqueueMessage,
            handleFlaggedItem: handleFlaggedItem,
            recordFinding: recordFinding,
            startServerAdminSearch: startServerAdminSearch,
            startAllMembersCrawl: startAllMembersCrawl,
            startFastKeywordSearch: startFastKeywordSearch,
            resetAllProgress: resetAllProgress,
            pump: pump,
            flushPumpNow: flushPumpNow,
            imageQueue: imageQueue,
            extractImageUrls: extractImageUrls,
            parseVisionFlags: parseVisionFlags,
            pumpImages: pumpImages,
            visionModerate: visionModerate,
            getVerifierStrengthRank: getVerifierStrengthRank,
            moderateWithFailover: moderateWithFailover,
            buildCandidateSlots: buildCandidateSlots,
            getVisionProviderCandidates: getVisionProviderCandidates,
            getMaxConcurrentBatches: getMaxConcurrentBatches,
            buildUserPrompt: buildUserPrompt,
            getActiveSystemPrompt: getActiveSystemPrompt,
            setMods: function (m) { for (var k in m) mods[k] = m[k]; },
            setStopped: function (v) { stopped = !!v; }
        });
    }

    return exports;
})({});
