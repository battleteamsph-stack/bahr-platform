(function (exports) {
    "use strict";

    var cfg = {
        delayMs: 1200,
        useSearchBoost: true,
        showLocalNotices: true
    };

    var storageRef = null;

    var mods = {
        RestAPI: null,
        UserStore: null,
        ChannelStore: null,
        GuildStore: null,
        SelectedChannelStore: null,
        MessageStore: null,
        MessageActions: null,
        Dispatcher: null,
        Toast: null
    };

    var job = {
        running: false,
        stopRequested: false,
        channelId: "",
        channelLabel: "",
        targetCount: null, // null = all
        deleted: 0,
        scanned: 0,
        skipped: 0,
        rateLimits: 0,
        status: "جاهز للحذف",
        lastError: ""
    };

    var listeners = [];

    function emitState() {
        for (var i = 0; i < listeners.length; i++) {
            try { listeners[i](); } catch (e) {}
        }
    }

    function subscribeState(fn) {
        listeners.push(fn);
        return function () {
            var idx = listeners.indexOf(fn);
            if (idx !== -1) listeners.splice(idx, 1);
        };
    }

    function getReact() {
        return (typeof valenced !== "undefined" && valenced.react && (valenced.react.React || valenced.react)) || null;
    }

    function getRN() {
        return (typeof valenced !== "undefined" && valenced.react && valenced.react.ReactNative) || null;
    }

    function sleep(ms) {
        return new Promise(function (resolve) {
            setTimeout(resolve, ms);
        });
    }

    function normalizeDigits(str) {
        if (typeof str !== "string") return "";
        var arabic = "٠١٢٣٤٥٦٧٨٩";
        var persian = "۰۱۲۳۴۵۶۷۸۹";
        var out = "";
        for (var i = 0; i < str.length; i++) {
            var ch = str.charAt(i);
            var idx = arabic.indexOf(ch);
            if (idx !== -1) {
                out += String(idx);
            } else {
                var pidx = persian.indexOf(ch);
                if (pidx !== -1) out += String(pidx);
                else out += ch;
            }
        }
        return out;
    }

    function showToast(text) {
        try {
            if (mods.Toast && typeof mods.Toast.showToast === "function") {
                mods.Toast.showToast(text);
                return;
            }
        } catch (e) {}
        try {
            var RN = getRN();
            if (RN && RN.ToastAndroid && typeof RN.ToastAndroid.show === "function") {
                RN.ToastAndroid.show(String(text), RN.ToastAndroid.SHORT);
            }
        } catch (e) {}
    }

    function sendLocalNotice(channelId, content) {
        if (!cfg.showLocalNotices || !channelId) return;
        var now = new Date().toISOString();
        var fakeId = String(Date.now()) + String(Math.floor(Math.random() * 100000));
        var msgObj = {
            id: fakeId,
            type: 0,
            channel_id: channelId,
            content: content,
            timestamp: now,
            edited_timestamp: null,
            tts: false,
            mention_everyone: false,
            mentions: [],
            mention_roles: [],
            attachments: [],
            embeds: [],
            pinned: false,
            flags: 64, // Ephemeral (local only)
            state: "SENT",
            author: {
                id: "1",
                username: "منصة بحر • حذف الرسائل",
                global_name: "منصة بحر • حذف الرسائل",
                discriminator: "0000",
                avatar: null,
                bot: true
            }
        };

        try {
            if (mods.MessageActions && typeof mods.MessageActions.receiveMessage === "function") {
                mods.MessageActions.receiveMessage(channelId, msgObj);
                return;
            }
        } catch (e) {}

        try {
            if (mods.Dispatcher && typeof mods.Dispatcher.dispatch === "function") {
                mods.Dispatcher.dispatch({
                    type: "MESSAGE_CREATE",
                    channelId: channelId,
                    message: msgObj,
                    optimistic: false,
                    isPushNotification: false
                });
            }
        } catch (e) {}
    }

    function getMyUserId() {
        try {
            if (mods.UserStore && typeof mods.UserStore.getCurrentUser === "function") {
                var u = mods.UserStore.getCurrentUser();
                if (u && u.id) return String(u.id);
            }
        } catch (e) {}
        return null;
    }

    function getCurrentChannelId() {
        try {
            if (mods.SelectedChannelStore && typeof mods.SelectedChannelStore.getChannelId === "function") {
                return mods.SelectedChannelStore.getChannelId() || "";
            }
        } catch (e) {}
        return "";
    }

    function getChannelInfo(channelId) {
        if (!channelId) return { id: "", name: "غير محدد", typeLabel: "", guildId: null };
        var ch = null;
        try {
            if (mods.ChannelStore && typeof mods.ChannelStore.getChannel === "function") {
                ch = mods.ChannelStore.getChannel(channelId);
            }
        } catch (e) {}

        if (!ch) {
            return { id: channelId, name: "قناة (" + channelId + ")", typeLabel: "قناة", guildId: null };
        }

        var type = ch.type;
        var guildId = ch.guild_id || null;

        // DM (type 1)
        if (type === 1) {
            var recipientName = "محادثة خاصة";
            try {
                var recIds = ch.recipients || ch.rawRecipients;
                if (Array.isArray(recIds) && recIds.length > 0) {
                    var first = recIds[0];
                    if (typeof first === "object" && first) {
                        recipientName = first.globalName || first.global_name || first.username || recipientName;
                    } else if (mods.UserStore && typeof mods.UserStore.getUser === "function") {
                        var u = mods.UserStore.getUser(String(first));
                        if (u) recipientName = u.globalName || u.global_name || u.username || recipientName;
                    }
                }
            } catch (e) {}
            return { id: channelId, name: recipientName, typeLabel: "خاص", guildId: null };
        }

        // Group DM (type 3)
        if (type === 3) {
            var gName = ch.name || "";
            if (!gName) {
                try {
                    var names = [];
                    var rIds = ch.recipients || [];
                    for (var i = 0; i < rIds.length && i < 3; i++) {
                        var uid = typeof rIds[i] === "object" ? rIds[i].id : String(rIds[i]);
                        var usr = mods.UserStore && mods.UserStore.getUser ? mods.UserStore.getUser(uid) : null;
                        if (usr) names.push(usr.globalName || usr.global_name || usr.username);
                    }
                    gName = names.length > 0 ? names.join("، ") : "قروب خاص";
                } catch (e) {
                    gName = "قروب خاص";
                }
            }
            return { id: channelId, name: gName, typeLabel: "قروب", guildId: null };
        }

        // Guild channel / Thread
        var chName = ch.name ? "#" + ch.name : channelId;
        var guildName = "";
        try {
            if (guildId && mods.GuildStore && typeof mods.GuildStore.getGuild === "function") {
                var g = mods.GuildStore.getGuild(guildId);
                if (g && g.name) guildName = g.name;
            }
        } catch (e) {}

        return {
            id: channelId,
            name: guildName ? (guildName + " / " + chName) : chName,
            typeLabel: "سيرفر",
            guildId: guildId
        };
    }

    function listPrivateChannels(maxItems) {
        var out = [];
        try {
            if (!mods.ChannelStore) return out;
            var raw = null;
            if (typeof mods.ChannelStore.getSortedPrivateChannels === "function") {
                raw = mods.ChannelStore.getSortedPrivateChannels();
            } else if (typeof mods.ChannelStore.getMutablePrivateChannels === "function") {
                var map = mods.ChannelStore.getMutablePrivateChannels();
                if (map && typeof map === "object") {
                    raw = Object.keys(map).map(function (k) { return map[k]; });
                }
            }
            if (Array.isArray(raw)) {
                for (var i = 0; i < raw.length && out.length < (maxItems || 25); i++) {
                    var c = raw[i];
                    if (c && c.id && (c.type === 1 || c.type === 3)) {
                        out.push(getChannelInfo(c.id));
                    }
                }
            }
        } catch (e) {}
        return out;
    }

    function isDeletableMessage(msg) {
        if (!msg || !msg.id) return false;
        // Standard message types that users can delete:
        // 0 = DEFAULT, 19 = REPLY, 20 = CHAT_INPUT_COMMAND, 23 = CONTEXT_MENU_COMMAND
        var t = msg.type;
        if (t === undefined || t === null || t === 0 || t === 19 || t === 20 || t === 23) {
            return true;
        }
        return false;
    }

    function apiGet(url, query) {
        if (!mods.RestAPI || typeof mods.RestAPI.get !== "function") {
            return Promise.reject(new Error("وحدة RestAPI غير متوفرة حالياً"));
        }
        var req = { url: url };
        if (query) req.query = query;
        return Promise.resolve(mods.RestAPI.get(req)).then(function (res) {
            if (res && res.body !== undefined) return { status: res.status || 200, body: res.body };
            return { status: 200, body: res };
        });
    }

    function apiDel(url) {
        if (mods.RestAPI && typeof mods.RestAPI.del === "function") {
            return Promise.resolve(mods.RestAPI.del({ url: url })).then(function (res) {
                return { status: (res && res.status) || 204, body: res && res.body };
            });
        }
        return Promise.reject(new Error("وحدة RestAPI.del غير متوفرة"));
    }

    function extractRetryAfterMs(err) {
        try {
            if (err && err.body && typeof err.body.retry_after === "number") {
                return Math.ceil(err.body.retry_after * 1000) + 500;
            }
            if (err && err.headers && err.headers["retry-after"]) {
                var sec = parseFloat(err.headers["retry-after"]);
                if (!isNaN(sec)) return Math.ceil(sec * 1000) + 500;
            }
        } catch (e) {}
        return 3500;
    }

    function fetchMessagesPage(channelId, beforeId) {
        var query = { limit: 100 };
        if (beforeId) query.before = beforeId;

        function attempt(tries) {
            if (job.stopRequested) return Promise.resolve([]);
            return apiGet("/channels/" + channelId + "/messages", query).then(function (res) {
                if (Array.isArray(res.body)) return res.body;
                return [];
            }).catch(function (err) {
                var status = err && (err.status || (err.body && err.body.code));
                if (status === 429 && tries < 6) {
                    var waitMs = extractRetryAfterMs(err);
                    job.rateLimits++;
                    job.status = "حد مؤقت من السيرفر... انتظار " + Math.ceil(waitMs / 1000) + " ثانية";
                    emitState();
                    return sleep(waitMs).then(function () {
                        return attempt(tries + 1);
                    });
                }
                throw err;
            });
        }

        return attempt(0);
    }

    function searchMyMessages(channelInfo, myId, maxId) {
        var url = channelInfo.guildId
            ? ("/guilds/" + channelInfo.guildId + "/messages/search")
            : ("/channels/" + channelInfo.id + "/messages/search");

        var query = { author_id: myId };
        if (channelInfo.guildId) query.channel_id = channelInfo.id;
        if (maxId) query.max_id = maxId;

        return apiGet(url, query).then(function (res) {
            if (!res || res.status === 202 || !res.body || !Array.isArray(res.body.messages)) {
                return null;
            }
            var found = [];
            var groups = res.body.messages;
            for (var i = 0; i < groups.length; i++) {
                var group = groups[i];
                if (Array.isArray(group)) {
                    for (var j = 0; j < group.length; j++) {
                        var m = group[j];
                        if (m && m.hit && m.channel_id === channelInfo.id && m.author && String(m.author.id) === myId) {
                            found.push(m);
                        }
                    }
                }
            }
            return {
                messages: found,
                totalResults: res.body.total_results || 0
            };
        }).catch(function () {
            return null;
        });
    }

    function deleteOneMessage(channelId, messageId) {
        function attempt(tries) {
            if (job.stopRequested) return Promise.resolve("stopped");

            var p;
            if (mods.RestAPI && typeof mods.RestAPI.del === "function") {
                p = apiDel("/channels/" + channelId + "/messages/" + messageId);
            } else if (mods.MessageActions && typeof mods.MessageActions.deleteMessage === "function") {
                p = Promise.resolve(mods.MessageActions.deleteMessage(channelId, messageId));
            } else {
                return Promise.reject(new Error("لا توجد أداة حذف متاحة"));
            }

            return p.then(function () {
                return "deleted";
            }).catch(function (err) {
                var status = err && err.status;
                if (status === 429 && tries < 6) {
                    var waitMs = extractRetryAfterMs(err);
                    job.rateLimits++;
                    job.status = "انتظار تلقائي لتجنب الحظر (" + Math.ceil(waitMs / 1000) + "ث)... تم حذف " + job.deleted;
                    emitState();
                    return sleep(waitMs).then(function () {
                        return attempt(tries + 1);
                    });
                }
                if (status === 404 || status === 403 || status === 400) {
                    return "skipped";
                }
                if (tries < 2) {
                    return sleep(1500).then(function () { return attempt(tries + 1); });
                }
                return "skipped";
            });
        }

        return attempt(0);
    }

    function stopPurge(notifyChannelId) {
        if (!job.running) {
            showToast("لا توجد عملية حذف جارية حالياً");
            if (notifyChannelId) sendLocalNotice(notifyChannelId, "ℹ️ لا توجد عملية حذف جارية حالياً.");
            return;
        }
        job.stopRequested = true;
        job.status = "جارٍ إيقاف الحذف...";
        emitState();
        showToast("تم طلب إيقاف الحذف");
    }

    function startPurge(channelId, targetCount, notifyInChat) {
        if (job.running) {
            var busyMsg = "⚠️ هناك عملية حذف جارية بالفعل (" + job.deleted + " رسالة محذوفة). أوقفها أولاً بكتابة `!ايقاف` أو من الإعدادات.";
            showToast("هناك عملية حذف جارية بالفعل");
            if (notifyInChat) sendLocalNotice(channelId, busyMsg);
            return;
        }

        var myId = getMyUserId();
        if (!myId) {
            var noUserMsg = "❌ تعذر التعرف على حسابك الحالي. أعد فتح التطبيق ثم حاول مجدداً.";
            showToast("تعذر التعرف على حسابك");
            if (notifyInChat) sendLocalNotice(channelId, noUserMsg);
            return;
        }

        if (!channelId) {
            showToast("يرجى تحديد محادثة أولاً");
            return;
        }

        var info = getChannelInfo(channelId);
        var limitNum = (typeof targetCount === "number" && targetCount > 0) ? Math.floor(targetCount) : null;

        job.running = true;
        job.stopRequested = false;
        job.channelId = channelId;
        job.channelLabel = (info.typeLabel ? "[" + info.typeLabel + "] " : "") + info.name;
        job.targetCount = limitNum;
        job.deleted = 0;
        job.scanned = 0;
        job.skipped = 0;
        job.rateLimits = 0;
        job.lastError = "";
        job.status = "بدء الفحص والحذف في " + job.channelLabel + "...";
        emitState();

        var startLabel = limitNum ? ("حذف آخر " + limitNum + " من رسائلك") : "حذف جميع رسائلك";
        showToast("بدأ " + startLabel);
        if (notifyInChat) {
            sendLocalNotice(
                channelId,
                "🗑️ **بدأ " + startLabel + "** في **" + job.channelLabel + "**.\n" +
                "• لإيقاف العملية في أي لحظة اكتب: `!ايقاف`\n" +
                "• لمعرفة التقدم اكتب: `!حذف حالة`"
            );
        }

        var beforeId = null;
        var emptyPages = 0;
        var deletedIds = {};

        function processBatch(messages) {
            var idx = 0;
            function nextMsg() {
                if (job.stopRequested) return Promise.resolve();
                if (limitNum && job.deleted >= limitNum) return Promise.resolve();
                if (idx >= messages.length) return Promise.resolve();

                var m = messages[idx++];
                if (!m || !m.id || deletedIds[m.id]) return nextMsg();
                if (!m.author || String(m.author.id) !== myId) return nextMsg();
                if (!isDeletableMessage(m)) {
                    job.skipped++;
                    return nextMsg();
                }

                deletedIds[m.id] = true;
                return deleteOneMessage(channelId, m.id).then(function (res) {
                    if (res === "deleted") {
                        job.deleted++;
                        job.status = "تم حذف " + job.deleted + (limitNum ? (" / " + limitNum) : "") + " رسالة (فُحصت " + job.scanned + ")";
                        emitState();
                    } else if (res === "skipped") {
                        job.skipped++;
                    }
                    if (job.stopRequested || (limitNum && job.deleted >= limitNum)) {
                        return;
                    }
                    var jitter = Math.floor(Math.random() * 250);
                    return sleep((cfg.delayMs || 1200) + jitter).then(nextMsg);
                });
            }
            return nextMsg();
        }

        function runLoop() {
            if (job.stopRequested) return Promise.resolve();
            if (limitNum && job.deleted >= limitNum) return Promise.resolve();

            // If 4 consecutive pages had 0 of my messages, try Search API boost to jump straight to my older messages
            if (cfg.useSearchBoost && emptyPages >= 4 && beforeId) {
                job.status = "البحث السريع عن رسائلك الأقدم... (محذوف: " + job.deleted + ")";
                emitState();
                return searchMyMessages(info, myId, beforeId).then(function (sRes) {
                    if (!sRes) {
                        // Search unavailable or indexing, continue normal pagination
                        emptyPages = 0;
                        return fetchAndProcessPage();
                    }
                    if (sRes.messages.length === 0) {
                        // No more messages by me older than beforeId!
                        return;
                    }
                    job.scanned += sRes.messages.length;
                    var oldestId = sRes.messages[sRes.messages.length - 1].id;
                    return processBatch(sRes.messages).then(function () {
                        if (oldestId === beforeId) return;
                        beforeId = oldestId;
                        return sleep(600).then(runLoop);
                    });
                });
            }

            return fetchAndProcessPage();
        }

        function fetchAndProcessPage() {
            job.status = "جارٍ فحص الرسائل... (محذوف: " + job.deleted + " | مفحوص: " + job.scanned + ")";
            emitState();
            return fetchMessagesPage(channelId, beforeId).then(function (batch) {
                if (job.stopRequested) return;
                if (!batch || batch.length === 0) return;

                job.scanned += batch.length;
                beforeId = batch[batch.length - 1].id;

                var mine = [];
                for (var i = 0; i < batch.length; i++) {
                    var msg = batch[i];
                    if (msg && msg.author && String(msg.author.id) === myId && !deletedIds[msg.id]) {
                        mine.push(msg);
                    }
                }

                if (mine.length === 0) {
                    emptyPages++;
                } else {
                    emptyPages = 0;
                }

                return processBatch(mine).then(function () {
                    if (job.stopRequested) return;
                    if (limitNum && job.deleted >= limitNum) return;
                    if (batch.length < 100) return; // reached beginning of channel
                    return sleep(350).then(runLoop);
                });
            });
        }

        runLoop().then(function () {
            var wasStopped = job.stopRequested;
            job.running = false;
            job.stopRequested = false;
            job.status = (wasStopped ? "تم الإيقاف: " : "اكتمل الحذف: ") + "حُذفت " + job.deleted + " رسالة (فُحصت " + job.scanned + ")";
            emitState();

            var summary = (wasStopped ? "⏹️ **تم إيقاف الحذف**" : "✅ **اكتمل حذف الرسائل**") +
                "\n• المكان: **" + job.channelLabel + "**" +
                "\n• الرسائل المحذوفة: **" + job.deleted + "**" +
                "\n• الرسائل المفحوصة: **" + job.scanned + "**" +
                (job.skipped > 0 ? ("\n• رسائل تم تخطيها (نظام/غير قابلة للحذف): **" + job.skipped + "**") : "");

            showToast((wasStopped ? "تم الإيقاف: " : "اكتمل: ") + "حُذفت " + job.deleted + " رسالة");
            if (notifyInChat) sendLocalNotice(channelId, summary);
        }).catch(function (err) {
            var errText = (err && (err.message || (err.body && err.body.message))) || String(err || "خطأ غير معروف");
            job.running = false;
            job.stopRequested = false;
            job.lastError = errText;
            job.status = "توقف بسبب خطأ بعد حذف " + job.deleted + " رسالة";
            emitState();
            showToast("خطأ أثناء الحذف: " + errText);
            if (notifyInChat) {
                sendLocalNotice(channelId, "❌ **حدث خطأ أثناء الحذف:** " + errText + "\n• تم حذف **" + job.deleted + "** رسالة قبل التوقف.");
            }
        });
    }

    function handleChatCommand(channelId, rawText) {
        if (typeof rawText !== "string") return false;
        var text = rawText.trim();
        if (!text || text.charAt(0) !== "!") return false;

        var norm = normalizeDigits(text);
        var parts = norm.split(/\s+/);
        var cmd = parts[0].toLowerCase();
        var arg = parts.slice(1).join(" ").trim().toLowerCase();

        // Direct stop command while running
        if (cmd === "!ايقاف" || cmd === "!إيقاف" || cmd === "!توقف" || cmd === "!ايقاف_حذف") {
            if (job.running || cmd === "!ايقاف_حذف") {
                stopPurge(channelId);
                return true;
            }
            return false;
        }

        if (cmd === "!حالة_حذف") {
            sendLocalNotice(
                channelId,
                "📊 **حالة الحذف:** " + job.status +
                (job.running ? ("\n• المكان: **" + job.channelLabel + "**\n• المحذوفة: **" + job.deleted + "** | المفحوصة: **" + job.scanned + "**") : "")
            );
            return true;
        }

        if (cmd === "!حذف" || cmd === "!مسح" || cmd === "!purge") {
            if (!arg || arg === "مساعدة" || arg === "help" || arg === "؟" || arg === "?") {
                sendLocalNotice(
                    channelId,
                    "🧹 **أوامر حذف رسائلي (تعمل في الخاص والقروبات والسيرفرات):**\n" +
                    "• `!حذف 20` — حذف آخر 20 من رسائلك في هذه المحادثة\n" +
                    "• `!حذف الكل` — حذف **جميع** رسائلك في هذه المحادثة\n" +
                    "• `!ايقاف` — إيقاف الحذف فوراً\n" +
                    "• `!حذف حالة` — عرض عدد الرسائل المحذوفة حالياً\n" +
                    "*(ملاحظة: هذه الأوامر محلية ولا تُرسل للطرف الآخر)*"
                );
                return true;
            }

            if (arg === "ايقاف" || arg === "إيقاف" || arg === "توقف" || arg === "stop") {
                stopPurge(channelId);
                return true;
            }

            if (arg === "حالة" || arg === "status") {
                sendLocalNotice(
                    channelId,
                    "📊 **حالة الحذف:** " + job.status +
                    (job.running ? ("\n• المكان: **" + job.channelLabel + "**\n• المحذوفة: **" + job.deleted + "** | المفحوصة: **" + job.scanned + "**") : "")
                );
                return true;
            }

            if (arg === "الكل" || arg === "كل" || arg === "جميع" || arg === "all") {
                startPurge(channelId, null, true);
                return true;
            }

            var num = parseInt(arg, 10);
            if (!isNaN(num) && num > 0) {
                startPurge(channelId, num, true);
                return true;
            }

            sendLocalNotice(channelId, "⚠️ أمر غير مفهوم. اكتب `!حذف 10` لحذف عدد معين، أو `!حذف الكل` لحذف كل رسائلك.");
            return true;
        }

        return false;
    }

    function saveSettings(patch) {
        if (patch.delayMs !== undefined) cfg.delayMs = patch.delayMs;
        if (patch.useSearchBoost !== undefined) cfg.useSearchBoost = patch.useSearchBoost;
        if (patch.showLocalNotices !== undefined) cfg.showLocalNotices = patch.showLocalNotices;
        if (storageRef && typeof storageRef.set === "function") {
            try { storageRef.set(patch); } catch (e) {}
        }
    }

    exports.default = plugin({
        jsonStorage: {
            load: true,
            default: {
                delayMs: 1200,
                useSearchBoost: true,
                showLocalNotices: true
            }
        },
        start: function (ctx) {
            var cleanup = ctx.cleanup;
            var finders = valenced.modules.finders;
            var filters = finders.filters;
            var patcher = valenced.patcher;

            storageRef = ctx.jsonStorage || null;
            if (storageRef) {
                var applyLoaded = function (c) {
                    if (!c || typeof c !== "object") return;
                    if (typeof c.delayMs === "number" && c.delayMs >= 400) cfg.delayMs = c.delayMs;
                    if (typeof c.useSearchBoost === "boolean") cfg.useSearchBoost = c.useSearchBoost;
                    if (typeof c.showLocalNotices === "boolean") cfg.showLocalNotices = c.showLocalNotices;
                };
                if (storageRef.cache) applyLoaded(storageRef.cache);
                if (typeof storageRef.get === "function") {
                    Promise.resolve(storageRef.get()).then(applyLoaded).catch(function () {});
                }
            }

            // Try Valenced built-in Discord shortcuts first
            try {
                var d = valenced.discord;
                if (d) {
                    if (d.rest) mods.RestAPI = d.rest;
                    if (d.common && d.common.RestAPI && !mods.RestAPI) mods.RestAPI = d.common.RestAPI;
                    if (d.common && d.common.flux && d.common.flux.Dispatcher) mods.Dispatcher = d.common.flux.Dispatcher;
                    if (d.flux && d.flux.Stores) {
                        if (d.flux.Stores.UserStore) mods.UserStore = d.flux.Stores.UserStore;
                        if (d.flux.Stores.ChannelStore) mods.ChannelStore = d.flux.Stores.ChannelStore;
                        if (d.flux.Stores.GuildStore) mods.GuildStore = d.flux.Stores.GuildStore;
                        if (d.flux.Stores.SelectedChannelStore) mods.SelectedChannelStore = d.flux.Stores.SelectedChannelStore;
                        if (d.flux.Stores.MessageStore) mods.MessageStore = d.flux.Stores.MessageStore;
                    }
                }
            } catch (e) {}

            // Module finders
            cleanup(finders.getModules(filters.withProps("get", "post", "put", "del"), function (m) {
                if (m && typeof m.get === "function" && typeof m.del === "function") {
                    if (!mods.RestAPI || typeof m.getAPIBaseURL === "function" || typeof m.patch === "function") {
                        mods.RestAPI = m;
                    }
                }
            }));

            if (!mods.UserStore) {
                cleanup(finders.getModules(filters.withProps("getCurrentUser", "getUser"), function (m) {
                    mods.UserStore = m;
                }));
            }

            if (!mods.ChannelStore) {
                cleanup(finders.getModules(filters.withProps("getChannel", "getDMFromUserId"), function (m) {
                    mods.ChannelStore = m;
                }));
            }

            if (!mods.GuildStore) {
                cleanup(finders.getModules(filters.withProps("getGuild", "getGuilds"), function (m) {
                    mods.GuildStore = m;
                }));
            }

            if (!mods.SelectedChannelStore) {
                cleanup(finders.getModules(filters.withProps("getChannelId", "getVoiceChannelId"), function (m) {
                    mods.SelectedChannelStore = m;
                }));
            }

            if (!mods.MessageStore) {
                cleanup(finders.getModules(filters.withProps("getMessage", "getMessages"), function (m) {
                    mods.MessageStore = m;
                }));
            }

            if (!mods.Dispatcher) {
                cleanup(finders.getModules(filters.withProps("_interceptors", "dispatch"), function (m) {
                    mods.Dispatcher = m;
                }));
            }

            cleanup(finders.getModules(filters.withProps("showToast"), function (m) {
                mods.Toast = m;
            }));

            var sendPatched = false;
            cleanup(finders.getModules(filters.withProps("sendMessage", "deleteMessage"), function (m) {
                if (!m || typeof m.sendMessage !== "function") return;
                mods.MessageActions = m;
                if (sendPatched) return;
                sendPatched = true;
                try {
                    cleanup(patcher.instead(m, "sendMessage", function (args, original) {
                        try {
                            var chId = args && args[0];
                            var msgPayload = args && args[1];
                            var content = msgPayload && msgPayload.content;
                            if (typeof content === "string" && handleChatCommand(chId, content)) {
                                return Promise.resolve();
                            }
                        } catch (e) {}
                        return original.apply(this, args);
                    }));
                } catch (e) {}
            }));

            cleanup(function () {
                job.stopRequested = true;
            });
        },

        SettingsComponent: function () {
            var R = getReact();
            var RN = getRN();
            if (!R || !RN) return null;

            var View = RN.View;
            var Text = RN.Text;
            var ScrollView = RN.ScrollView;
            var TouchableOpacity = RN.TouchableOpacity;
            var TextInput = RN.TextInput;

            var tickState = R.useState(0);
            var setTick = tickState[1];

            R.useEffect(function () {
                return subscribeState(function () {
                    setTick(function (n) { return n + 1; });
                });
            }, []);

            var activeChannelId = getCurrentChannelId();
            var selectedIdState = R.useState(activeChannelId || "");
            var selectedId = selectedIdState[0];
            var setSelectedId = selectedIdState[1];

            var modeState = R.useState("count"); // "count" | "all"
            var mode = modeState[0];
            var setMode = modeState[1];

            var countInputState = R.useState("20");
            var countInput = countInputState[0];
            var setCountInput = countInputState[1];

            var confirmAllState = R.useState(false);
            var confirmAll = confirmAllState[0];
            var setConfirmAll = confirmAllState[1];

            var showDmListState = R.useState(false);
            var showDmList = showDmListState[0];
            var setShowDmList = showDmListState[1];

            var selectedInfo = getChannelInfo(selectedId);
            var activeInfo = activeChannelId ? getChannelInfo(activeChannelId) : null;
            var privateChannels = showDmList ? listPrivateChannels(30) : [];

            function btnStyle(bg, extra) {
                return Object.assign({
                    backgroundColor: bg,
                    paddingVertical: 11,
                    paddingHorizontal: 14,
                    borderRadius: 8,
                    alignItems: "center",
                    justifyContent: "center"
                }, extra || {});
            }

            var cardStyle = {
                backgroundColor: "#2B2D31",
                borderRadius: 10,
                padding: 14,
                gap: 10
            };

            var presets = [5, 10, 25, 50, 100];
            var delays = [
                { label: "سريع (800ms)", val: 800 },
                { label: "متوازن (1200ms)", val: 1200 },
                { label: "آمن جداً (2000ms)", val: 2000 }
            ];

            return R.createElement(
                ScrollView,
                { style: { flex: 1, padding: 16, backgroundColor: "#1E1F22" } },
                R.createElement(
                    View,
                    { style: { gap: 14, paddingBottom: 40 } },

                    // Header
                    R.createElement(
                        Text,
                        { style: { fontSize: 19, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                        "🧹 حذف رسائلي (خاص / قروب / سيرفر)"
                    ),

                    // Live Status Card
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 14, fontWeight: "bold", color: job.running ? "#23A55A" : "#FFFFFF", textAlign: "right" } },
                            "الحالة: " + job.status
                        ),
                        R.createElement(
                            Text,
                            { style: { fontSize: 12, color: "#B5BAC1", textAlign: "right" } },
                            "المحذوفة: " + job.deleted + "  |  المفحوصة: " + job.scanned + "  |  تم تخطيها: " + job.skipped
                        ),
                        job.lastError ? R.createElement(
                            Text,
                            { style: { fontSize: 12, color: "#F23F43", textAlign: "right" } },
                            "آخر خطأ: " + job.lastError
                        ) : null,
                        job.running ? R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () { stopPurge(null); },
                                style: btnStyle("#DA373C")
                            },
                            R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, "⏹️ إيقاف الحذف فوراً")
                        ) : null
                    ),

                    // Target Channel Card
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "1) اختر المكان (خاص / قروب / قناة)"
                        ),
                        R.createElement(
                            Text,
                            { style: { fontSize: 13, color: "#DBDEE1", textAlign: "right" } },
                            "المكان المحدد حالياً: " + (selectedId ? ("[" + (selectedInfo.typeLabel || "قناة") + "] " + selectedInfo.name) : "لم يتم التحديد")
                        ),
                        activeInfo ? R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () { setSelectedId(activeChannelId); setConfirmAll(false); },
                                style: btnStyle("#5865F2")
                            },
                            R.createElement(
                                Text,
                                { style: { color: "#FFFFFF", fontWeight: "bold" } },
                                "استخدام المحادثة المفتوحة الآن: " + activeInfo.name
                            )
                        ) : null,
                        R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () { setShowDmList(!showDmList); },
                                style: btnStyle("#4E5058")
                            },
                            R.createElement(
                                Text,
                                { style: { color: "#FFFFFF", fontWeight: "bold" } },
                                showDmList ? "إخفاء قائمة الخاص والقروبات ▲" : "اختيار من محادثات الخاص والقروبات ▼"
                            )
                        ),
                        showDmList ? R.createElement(
                            View,
                            { style: { gap: 6, marginTop: 4 } },
                            privateChannels.length === 0
                                ? R.createElement(Text, { style: { color: "#949BA4", textAlign: "right", fontSize: 12 } }, "لم يتم العثور على محادثات خاصة محمّلة حالياً.")
                                : privateChannels.map(function (ch) {
                                    var isSel = ch.id === selectedId;
                                    return R.createElement(
                                        TouchableOpacity,
                                        {
                                            key: ch.id,
                                            onPress: function () {
                                                setSelectedId(ch.id);
                                                setShowDmList(false);
                                                setConfirmAll(false);
                                            },
                                            style: btnStyle(isSel ? "#248046" : "#1E1F22", { alignItems: "flex-end" })
                                        },
                                        R.createElement(
                                            Text,
                                            { style: { color: "#FFFFFF", fontSize: 13 } },
                                            "[" + ch.typeLabel + "] " + ch.name
                                        )
                                    );
                                })
                        ) : null,
                        R.createElement(
                            Text,
                            { style: { fontSize: 12, color: "#949BA4", textAlign: "right", marginTop: 4 } },
                            "أو أدخل معرّف القناة (Channel ID) يدوياً:"
                        ),
                        TextInput ? R.createElement(TextInput, {
                            value: selectedId,
                            onChangeText: function (t) { setSelectedId(normalizeDigits(t).trim()); setConfirmAll(false); },
                            placeholder: "مثال: 123456789012345678",
                            placeholderTextColor: "#72767D",
                            keyboardType: "numeric",
                            style: {
                                backgroundColor: "#111214",
                                color: "#FFFFFF",
                                padding: 10,
                                borderRadius: 8,
                                borderWidth: 1,
                                borderColor: "#3F4147"
                            }
                        }) : null
                    ),

                    // Mode & Count Card
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "2) كمية الرسائل المراد حذفها"
                        ),
                        R.createElement(
                            View,
                            { style: { flexDirection: "row", gap: 8 } },
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setMode("count"); setConfirmAll(false); },
                                    style: btnStyle(mode === "count" ? "#5865F2" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, "عدد معين")
                            ),
                            R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () { setMode("all"); setConfirmAll(false); },
                                    style: btnStyle(mode === "all" ? "#DA373C" : "#4E5058", { flex: 1 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, "حذف كل رسائلي")
                            )
                        ),
                        mode === "count" ? R.createElement(
                            View,
                            { style: { gap: 8 } },
                            R.createElement(
                                View,
                                { style: { flexDirection: "row", flexWrap: "wrap", gap: 6, justifyContent: "flex-end" } },
                                presets.map(function (n) {
                                    var active = String(n) === countInput;
                                    return R.createElement(
                                        TouchableOpacity,
                                        {
                                            key: String(n),
                                            onPress: function () { setCountInput(String(n)); },
                                            style: btnStyle(active ? "#248046" : "#1E1F22", { minWidth: 52, paddingVertical: 8 })
                                        },
                                        R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold" } }, String(n))
                                    );
                                })
                            ),
                            TextInput ? R.createElement(TextInput, {
                                value: countInput,
                                onChangeText: function (t) { setCountInput(normalizeDigits(t).replace(/[^0-9]/g, "")); },
                                placeholder: "أدخل العدد المطلوب...",
                                placeholderTextColor: "#72767D",
                                keyboardType: "numeric",
                                style: {
                                    backgroundColor: "#111214",
                                    color: "#FFFFFF",
                                    padding: 10,
                                    borderRadius: 8,
                                    borderWidth: 1,
                                    borderColor: "#3F4147"
                                }
                            }) : null
                        ) : R.createElement(
                            Text,
                            { style: { fontSize: 12, color: "#F0B232", textAlign: "right" } },
                            "⚠️ سيقوم هذا الخيار بحذف جميع رسائلك في المكان المحدد حتى بدايته."
                        )
                    ),

                    // Delay & Options Card
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "3) سرعة الحذف (لحماية الحساب من التقييد)"
                        ),
                        R.createElement(
                            View,
                            { style: { flexDirection: "row", flexWrap: "wrap", gap: 6, justifyContent: "flex-end" } },
                            delays.map(function (d) {
                                var active = cfg.delayMs === d.val;
                                return R.createElement(
                                    TouchableOpacity,
                                    {
                                        key: String(d.val),
                                        onPress: function () {
                                            saveSettings({ delayMs: d.val });
                                            setTick(function (n) { return n + 1; });
                                        },
                                        style: btnStyle(active ? "#248046" : "#1E1F22", { paddingVertical: 8 })
                                    },
                                    R.createElement(Text, { style: { color: "#FFFFFF", fontSize: 12, fontWeight: "bold" } }, d.label)
                                );
                            })
                        ),
                        R.createElement(
                            TouchableOpacity,
                            {
                                onPress: function () {
                                    saveSettings({ useSearchBoost: !cfg.useSearchBoost });
                                    setTick(function (n) { return n + 1; });
                                },
                                style: btnStyle(cfg.useSearchBoost ? "#248046" : "#4E5058")
                            },
                            R.createElement(
                                Text,
                                { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 13 } },
                                "البحث السريع عن الرسائل القديمة: " + (cfg.useSearchBoost ? "مفعّل" : "معطّل")
                            )
                        )
                    ),

                    // Execute Button
                    !job.running ? (
                        mode === "all" && !confirmAll
                            ? R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () {
                                        if (!selectedId) {
                                            showToast("اختر محادثة أو أدخل Channel ID أولاً");
                                            return;
                                        }
                                        setConfirmAll(true);
                                    },
                                    style: btnStyle("#DA373C", { paddingVertical: 14 })
                                },
                                R.createElement(Text, { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 15 } }, "🗑️ حذف كل رسائلي في هذا المكان")
                            )
                            : R.createElement(
                                TouchableOpacity,
                                {
                                    onPress: function () {
                                        if (!selectedId) {
                                            showToast("اختر محادثة أو أدخل Channel ID أولاً");
                                            return;
                                        }
                                        var target = null;
                                        if (mode === "count") {
                                            var parsed = parseInt(countInput, 10);
                                            if (isNaN(parsed) || parsed <= 0) {
                                                showToast("أدخل عدداً صحيحاً أكبر من 0");
                                                return;
                                            }
                                            target = parsed;
                                        }
                                        setConfirmAll(false);
                                        startPurge(selectedId, target, true);
                                    },
                                    style: btnStyle(mode === "all" ? "#B8252A" : "#248046", { paddingVertical: 14 })
                                },
                                R.createElement(
                                    Text,
                                    { style: { color: "#FFFFFF", fontWeight: "bold", fontSize: 15 } },
                                    mode === "all"
                                        ? "⚠️ اضغط مجدداً لتأكيد حذف جميع رسائلك"
                                        : ("🚀 ابدأ حذف " + (countInput || "20") + " رسالة الآن")
                                )
                            )
                    ) : null,

                    // Quick Chat Commands Guide
                    R.createElement(
                        View,
                        { style: cardStyle },
                        R.createElement(
                            Text,
                            { style: { fontSize: 15, fontWeight: "bold", color: "#FFFFFF", textAlign: "right" } },
                            "⚡ الأوامر السريعة من داخل أي شات مباشرة"
                        ),
                        R.createElement(
                            Text,
                            { style: { fontSize: 13, color: "#DBDEE1", textAlign: "right", lineHeight: 22 } },
                            "• !حذف 20  ←  حذف آخر 20 من رسائلك في نفس الشات\n" +
                            "• !حذف الكل  ←  حذف كل رسائلك في نفس الشات\n" +
                            "• !ايقاف  ←  إيقاف الحذف فوراً\n" +
                            "• !حذف حالة  ←  معرفة كم رسالة تم حذفها\n" +
                            "• !حذف مساعدة  ←  عرض دليل الأوامر\n" +
                            "(لا تُرسل هذه الأوامر لأحد وتعمل في الخاص والقروب والسيرفر)"
                        )
                    )
                )
            );
        }
    });

    return exports;
})({});
